package com.ihomefnt;

import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.mobile.MobileApiApplication;
import com.ihomefnt.mobile.domain.hotupdate.po.AppBundleDiff;
import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import com.ihomefnt.mobile.domain.module.AppModule;
import com.ihomefnt.mobile.dao.IHotUpdateMapper;
import com.ihomefnt.mobile.domain.upload.dto.UploadFileRequest;
import com.ihomefnt.mobile.proxy.upload.IUploadProxy;
import com.ihomefnt.mobile.common.utils.FileUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=MobileApiApplication.class, webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MobileApiApplicationTests {

	/**
     * @LocalServerPort 提供了 @Value("${local.server.port}") 的代替
     */
    @LocalServerPort
    private int port;
    
    @Autowired
    private IHotUpdateMapper mapper;

    @Autowired
    private IUploadProxy uploadProxy;
    
	@Test
	public void bundleQuery() {
		System.out.println(1);
		Map<String,Object> params = new HashMap<>(2);
		params.put("baseAppVersion",5);
		params.put("moduleCodes",new ArrayList<String>(){{
			add("123456");
			add("654321");
		}});
		Map<String, AppBundleRecord> recordMap = mapper.getLatestBundleByModuleCodes(params);

		List<AppBundleRecord> appBundleRecordList = new ArrayList<>();

		for (String moduleCode : recordMap.keySet()){
			appBundleRecordList.add(recordMap.get(moduleCode));
		}

		System.out.println(JsonUtils.obj2json(appBundleRecordList));
	}

	@Test
	public void diffQuery() {
		System.out.println(2);
		List<AppBundleDiff> appBundleDiffList = new ArrayList<AppBundleDiff>(){{
			add(new AppBundleDiff().setModuleCode("123456").setMainBundleVersionCode(2).setDiffBundleVersionCode(1));
			add(new AppBundleDiff().setModuleCode("654321").setMainBundleVersionCode(2).setDiffBundleVersionCode(1));
		}};

		List<AppBundleDiff> appBundleDiffs = mapper.getLatestBundleDiff(appBundleDiffList);

		System.out.println(JsonUtils.obj2json(appBundleDiffs));
	}

	@Test
	public void insertBundle(){
		System.out.print(3);
		AppBundleRecord appBundleRecord = new AppBundleRecord().setModuleCode("123456")
				.setBaseAppVersion(5)
				.setDownloadUrl("main_3")
				.setFileMd5("abcdksj")
				.setRemindMode(1)
				.setUpdateFlag(1)
				.setVersionCode(3)
				.setUpdateTitle("更新标题")
				.setUpdateDesc("更新说明")
				.setVersionName("5.1.2.2");

		AppBundleRecord record = mapper.createNewBundle(appBundleRecord);
		System.out.println(JsonUtils.obj2json(record));
	}

	@Test
	public void insertDiffs(){
		System.out.print(4);
		List<AppBundleDiff> appBundleDiffList = new ArrayList<>();
		for(int i = 1;i<3;i++){
			AppBundleDiff diff = new AppBundleDiff().setModuleCode("123456")
					.setMainBundleVersionCode(3)
					.setDiffVersionName("main_3_diff_"+i)
					.setDiffBundleVersionCode(i)
					.setDownloadUrl("cdse")
					.setFileMd5("12456suaa");
			appBundleDiffList.add(diff);
		}

		List<AppBundleDiff> bundleDiffs = mapper.createNewDiffs(appBundleDiffList);

		System.out.print(JsonUtils.obj2json(bundleDiffs));

	}

	@Test
	public void unzip(){
		FileUtils.unZip("/Users/xiamingyu/coding/working/mobile-base/mobile-api/target/classes/life_4/life_4.zip", "/Users/xiamingyu/coding/working/mobile-base/mobile-api/target/classes/life_4/");
	}

	@Test
	public void uploadFile(){
		File diffFile = new File("/Users/xiamingyu/coding/working/mobile-base/mobile-api/target/classes/decoration_android_2_diff_1.zip");
		UploadFileRequest uploadFileRequest = new UploadFileRequest().setBucketType(2)
				.setBusinessSystemName("o2o")
				.setMultipartFile(diffFile)
				.setSceneName("AppBundleFile");

		uploadProxy.uploadStaticFile(uploadFileRequest,"decoration_android_2_diff_1.zip");
	}

	@Test
	public void queryModuleByAppId(){
		Map<String,Object> params = new HashMap<>(3);
		params.put("appId","111111");
		params.put("pageNo",2);
		params.put("pageSize",2);
		List<AppModule> appModules = mapper.queryModuleByAppId(params);
	}

}
