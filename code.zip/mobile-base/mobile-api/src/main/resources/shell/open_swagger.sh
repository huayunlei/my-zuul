#!/usr/bin/env bash

open 'http://localhost:11155/mobile-api/swagger-ui.html#/'