package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.hotupdate.BasebandVersion;
import com.ihomefnt.mobile.domain.hotupdate.dto.BasebandVersionDto;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryBaseBandPageDto;
import com.ihomefnt.mobile.domain.hotupdate.vo.BasebandVo;

import java.util.List;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-10-08 14:19
 */
public interface BasebandService extends IService<BasebandVersion> {

    /**
     * 创建基带版本
     *
     * @param versionDto 版本信息
     * @return 创建结果
     */
    ResponseVo create(BasebandVersionDto versionDto);

    /**
     * 查询所有基带版本
     *
     * @param osType 系统类型 1:ios 2:安卓
     * @return 基带版本
     */
    ResponseVo<List<BasebandVo>> queryAll(Integer osType);

    /**
     * 分页查询基带版本
     *
     * @param pageDto 分页信息
     * @return 基带版本
     */
    ResponseVo<PageResponse<BasebandVo>> queryPage(QueryBaseBandPageDto pageDto);


    /**
     * 删除基带版本
     *
     * @param id 基带版本id
     * @return 删除结果
     */
    ResponseVo delete(Integer id);

    ResponseVo<BasebandVo> detailById(Integer id);

}
