package com.ihomefnt.mobile.common.aop;

import com.ihomefnt.mobile.common.BusinessException;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.common.constant.HttpResponseCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;

/**
 * 自定义异常处理
 *
 * @author liyonggang
 * @create 2018-12-20 17:48
 */
public class CustomerExceptionHandler {

    public static final Logger LOGGER = LoggerFactory.getLogger(CustomerExceptionHandler.class);

    private static final String httpBaseResponseSimpleClassName = ResponseVo.class.getSimpleName();

    public static Object handlerCustomerExcelption(Exception e, Method method) {
        if (e instanceof BusinessException) {
            BusinessException exception = (BusinessException) e;
            Object obj = handlerResult(exception.getCode(), exception.getMessage(), method);
            LOGGER.error("---handlerCustomerExcelption.BusinessException Handler---### {} ### {}", method.getName(), e);
            return obj;
        } else if (e.getCause() != null && e.getCause().getCause() != null && e.getCause().getCause() instanceof BusinessException) {
            BusinessException exception = (BusinessException) e.getCause().getCause();
            Object obj = handlerResult(exception.getCode(), exception.getMessage(), method);
            LOGGER.error("---post.handlerCustomerExcelption.BusinessException Handler---### {} ### {}", method.getName(), e);
            return obj;
        } else {
            LOGGER.error("---handlerCustomerExcelption.Exception Handler---### {} ### {}", method.getName(), e);
            return handlerResult(HttpResponseCode.FAILED, "服务器内部异常", method);
        }
    }

    private static Object handlerResult(int code, String message, Method method) {
        Class<?> returnType = method.getReturnType();
        String simpleName = returnType.getSimpleName();
        Object result = null;
        ResponseVo baseResponse = ResponseVo.buildFailedResponse(code, message);
        if (simpleName.equalsIgnoreCase(httpBaseResponseSimpleClassName)) {
            result = baseResponse;
        }
        return result;
    }
}
