package com.ihomefnt.mobile.domain.group.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class DeleteAppDto {

    @ApiModelProperty("组关联id")
    private List<Integer> relationIds;
}
