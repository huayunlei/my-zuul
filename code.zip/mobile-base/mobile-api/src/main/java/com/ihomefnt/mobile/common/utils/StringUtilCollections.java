package com.ihomefnt.mobile.common.utils;

/**
 * @author xiamingyu
 * @date 2019/1/2
 */

public class StringUtilCollections {

    /**
     * 判断字符串是否只包含英文字母
     * @param str
     * @return
     */
    public static boolean letterOnly(String str){
        String regex = "^[a-zA-Z]*$";
        return str.matches(regex);
    }
}
