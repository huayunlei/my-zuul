package com.ihomefnt.mobile.constant.hotupdate;

/**
 * @author xiamingyu
 */

public enum BundleConfigEnum {

    NO_MODULE(1011,"未查询到模块信息"),
    INCREMENT_UPDATE(2,"增量更新"),
    FULL_UPDATE(1,"全量更新");

    private Integer code;

    private String msg;


    BundleConfigEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static BundleConfigEnum getEnumByCode(int code){
        BundleConfigEnum[] values = values();
        for (BundleConfigEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }


    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
