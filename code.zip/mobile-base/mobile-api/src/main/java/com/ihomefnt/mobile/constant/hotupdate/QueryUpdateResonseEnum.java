package com.ihomefnt.mobile.constant.hotupdate;

/**
 * @author xiamingyu
 */

public enum QueryUpdateResonseEnum {

    APPID_NOT_MATCH(1021,"模块唯一码与APPID不匹配"),
    NO_MODULE_RECORD(1022,"未查询到模块更新记录");

    private Integer code;

    private String msg;


    QueryUpdateResonseEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static QueryUpdateResonseEnum getEnumByCode(int code){
        QueryUpdateResonseEnum[] values = values();
        for (QueryUpdateResonseEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }


    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
