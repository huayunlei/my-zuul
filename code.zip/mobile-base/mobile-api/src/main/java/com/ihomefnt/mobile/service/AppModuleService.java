package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.common.BasePageRequest;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.domain.module.AppModule;
import com.ihomefnt.mobile.domain.module.vo.AppModuleVo;

import java.util.List;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-26 10:52
 */
public interface AppModuleService extends IService<AppModule> {

    List<AppModule> queryModuleList(String id);

    PageResponse<AppModuleVo> queryPage(BasePageRequest request);
}
