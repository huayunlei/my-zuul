package com.ihomefnt.mobile.domain.hotupdate.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-10-08 14:10
 */
@Data
public class BasebandVo {

    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "系统类型 1:ios 2:android")
    private Integer osType;

    @ApiModelProperty(value = "基带版本号")
    private Integer basebandVersion;

    @ApiModelProperty(value = "说明")
    private String remark;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createTime;
}
