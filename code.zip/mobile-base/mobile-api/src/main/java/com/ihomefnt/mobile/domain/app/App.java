package com.ihomefnt.mobile.domain.app;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ihomefnt.mobile.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * @author xiamingyu
 */

@Data
@Accessors(chain = true)
@TableName("t_app")
@EqualsAndHashCode(callSuper = true)
public class App extends BaseEntity {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 应用民称
     */
    private String appName;

    /**
     * 应用id
     */
    private String appId;

    /**
     * 应用迷药
     */
    private String appSecret;

    /**
     * 应用类型 1:IOS 2:Android
     */
    private Integer appType;

    /**
     * 其他能力 Native H5
     */
    private String type;

    /**
     * 包名
     */
    private String bundleId;

    /**
     * app图标
     */
    private String icon;

    /**
     * 描述
     */
    private String description;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改时间
     */
    private LocalDateTime updateTime;

    /**
     * 删除标记
     */
    private Integer deleteFlag;

    /**
     * 所属组
     */
    private Integer groupId;

}