package com.ihomefnt.mobile.domain.hotupdate.po;

import lombok.Data;
import lombok.experimental.Accessors;

import java.sql.Timestamp;

/**
 * @author xiamingyu
 */
@Data
@Accessors(chain = true)
public class UpdateLog {
    private Integer id;

    private String deviceToken;

    private String osType;

    private String network;

    private String userInfo;

    private String appId;

    private String moduleCode;

    private String type;

    private Integer appVersionCode;

    private Integer nativeBundleVersionCode;

    private Integer remoteBundleVersionCode;

    private Integer updateFlag;

    private Integer resultCode;

    private String resultMsg;

    private Timestamp createTime;

    private Timestamp updateTime;

    private Integer deleteFlag;

    private String stackLog;

}