package com.ihomefnt.mobile.domain.hotupdate.dto;

import com.ihomefnt.mobile.common.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-12 15:43
 */
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
public class BasebandVersionDto extends BaseEntity {

    @ApiModelProperty(value = "操作系统 1:ios 2:android", required = true)
    private Integer osType;

    @ApiModelProperty(value = "版本号")
    private Integer basebandVersion;

    @ApiModelProperty(value = "版本说明")
    private String remark;

}
