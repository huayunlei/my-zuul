package com.ihomefnt.mobile.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.mobile.common.BasePageRequest;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.domain.app.App;
import com.ihomefnt.mobile.domain.app.vo.AppVo;
import com.ihomefnt.mobile.domain.appversion.AppVersion;
import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import com.ihomefnt.mobile.domain.module.AppModule;
import com.ihomefnt.mobile.domain.module.vo.AppModuleVo;
import com.ihomefnt.mobile.mapper.AppModuleMapper;
import com.ihomefnt.mobile.service.AppBundleRecordService;
import com.ihomefnt.mobile.service.AppModuleService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-26 10:53
 */
@Service
public class AppModuleServiceImpl extends ServiceImpl<AppModuleMapper, AppModule> implements AppModuleService {

    @Resource
    private AppModuleMapper appModuleMapper;

    @Resource
    private AppBundleRecordService appBundleRecordService;

    /**
     * 根据appId 查询所有模块
     *
     * @param appId appId
     * @return 模块列表
     */
    @Override
    public List<AppModule> queryModuleList(String appId) {
        QueryWrapper<AppModule> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppModule::getAppId, appId);
        return appModuleMapper.selectList(queryWrapper);
    }

    /**
     * 模块列表
     * @param request 分页条件
     * @return 模块列表
     */
    @Override
    public PageResponse<AppModuleVo> queryPage(BasePageRequest request) {
        PageResponse<AppModuleVo> response = new PageResponse<>();

        //查询app下面的module
        QueryWrapper<AppModule> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppModule::getAppId,request.getAppId());

        Page<AppModule> appVersionIPage = new Page<>(request.getPageNo(), request.getPageSize());
        IPage<AppModule> page = appModuleMapper.selectPage(appVersionIPage, queryWrapper);

        List<AppModuleVo> appVoList = page.getRecords().stream().map(appModule -> {
            AppModuleVo appModuleVo = appModule.transform(AppModuleVo.class);
            AppBundleRecord appBundleRecord = appBundleRecordService.queryLatestBundle(appModule.getModuleCode());
            if (appBundleRecord != null) {
                appModuleVo.setBaseVersion(appBundleRecord.getBaseAppVersion());
                appModuleVo.setVersion(appBundleRecord.getVersionCode());
                appModuleVo.setIsRelease(appBundleRecord.getIsRelease());
                appModuleVo.setUpdateTime(appBundleRecord.getCreateTime());
            }
            return appModuleVo;
        }).collect(toList());
        response.setTotalPage(page.getPages());
        response.setTotalCount(page.getTotal());
        response.setPageNo(request.getPageNo());
        response.setPageSize(request.getPageSize());
        response.setList(appVoList);
        return response;
    }
}
