package com.ihomefnt.mobile.domain.hotupdate.dto;

import com.ihomefnt.mobile.common.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-12 15:43
 */
@Data
@ApiModel("分页查询请求参数")
@EqualsAndHashCode(callSuper = true)
public class QueryBaseBandPageDto extends BaseEntity {

    @ApiModelProperty("应用唯一码")
    private String appId;

    @ApiModelProperty(value = "页码")
    private int pageNo = 1;

    @ApiModelProperty(value = "每页记录数")
    private int pageSize = 30;

    @ApiModelProperty(value = "设备类型,1:iPhone客户端，2:Android客户端")
    private Integer osType;

}
