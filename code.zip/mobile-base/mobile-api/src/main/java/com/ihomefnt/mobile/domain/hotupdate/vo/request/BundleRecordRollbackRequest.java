package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-25 16:26
 */
@ApiModel(description = "BundleRecordRollbackRequest")
@Data
@Accessors(chain = true)
public class BundleRecordRollbackRequest extends BaseRequest {

    @ApiModelProperty(value = "bundleRecordId")
    private Integer bundleRecordId;
}
