package com.ihomefnt.mobile.domain.appversion.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-23 20:00
 */
@Data
public class PutAwayDto {

    @ApiModelProperty(value = "记录id", required = true)
    private Integer id;
}
