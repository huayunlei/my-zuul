package com.ihomefnt.mobile.domain.hotupdate.po;

import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-12 17:54
 */
@Data
@Accessors(chain = true)
public class AppBundleRecordList {
    private Integer baseAppVersion;
    private String moduleCode;
    private List<AppBundleRecord> records;
}
