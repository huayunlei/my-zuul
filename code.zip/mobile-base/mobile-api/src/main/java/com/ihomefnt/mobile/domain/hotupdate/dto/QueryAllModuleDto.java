package com.ihomefnt.mobile.domain.hotupdate.dto;

import com.ihomefnt.mobile.common.BaseRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.annotation.Resource;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-26 11:27
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class QueryAllModuleDto extends BaseRequest {

    @Resource
    private Integer appVersionCode;
}
