package com.ihomefnt.mobile.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-24 13:54
 */

@Data
@ApiModel("分页查询请求参数")
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
public class BasePageRequest extends BaseRequest {

    @ApiModelProperty(value = "页码")
    private int pageNo = 0;

    @ApiModelProperty(value = "每页记录数")
    private int pageSize = 30;

    @ApiModelProperty(value = "基带版本号")
    private Integer basebandVersion;

}
