package com.ihomefnt.mobile.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ihomefnt.mobile.domain.group.AppGroup;

public interface AppGroupMapper extends BaseMapper<AppGroup> {
}
