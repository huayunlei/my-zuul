package com.ihomefnt.mobile.domain.monitor.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Accessors(chain = true)
@ApiModel("AppMonitorConfigVo")
public class AppMonitorConfigVo{

    @ApiModelProperty("id")
    private Integer id;

    /**
     * appId
     */
    @ApiModelProperty("appId")
    private String appId;

    /**
     * appName
     */
    @ApiModelProperty("appName")
    private String appName;

    /**
     * 监控来源类型：1，o2o监控；2，wcm监控；3，sky监控；4，通用监控；5，collector监控
     */
    @ApiModelProperty("监控来源类型：1，o2o监控；2，wcm监控；3，sky监控；4，通用监控；5，collector监控")
    private int monitorType;

    /**
     * 监控业务key
     */
    @ApiModelProperty("监控业务key")
    private String monitorKey;

    /**
     * 告警等级
     */
    @ApiModelProperty("告警等级（高，中，低）")
    private String monitorLevel;

    /**
     * 告警信息
     */
    @ApiModelProperty("告警信息")
    private String monitorDesc;

    /**
     * 钉钉告警群名称
     */
    @ApiModelProperty("钉钉告警群名称")
    private String monitorDingName;

    /**
     * 钉钉群token
     */
    @ApiModelProperty("钉钉群token")
    private String monitorDingToken;

    /**
     * 删除标志（0未删除  1已删除）
     */
    @ApiModelProperty("删除标志（0未删除  1已删除）")
    private Integer delFlag;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    @ApiModelProperty("更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

}
