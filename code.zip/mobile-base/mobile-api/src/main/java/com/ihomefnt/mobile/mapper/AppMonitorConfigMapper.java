package com.ihomefnt.mobile.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ihomefnt.mobile.domain.monitor.AppMonitorConfigPo;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-27 14:02
 */
public interface AppMonitorConfigMapper extends BaseMapper<AppMonitorConfigPo> {
}
