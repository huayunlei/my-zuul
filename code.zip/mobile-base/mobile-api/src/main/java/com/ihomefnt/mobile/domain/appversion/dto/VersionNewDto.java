/*
 * Copyright (C) 2006-2016 AiJia All rights reserved
 * Author: zhang
 * Date: 2017年6月20日
 * Description:VersionDto.java 
 */
package com.ihomefnt.mobile.domain.appversion.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@ApiModel("APP版本管理（新）")
@Data
public class VersionNewDto implements Serializable {

	@ApiModelProperty("主键")
	private Long vId;

	@ApiModelProperty("应用唯一码")
	private String appId;

	@ApiModelProperty("版本号")
	private String version;

	@ApiModelProperty("版本描述（版本号百进制转换为int）")
	private Integer versionComment;

	@ApiModelProperty("渠道编号")
	private String partnerValue = "0";

	@ApiModelProperty("下载地址")
	private String download;

	@ApiModelProperty("更新描述")
	private String updateContent;

	@ApiModelProperty("app类型")
	private Integer type;

	@ApiModelProperty("添加人")
	private Integer opUid;

	@ApiModelProperty("强更标记")
	private Integer updateFlag;

	@ApiModelProperty("创建时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime createTime;

	@ApiModelProperty("更新时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime updateTime;

	@ApiModelProperty("删除标记位")
	private Integer delFlag;


	
}
