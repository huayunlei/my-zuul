package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseCodeEnum;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.common.constant.MessageConstant;
import com.ihomefnt.mobile.domain.monitor.vo.*;
import com.ihomefnt.mobile.service.AppMonitorConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-26 14:19
 */
@RestController
@Api(description = "app告警配置相关API")
@RequestMapping("/monitorConfig")
public class AppMonitorConfigController {

    @Autowired
    private AppMonitorConfigService appMonitorConfigService;

    @PostMapping("/add")
    @ApiOperation("添加")
    public ResponseVo<Integer> add(@RequestBody CreateMonitorConfigRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId()) || StringUtils.isBlank(request.getMonitorKey())
                || StringUtils.isBlank(request.getMonitorDingToken())) {
            return ResponseVo.buildResponse(ResponseCodeEnum.DATA_TRANSFER_EMPTY);
        }
        return appMonitorConfigService.add(request);
    }

    @PostMapping("/update")
    @ApiOperation("更新")
    public ResponseVo<Integer> update(@RequestBody UpdateMonitorConfigRequest request) {
        if (request == null || null == request.getId()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.DATA_TRANSFER_EMPTY);
        }
        return appMonitorConfigService.update(request);
    }

    @PostMapping("/detailById")
    @ApiOperation("根据id查询详情")
    public ResponseVo<AppMonitorConfigVo> detailById(@RequestBody DetailMonitorConfigRequest request) {
        if (null == request || null == request.getId()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.DATA_TRANSFER_EMPTY);
        }
        return appMonitorConfigService.detailById(request.getId());
    }

    @PostMapping("/deleteById")
    @ApiOperation("根据id删除")
    public ResponseVo<Integer> deleteById(@RequestBody DeleteMonitorConfigRequest request) {
        if (null == request || null == request.getId()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.DATA_TRANSFER_EMPTY);
        }
        return appMonitorConfigService.deleteById(request.getId());
    }

    @PostMapping("/queryPage")
    @ApiOperation("分页查询")
    public ResponseVo<PageResponse<AppMonitorConfigVo>> queryPage(@RequestBody PageMonitorConfigRequest pageMonitorConfigRequest) {
        PageResponse<AppMonitorConfigVo> pageResponse = appMonitorConfigService.queryPage(pageMonitorConfigRequest);
        return ResponseVo.success(pageResponse);
    }

    @PostMapping("/queryByCondition")
    @ApiOperation("条件查询")
    public ResponseVo<AppMonitorConfigVo> queryByCondition(@RequestBody QueryMonitorConfigConditionRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId()) || StringUtils.isBlank(request.getMonitorKey())) {
            return ResponseVo.fail(MessageConstant.DATA_TRANSFER_EMPTY);
        }
        return appMonitorConfigService.queryByCondition(request);
    }
}
