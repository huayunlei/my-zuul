package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.account.Account;
import com.ihomefnt.mobile.domain.account.dto.LoginDto;
import com.ihomefnt.mobile.domain.account.vo.AccountVo;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-12 10:36
 */
public interface AccountService extends IService<Account> {

    ResponseVo<AccountVo> login(LoginDto loginDto);
}
