package com.ihomefnt.mobile.constant.hotupdate;

/**
 * @author xiamingyu
 */

public enum BundleCreateEnum {

    SUCCESS(1,"成功"),
    NOT_EXIST(1031,"未查询到模块信息"),
    INCREMENTAL_FAILED(1032,"创建增量更新失败"),
    GET_MD5_ERROR(1033,"获取文件MD5出错"),
    GET_NEED_DIFF_ERROR(1034,"获取需要增量更新的低版本出错");

    private Integer code;

    private String msg;


    BundleCreateEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static BundleCreateEnum getEnumByCode(int code){
        BundleCreateEnum[] values = values();
        for (BundleCreateEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }


    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
