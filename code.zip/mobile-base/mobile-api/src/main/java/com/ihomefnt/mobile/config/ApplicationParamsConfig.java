package com.ihomefnt.mobile.config;

import com.alibaba.nacos.api.config.annotation.NacosValue;
import com.ihomefnt.common.util.StringUtil;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * @author xiamingyu
 */
@Component
public class ApplicationParamsConfig {
	
	/**
	 * 网关接口请求的有效时间（单位：秒）
	 */
	@NacosValue(value = "${server.api.timeout}", autoRefreshed = true)
	private long serverApiTimeout;

	/**
	 * bundle更新手机号白名单
	 */
	@NacosValue(value = "${bundle.update.mobile.white.lists}", autoRefreshed = true)
	private String bundleUpdateMobileWhiteLists;

	public boolean containMobile(String mobileNum) {
		if (StringUtil.isBlank(mobileNum)) {
			return false;
		}
		if (StringUtil.isBlank(this.bundleUpdateMobileWhiteLists)) {
			return false;
		}

		List<String> list = Arrays.asList(this.bundleUpdateMobileWhiteLists.split(","));
		return list.contains(mobileNum);
	}

	public String getBundleUpdateMobileWhiteLists() {
		return bundleUpdateMobileWhiteLists;
	}

	public void setBundleUpdateMobileWhiteLists(String bundleUpdateMobileWhiteLists) {
		this.bundleUpdateMobileWhiteLists = bundleUpdateMobileWhiteLists;
	}

	public long getServerApiTimeout() {
		return serverApiTimeout*1000;
	}

	public void setServerApiTimeout(long serverApiTimeout) {
		this.serverApiTimeout = serverApiTimeout;
	}
	
	
}
