package com.ihomefnt.mobile.domain.appversion;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ihomefnt.mobile.common.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-18 15:24
 */
@Data
@Accessors(chain = true)
@TableName("t_app_version")
@EqualsAndHashCode(callSuper = true)
public class AppVersion extends BaseEntity {

    @TableId(value = "v_id", type = IdType.AUTO)
    private Long vId;

    /**
     * appId
     */
    private String appId;

    /**
     * 版本号
     */
    private String version;

    /**
     * 版本说明
     */
    private Integer versionComment;

    /**
     * 商城id,apk会上传到对应商城
     */
    private String partnerValue = "0";

    /**
     * 下载地址
     */
    private String download;

    /**
     * 更新内容
     */
    private String updateContent;

    /**
     * 基础运行环境
     */
    private Integer baseAppVersion;

    /**
     * APP类型：1安卓、2iOS
     */
    private Integer type;

    /**
     * 添加人
     */
    private Integer opUid;

    /**
     * 强制更新标志（0不更新  1更新）
     */
    private Integer updateFlag;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 删除标志（0未删除  1已删除）
     */
    private Integer delFlag;

    /**
     * 上架标记 0 未上架 1已上架
     */
    private Integer putAwayState;

    /**
     * IOS download 地址
     */
    private String ipaDownloadUrl;

    /**
     * 操作人
     */
    private String operator;
}
