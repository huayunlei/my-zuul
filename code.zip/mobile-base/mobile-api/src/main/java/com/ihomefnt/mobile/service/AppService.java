package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.app.App;
import com.ihomefnt.mobile.domain.app.dto.CreateAppDto;
import com.ihomefnt.mobile.domain.app.dto.QueryAppDto;
import com.ihomefnt.mobile.domain.app.dto.QueryAppPageDto;
import com.ihomefnt.mobile.domain.app.dto.UpdateAppDto;
import com.ihomefnt.mobile.domain.app.vo.AppDetailVo;
import com.ihomefnt.mobile.domain.app.vo.AppVo;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryBaseBandDto;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author xiamingyu
 */
public interface AppService extends IService<App> {

    ResponseVo createApp(CreateAppDto request);

    PageResponse<AppVo> queryPage(QueryAppPageDto pageDto);

    void ipa(String appId, String appVersion, HttpServletResponse response);

    ResponseVo updateApp(UpdateAppDto appDto);

    AppDetailVo queryDetail(String appId);

    void delete(String appId);

    List<AppVo> queryList(QueryAppDto pageDto);

    void downloadCount(String appId);

    List<AppVo> queryListByBaseband(QueryBaseBandDto baseBandDto);
}
