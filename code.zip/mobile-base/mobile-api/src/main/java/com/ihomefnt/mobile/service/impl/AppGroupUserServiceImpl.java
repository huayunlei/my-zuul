package com.ihomefnt.mobile.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.mobile.domain.group.AppGroupUser;
import com.ihomefnt.mobile.mapper.AppGroupUserMapper;
import com.ihomefnt.mobile.service.AppGroupUserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
public class AppGroupUserServiceImpl extends ServiceImpl<AppGroupUserMapper, AppGroupUser> implements AppGroupUserService {

    @Resource
    private AppGroupUserMapper appGroupUserMapper;

    @Override
    public List<Integer> selectAllGroupIdByUserId(Integer userId) {
        QueryWrapper<AppGroupUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppGroupUser::getUserId,userId);
        List<AppGroupUser> appGroupUserList = appGroupUserMapper.selectList(queryWrapper);
        return appGroupUserList.stream().map(AppGroupUser::getGroupId).collect(toList());
    }
}
