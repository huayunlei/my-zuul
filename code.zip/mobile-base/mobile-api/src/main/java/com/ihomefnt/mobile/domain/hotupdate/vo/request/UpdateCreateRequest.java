package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * @author xiamingyu
 * @date 2018/12/13
 */

@Data
@Accessors(chain = true)
@ApiModel(description = "创建更新")
@EqualsAndHashCode(callSuper = true)
public class UpdateCreateRequest extends BaseRequest {

    @ApiModelProperty("平台")
    private String platform;

    @ApiModelProperty(value = "模块唯一码")
    private String moduleCode;

    @ApiModelProperty(value = "模块名称")
    private String moduleName;

    @ApiModelProperty(value = "模块版本号")
    private Integer versionCode;

    @ApiModelProperty(value = "APP基带版本")
    private Integer baseAppVersion;

    @ApiModelProperty(value = "更新模式：1全量，2增量")
    private Integer updateFlag;

    @ApiModelProperty(value = "提醒方式：1静默，2弹窗")
    private Integer remindMode;

    @ApiModelProperty(value = "全量下载地址")
    private String fullDownloadUrl;

    @ApiModelProperty(value = "更新标题")
    private String updateTitle;

    @ApiModelProperty(value = "更新描述")
    private String updateDesc;

    @ApiModelProperty(value = "是否发布 0未发布，1已发布")
    private int isRelease;

}
