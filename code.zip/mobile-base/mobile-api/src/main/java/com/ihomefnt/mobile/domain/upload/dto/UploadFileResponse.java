package com.ihomefnt.mobile.domain.upload.dto;

/**
 * @author xiamingyu
 * @date 2018/12/24
 */

public class UploadFileResponse {

    private Integer fileId;

    private String fileUrl;

    public Integer getFileId() {
        return fileId;
    }

    public void setFileId(Integer fileId) {
        this.fileId = fileId;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }
}
