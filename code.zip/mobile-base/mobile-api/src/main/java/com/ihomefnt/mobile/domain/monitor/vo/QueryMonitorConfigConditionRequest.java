package com.ihomefnt.mobile.domain.monitor.vo;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-30 15:05
 */
@ApiModel("QueryMonitorConfigConditionRequest")
@Data
public class QueryMonitorConfigConditionRequest extends BaseRequest {

    @ApiModelProperty("监控业务配置key")
    private String monitorKey;
}
