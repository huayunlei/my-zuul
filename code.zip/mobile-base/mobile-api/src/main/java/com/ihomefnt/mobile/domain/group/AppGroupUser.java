package com.ihomefnt.mobile.domain.group;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ihomefnt.mobile.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Accessors(chain = true)
@TableName("t_app_group_user")
@EqualsAndHashCode(callSuper = true)
public class AppGroupUser extends BaseEntity {

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 组id
     */
    private Integer groupId;

    /**
     * 用户Id
     */
    private Integer userId;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}
