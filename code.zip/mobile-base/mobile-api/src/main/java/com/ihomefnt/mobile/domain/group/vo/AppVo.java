package com.ihomefnt.mobile.domain.group.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AppVo {

    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty(value = "appId")
    private String appId;

    @ApiModelProperty(value = "app名称")
    private String appName;

    @ApiModelProperty(value = "图标")
    private String icon;

    @ApiModelProperty(value = "分发地址")
    private String url;

    @ApiModelProperty(value = "app类型  1:IOS 2:Android")
    private Integer appType;

    @ApiModelProperty(value = "来源 1: mop 2:其他来源")
    private Integer source;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "更新时间")
    private LocalDateTime updateTime;
}
