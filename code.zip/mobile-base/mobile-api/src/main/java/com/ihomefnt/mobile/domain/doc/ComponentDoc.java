package com.ihomefnt.mobile.domain.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ihomefnt.mobile.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 13:58
 */

@Data
@Accessors(chain = true)
@TableName("t_component_doc")
@EqualsAndHashCode(callSuper = true)
public class ComponentDoc extends BaseEntity {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 组件名称
     */
    private String componentName;

    /**
     * 组件描述
     */
    private String componentDescription;

    /**
     * 组件类型
     */
    private String componentType;

    /**
     * 组件分类
     */
    private String componentCategory;

    /**
     * 组件适用文档
     */
    private String componentDoc;

    /**
     * 组件适用平台
     */
    private String componentPlatform;
}
