package com.ihomefnt.mobile.domain.upload.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.File;

/**
 * @author xiamingyu
 * @date 2018/12/24
 */

@Data
@Accessors(chain = true)
public class UploadFileRequest {

    private Integer bucketType;

    private String businessSystemName;

    private File multipartFile;

    private Integer operatorId;

    private String sceneName;

}
