package com.ihomefnt.mobile;

import com.alibaba.nacos.spring.context.annotation.config.NacosPropertySource;
import com.ihomefnt.starter.semporna.EnableSemporna;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author xiamingyu
 */

@SpringBootApplication
@MapperScan("com.ihomefnt.mobile.*.repository")
@EnableSemporna(redis = true)
@NacosPropertySource(dataId = "mobile-api",autoRefreshed = true)
@ComponentScan(basePackages = {"com.ihomefnt.mobile"})
public class MobileApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileApiApplication.class, args);
	}
}
