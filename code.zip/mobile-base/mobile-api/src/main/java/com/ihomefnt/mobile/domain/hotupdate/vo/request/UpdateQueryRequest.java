package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author xiamingyu
 * @date 2018/11/22
 */

@ApiModel(description = "热更新请求参数")
@Data
@Accessors(chain = true)
public class UpdateQueryRequest extends BaseRequest {

    @ApiModelProperty(value = "app版本号")
    private Integer appVersionCode;

    @ApiModelProperty(value = "模块列表")
    private List<ReqModule> modules;

    @ApiModelProperty(value = "用户手机号")
    private String mobileNum;
}
