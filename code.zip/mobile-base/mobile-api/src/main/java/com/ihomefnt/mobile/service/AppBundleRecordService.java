package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;

import java.util.List;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-26 11:16
 */
public interface AppBundleRecordService extends IService<AppBundleRecord> {

    List<AppBundleRecord> queryModuleNewBundleRecord(List<String> moduleList, Integer baseAppVersion);

    AppBundleRecord queryLatestBundle(String moduleCode);
}
