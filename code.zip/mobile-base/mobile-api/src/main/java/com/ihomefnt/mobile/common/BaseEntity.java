package com.ihomefnt.mobile.common;


import com.ihomefnt.mobile.common.utils.BeanUtils;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:28
 */
public class BaseEntity {

    public <T> T transform(Class<T> clazz) {
        return BeanUtils.copyProperties(clazz, this);
    }


    public <T> T transform(T target) {
        BeanUtils.copyProperties(this, target);
        return target;
    }
}
