package com.ihomefnt.mobile.domain.hotupdate.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-24 10:40
 */
@ApiModel(description = "BasebandVersionResponse")
@Data
@Accessors(chain = true)
public class BasebandVersionResponse {

    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "设备类型,1:iPhone客户端，2:Android客户端")
    private Integer osType; // 设备类型,1:iPhone客户端，2:Android客户端

    @ApiModelProperty(value = "基带版本号")
    private Integer basebandVersion;

    @ApiModelProperty(value = "备注描述")
    private String remark;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "有效标识 0可用 ， 1删除")
    private Integer deleteFlag;

}
