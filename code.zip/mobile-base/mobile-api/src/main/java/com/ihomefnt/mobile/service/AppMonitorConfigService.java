package com.ihomefnt.mobile.service;

import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.monitor.vo.*;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-27 11:13
 */
public interface AppMonitorConfigService {
    ResponseVo<Integer> add(CreateMonitorConfigRequest createMonitorConfigRequest);

    ResponseVo<Integer> update(UpdateMonitorConfigRequest updateMonitorConfigRequest);

    ResponseVo<AppMonitorConfigVo> detailById(Integer id);

    PageResponse<AppMonitorConfigVo> queryPage(PageMonitorConfigRequest pageMonitorConfigRequest);

    ResponseVo<Integer> deleteById(Integer id);

    ResponseVo<AppMonitorConfigVo> queryByCondition(QueryMonitorConfigConditionRequest request);
}
