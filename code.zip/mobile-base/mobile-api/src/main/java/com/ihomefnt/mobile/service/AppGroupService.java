package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.group.AppGroup;
import com.ihomefnt.mobile.domain.group.dto.*;
import com.ihomefnt.mobile.domain.group.vo.AppGroupDetailVo;
import com.ihomefnt.mobile.domain.group.vo.AppGroupVo;
import com.ihomefnt.mobile.domain.group.vo.AppVo;

import java.util.List;


public interface AppGroupService extends IService<AppGroup> {

    PageResponse<AppGroupVo> queryPage(AppGroupPageDto pageDto);

    ResponseVo<String> add(AddAppGroupDto addAppGroupDto);

    ResponseVo<String> addApp(AddAppDto addAppDto);

    List<AppVo> queryAppList(QueryAppDto queryAppDto);

    ResponseVo<String> deleteApp(DeleteAppDto deleteAppDto);

    AppGroupDetailVo detail(QueryAppDto queryAppDto);

    ResponseVo<String> updateApp(UpdateAppDto appDto);
}
