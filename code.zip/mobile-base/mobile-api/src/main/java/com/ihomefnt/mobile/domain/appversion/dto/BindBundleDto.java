package com.ihomefnt.mobile.domain.appversion.dto;

import com.ihomefnt.mobile.common.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-10-11 16:51
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BindBundleDto extends BaseEntity {

    @ApiModelProperty(value = "模块名称", required = true)
    private String moduleName;

    @ApiModelProperty(value = "模块编码", required = true)
    private String moduleCode;

    @ApiModelProperty(value = "模块版本号", required = true)
    private Integer versionCode;

    @ApiModelProperty(value = "下载地址", required = true)
    private String fullDownloadUrl;
}
