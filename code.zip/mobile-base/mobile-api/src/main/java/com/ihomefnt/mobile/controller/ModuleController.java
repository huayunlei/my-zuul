package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.BasePageRequest;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.module.vo.AppModuleVo;
import com.ihomefnt.mobile.service.AppModuleService;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/module")
public class ModuleController {

    @Resource
    private AppModuleService appModuleService;

    @ApiOperation("模块列表")
    @PostMapping("/query-page")
    public ResponseVo<PageResponse<AppModuleVo>> queryPage(@RequestBody BasePageRequest request){
        return ResponseVo.success(appModuleService.queryPage(request));
    }
}
