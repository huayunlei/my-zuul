package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.doc.ComponentDoc;
import com.ihomefnt.mobile.domain.doc.dto.AddComponentDto;
import com.ihomefnt.mobile.domain.doc.dto.ModifyComponentDto;
import com.ihomefnt.mobile.domain.doc.dto.QueryComponentDto;
import com.ihomefnt.mobile.domain.doc.vo.ComponentDocDetailVo;
import com.ihomefnt.mobile.domain.doc.vo.ComponentDocVo;

import java.util.List;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:09
 */
public interface ComponentDocService extends IService<ComponentDoc> {

    ResponseVo<List<ComponentDocVo>> queryList(QueryComponentDto queryDto);

    ResponseVo add(AddComponentDto componentDto);

    ResponseVo modify(ModifyComponentDto componentDto);

    ResponseVo<ComponentDocDetailVo> queryDetail(Integer id);
}
