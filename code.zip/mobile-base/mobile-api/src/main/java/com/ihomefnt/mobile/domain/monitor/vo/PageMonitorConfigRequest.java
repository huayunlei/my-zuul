package com.ihomefnt.mobile.domain.monitor.vo;

import com.ihomefnt.mobile.common.BasePageRequest;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-27 13:53
 */
@Data
@ApiModel("PageMonitorConfigRequest")
public class PageMonitorConfigRequest extends BasePageRequest {
}
