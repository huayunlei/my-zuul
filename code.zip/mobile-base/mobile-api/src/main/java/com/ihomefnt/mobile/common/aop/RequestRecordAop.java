package com.ihomefnt.mobile.common.aop;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ihomefnt.common.util.StringUtil;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.io.Serializable;

/**
 * @author onefish
 * @date 2018/9/28 0028.
 */
@Configuration
@Aspect
public class RequestRecordAop {

    private static Logger logger = LoggerFactory.getLogger(RequestRecordAop.class);
    private static ObjectMapper objectMapper = new ObjectMapper();

    /**
     * controller的切面
     */
    @Pointcut("within(@org.springframework.stereotype.Controller *)")
    public void controllerPointcut() {
    }

    /**
     * RestController的切面
     */
    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    public void restControllerPointcut() {
    }

    @Around("(controllerPointcut()|| restControllerPointcut())")
    public Object recordRequest(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Object[] args = joinPoint.getArgs();

        //方法名称
        final String methodName = signature.getMethod().getName();
        final String className = signature.getDeclaringTypeName();
        String simpleClassName = className.substring(className.lastIndexOf(".")+1);
        Object result = null;
        Exception e = null;
        String paramsJson = null;
        try {
            paramsJson = preHandle(args);
            if (!"CheckController".equals(simpleClassName)) {
                logger.info(simpleClassName + "." + methodName +" begin params:{}", paramsJson);
            }
            result = joinPoint.proceed();
        } catch (Exception ex) {
            e = ex;
        } finally {
            try {
                if (e != null) {
                    result = CustomerExceptionHandler.handlerCustomerExcelption(e,signature.getMethod());
                }
                if (!"CheckController".equals(simpleClassName)) {
                    logger.info(simpleClassName + "." + methodName +" end params:{}, result:{}", paramsJson, postHandle(result));
                }
            } catch (Exception ignore) {
            }
        }
        
        return result;
    }

    /**
     * 入参数据
     * @param paramsArray
     * @return
     */
    private String preHandle(Object[] paramsArray) {
        StringBuffer params = new StringBuffer();
        if (paramsArray != null && paramsArray.length > 0) {
            for (int i = 0; i < paramsArray.length; i++) {
                if (paramsArray[i] instanceof Serializable) {
                    params.append(paramsArray[i].toString()).append(",");
                } else {
                    try {
                        String param= objectMapper.writeValueAsString(paramsArray[i]);
                        if(StringUtils.isNotBlank(param))
                            params.append(param).append(",");
                    } catch (JsonProcessingException e) {
                    }
                }
            }
        }else {
            return null;
        }
        String s = params.toString();
        if (StringUtil.isBlank(s)) {
            return null;
        }
        return s.substring(0,s.length()-1);
    }

    /**
     * 返回数据
     * @param retVal
     * @return
     */
    private String postHandle(Object retVal) {
        if(null == retVal){
            return "";
        }
        return JSON.toJSONString(retVal);
    }
}
