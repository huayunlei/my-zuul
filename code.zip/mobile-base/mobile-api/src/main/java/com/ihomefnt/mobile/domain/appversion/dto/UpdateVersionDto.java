package com.ihomefnt.mobile.domain.appversion.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class UpdateVersionDto {

    @ApiModelProperty(value = "vId",required = true)
    private Integer vId;

    @ApiModelProperty(value = "版本号",required = true)
    private String version;

    @ApiModelProperty(value = "是否强更：1:是 0:否",required = true)
    private Integer updateFlag;

    @ApiModelProperty(value = "是否强更：1:是 0:否",required = true)
    private List<String> updateContent;

    @ApiModelProperty(value = "基础版本",required = true)
    private Integer baseAppVersion;
}
