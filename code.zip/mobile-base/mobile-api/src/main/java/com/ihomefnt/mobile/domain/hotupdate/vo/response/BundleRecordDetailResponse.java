package com.ihomefnt.mobile.domain.hotupdate.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @author xiamingyu
 */
@ApiModel(description = "BundleRecordDetailResponse")
@Data
@Accessors(chain = true)
public class BundleRecordDetailResponse {

    private Integer id;

    @ApiModelProperty(value = "模块唯一码")
    private String moduleCode;

    @ApiModelProperty(value = "模块名称")
    private String versionName;

    @ApiModelProperty(value = "模块版本号")
    private Integer versionCode;

    @ApiModelProperty(value = "APP基带版本")
    private Integer baseAppVersion;

    @ApiModelProperty(value = "更新模式：1全量，2增量")
    private Integer updateFlag;

    @ApiModelProperty(value = "提醒方式：1静默，2弹窗")
    private Integer remindMode;

    @ApiModelProperty(value = "下载地址")
    private String downloadUrl;

    @ApiModelProperty(value = "文件md5")
    private String fileMd5;

    @ApiModelProperty(value = "更新标题")
    private String updateTitle;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(value = "0可用 ， 1删除")
    private Integer deleteFlag;

    @ApiModelProperty(value = "更新描述")
    private String updateDesc;

    @ApiModelProperty(value = "是否发布 0未发布，1已发布")
    private int isRelease;

}