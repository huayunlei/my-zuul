package com.ihomefnt.mobile.domain.app.dto;

import com.ihomefnt.mobile.common.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class QueryAppPageDto extends BasePageRequest {

    @ApiModelProperty(value = "用户Id", required = true)
    private Integer userId;

    @ApiModelProperty(value = "app名称", required = true)
    private String appName;

}
