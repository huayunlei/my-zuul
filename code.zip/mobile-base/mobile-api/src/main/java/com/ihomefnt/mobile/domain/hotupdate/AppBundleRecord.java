package com.ihomefnt.mobile.domain.hotupdate;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ihomefnt.mobile.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author xiamingyu
 */

@Data
@Accessors(chain = true)
@TableName("t_app_bundle_record")
@EqualsAndHashCode(callSuper = true)
public class AppBundleRecord extends BaseEntity {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;


    private String moduleCode;


    private String versionName;


    private Integer versionCode;


    private Integer baseAppVersion;


    private Integer updateFlag;


    private Integer remindMode;


    private String downloadUrl;


    private String fileMd5;


    private String updateTitle;


    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;


    private Integer deleteFlag;


    private String updateDesc;

    // 是否发布 0未发布，1已发布
    private int isRelease;

}