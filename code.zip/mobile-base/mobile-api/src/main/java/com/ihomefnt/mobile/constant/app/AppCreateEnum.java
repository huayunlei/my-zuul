package com.ihomefnt.mobile.constant.app;

/**
 * @author xiamingyu
 */

public enum AppCreateEnum {

    SUCCESS(1,"成功"),
    CREATE_FAILED(2011,"创建APP失败");

    private Integer code;

    private String msg;


    AppCreateEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static AppCreateEnum getEnumByCode(int code){
        AppCreateEnum[] values = values();
        for (AppCreateEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }


    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
