package com.ihomefnt.mobile.common.utils;

/**
 * @description:
 * @auther: 何佳文
 * @date: 2018/11/22 15:19
 */
public class BeanUtils {

    public static <T> T copyProperties(Class<T> clazz, Object source) throws RuntimeException {
        try {
            Object result = clazz.getDeclaredConstructor().newInstance();
            org.springframework.beans.BeanUtils.copyProperties(source, result);
            return (T) result;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public static <T> void copyProperties(Object source, T target) throws RuntimeException {
        try {
            org.springframework.beans.BeanUtils.copyProperties(source, target);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
