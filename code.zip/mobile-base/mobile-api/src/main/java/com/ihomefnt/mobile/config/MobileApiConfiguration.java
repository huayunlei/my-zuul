package com.ihomefnt.mobile.config;

import com.ihomefnt.common.util.ServiceLocator;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import redis.clients.jedis.JedisPool;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-12 14:20
 */
@Configuration
public class MobileApiConfiguration implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowCredentials(true)
                .allowedHeaders("*")
                .allowedOrigins("*")
                .allowedMethods("*");

    }

    @Bean(name = "serviceLocator")
    public ServiceLocator serviceLocator() {
        return ServiceLocator.init();
    }

    @Value("${spring.redis.host}")
    private String redisHost;

    @Value("${spring.redis.port}")
    private Integer redisPort;

    @Value("${spring.redis.password}")
    private String redisPassword;


    @DependsOn("serviceLocator")
    @Bean(name = "jedisPool")
    public JedisPool jedisPool() {
        GenericObjectPoolConfig pc = new GenericObjectPoolConfig();
        pc.setMaxIdle(300);
        pc.setMaxTotal(60000);
        pc.setTestOnBorrow(true);
        return new JedisPool(pc, redisHost, redisPort,2000,redisPassword);
    }
}
