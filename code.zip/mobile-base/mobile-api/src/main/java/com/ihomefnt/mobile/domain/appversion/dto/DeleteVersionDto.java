package com.ihomefnt.mobile.domain.appversion.dto;

import lombok.Data;

import java.util.List;

@Data
public class DeleteVersionDto {

    private List<Integer> ids;
}
