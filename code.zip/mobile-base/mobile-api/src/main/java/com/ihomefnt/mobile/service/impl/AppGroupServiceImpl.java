package com.ihomefnt.mobile.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.group.AppGroup;
import com.ihomefnt.mobile.domain.group.AppGroupRelation;
import com.ihomefnt.mobile.domain.group.dto.*;
import com.ihomefnt.mobile.domain.group.vo.AppGroupDetailVo;
import com.ihomefnt.mobile.domain.group.vo.AppGroupVo;
import com.ihomefnt.mobile.domain.group.vo.AppVo;
import com.ihomefnt.mobile.mapper.AppGroupMapper;
import com.ihomefnt.mobile.mapper.AppGroupRelationMapper;
import com.ihomefnt.mobile.service.AppGroupService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;

import static java.util.stream.Collectors.toList;


@Service
public class AppGroupServiceImpl extends ServiceImpl<AppGroupMapper, AppGroup> implements AppGroupService {

    @Resource
    private AppGroupMapper appGroupMapper;

    @Resource
    private AppGroupRelationMapper appGroupRelationMapper;

    /**
     * 查询组列表
     *
     * @param pageDto 分页查询参数
     * @return 组列表
     */
    @Override
    public PageResponse<AppGroupVo> queryPage(AppGroupPageDto pageDto) {

        PageResponse<AppGroupVo> response = new PageResponse<>();

        QueryWrapper<AppGroup> queryWrapper = new QueryWrapper<>();
        if (!StringUtils.isEmpty(pageDto.getName())) {
            queryWrapper.lambda().like(AppGroup::getName, pageDto.getName());
        }
        Page<AppGroup> appGroupPage = new Page<>(pageDto.getPageNo(), pageDto.getPageSize());
        appGroupPage.setDesc("create_time");
        IPage<AppGroup> page = appGroupMapper.selectPage(appGroupPage, queryWrapper);
        List<AppGroupVo> appVoList = page.getRecords().stream().map(group -> group.transform(AppGroupVo.class)).collect(toList());
        response.setTotalPage(page.getPages());
        response.setTotalCount(page.getTotal());
        response.setPageNo(pageDto.getPageNo());
        response.setPageSize(pageDto.getPageSize());
        response.setList(appVoList);
        return response;
    }

    /**
     * 新增组
     *
     * @param addAppGroupDto 组信息
     * @return 添加结果
     */
    @Override
    public ResponseVo<String> add(AddAppGroupDto addAppGroupDto) {
        QueryWrapper<AppGroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppGroup::getName, addAppGroupDto.getName());
        AppGroup appGroup = appGroupMapper.selectOne(queryWrapper);
        if (appGroup != null) {
            return ResponseVo.fail("组已存在");
        }
        appGroup = new AppGroup();
        appGroup.setName(addAppGroupDto.getName())
                .setIcon(addAppGroupDto.getIcon())
                .setCreateTime(LocalDateTime.now())
                .setRemark(addAppGroupDto.getRemark());
        appGroupMapper.insert(appGroup);
        return ResponseVo.success();
    }

    /**
     * 添加app到组内
     *
     * @param addAppDto 添加信息
     * @return 添加结果
     */
    @Override
    public ResponseVo<String> addApp(AddAppDto addAppDto) {
        if (!StringUtils.isEmpty(addAppDto.getAppId())) {
            QueryWrapper<AppGroupRelation> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda()
                    .eq(AppGroupRelation::getGroupId, addAppDto.getGroupId())
                    .eq(AppGroupRelation::getAppId, addAppDto.getAppId());
            AppGroupRelation appGroupRelation = appGroupRelationMapper.selectOne(queryWrapper);
            if (appGroupRelation != null) {
                return ResponseVo.fail("该应用已在组内");
            }
        }
        AppGroupRelation appGroupRelation = addAppDto.transform(AppGroupRelation.class);
        appGroupRelation.setAppId(addAppDto.getAppId())
                .setUpdateTime(LocalDateTime.now())
                .setCreateTime(LocalDateTime.now());
        appGroupRelationMapper.insert(appGroupRelation);
        return ResponseVo.success();
    }

    /**
     * 修改组应用
     * @return 修改结果
     */
    @Override
    public ResponseVo<String> updateApp(UpdateAppDto appDto) {
        AppGroupRelation appGroupRelation = appGroupRelationMapper.selectById(appDto.getId());
        if(appGroupRelation !=null){
            appDto.transform(appGroupRelation).setUpdateTime(LocalDateTime.now());
            appGroupRelationMapper.updateById(appGroupRelation);
            return ResponseVo.success();
        }
        return ResponseVo.fail("信息不正确");
    }

    /**
     * 查询组下面的 app
     *
     * @param queryAppDto 查询条件
     * @return 组下面的 app
     */
    @Override
    public List<AppVo> queryAppList(QueryAppDto queryAppDto) {
        QueryWrapper<AppGroupRelation> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppGroupRelation::getGroupId, queryAppDto.getGroupId());
        return appGroupRelationMapper.selectList(queryWrapper).stream()
                .map(appGroupRelation -> appGroupRelation.transform(AppVo.class)).collect(toList());
    }

    /**
     * 移除应用
     *
     * @param deleteAppDto
     * @return
     */
    @Override
    public ResponseVo<String> deleteApp(DeleteAppDto deleteAppDto) {
        appGroupRelationMapper.deleteBatchIds(deleteAppDto.getRelationIds());
        return ResponseVo.success();
    }

    @Override
    public AppGroupDetailVo detail(QueryAppDto queryAppDto) {
        QueryWrapper<AppGroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppGroup::getGroupId, queryAppDto.getGroupId());
        AppGroup appGroup = appGroupMapper.selectOne(queryWrapper);
        if (appGroup != null) {
            QueryWrapper<AppGroupRelation> groupRelationQueryWrapper = new QueryWrapper<>();
            groupRelationQueryWrapper.lambda().eq(AppGroupRelation::getGroupId, queryAppDto.getGroupId());
            List<AppVo> appList = appGroupRelationMapper.selectList(groupRelationQueryWrapper).stream()
                    .map(appGroupRelation -> appGroupRelation.transform(AppVo.class)).collect(toList());
            AppGroupDetailVo appGroupDetailVo = appGroup.transform(AppGroupDetailVo.class);
            appGroupDetailVo.setApp(appList);
            return appGroupDetailVo;
        }
        return null;
    }
}
