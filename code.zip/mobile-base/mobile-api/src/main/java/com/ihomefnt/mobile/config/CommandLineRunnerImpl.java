package com.ihomefnt.mobile.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * @author xiamingyu
 * @date 2018/12/29
 */

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        System.out.println("mobile-api服务启动成功");
        Runtime run = Runtime.getRuntime();
        try{
            run.exec("sh ./src/main/resources/shell/open_swagger.sh").waitFor();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}