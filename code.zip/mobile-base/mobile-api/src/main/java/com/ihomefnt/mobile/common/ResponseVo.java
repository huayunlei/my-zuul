package com.ihomefnt.mobile.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @description:
 * @author: lichensi
 * @create: 2018-08-17 17:30
 */
@ApiModel(description = "响应内容")
@Data
@Accessors(chain = true)
public class ResponseVo<T> {

    /**
     * 响应代码
     */
    @ApiModelProperty(value = "结果码")
    private Integer code = 1;

    /**
     * 返回消息
     */
    @ApiModelProperty(value = "响应内容")
    private String msg;

    /**
     * 响应数据
     */
    @ApiModelProperty(value = "响应数据")
    private T obj;

    /**
     * 是否成功
     */
    @ApiModelProperty(value = "请求结果")
    private boolean success;

    public ResponseVo(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    private ResponseVo(ResponseCodeEnum responseEnum) {
        this.code = responseEnum.getCode();
        this.msg = responseEnum.getMsg();
        this.success = responseEnum.isSuccess();
    }

    public ResponseVo(int code, boolean result, String msg) {
        this.code = code;
        this.success = result;
        this.msg = msg;
    }

    public static <T> ResponseVo<T> success() {
        return new ResponseVo<>(ResponseCodeEnum.SUCCESS);
    }

    public static <T> ResponseVo<T> success(T obj) {
        ResponseVo<T> responseVo = new ResponseVo<>(ResponseCodeEnum.SUCCESS);
        responseVo.setObj(obj);
        return responseVo;
    }

    public static <T> ResponseVo<T> fail(String failMessage) {
        return new ResponseVo<>(0, false, failMessage);
    }


    public static <T> ResponseVo<T> buildFailedResponse(Integer code, String msg) {
        ResponseVo<T> responseVo = new ResponseVo<>(code, msg);
        responseVo.setSuccess(false);
        return responseVo;
    }

    public static <T> ResponseVo<T> buildResponse(ResponseCodeEnum responseEnum) {
        return new ResponseVo<>(responseEnum);
    }
}