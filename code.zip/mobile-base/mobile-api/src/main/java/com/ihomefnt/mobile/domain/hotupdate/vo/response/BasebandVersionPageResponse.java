package com.ihomefnt.mobile.domain.hotupdate.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-24 17:48
 */
@ApiModel(description = "BasebandVersionPageResponse")
@Data
@Accessors(chain = true)
public class BasebandVersionPageResponse {
    @ApiModelProperty(value = "记录")
    private List<BasebandVersionResponse> records;

    /**
     * 当前页码
     */
    @ApiModelProperty(value = "当前页码")
    private int pageNo;
    /**
     * 总记录数
     */
    @ApiModelProperty(value = "总记录数")
    private int totalCount;
}
