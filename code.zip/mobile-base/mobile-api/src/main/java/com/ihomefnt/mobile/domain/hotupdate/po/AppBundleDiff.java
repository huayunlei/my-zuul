package com.ihomefnt.mobile.domain.hotupdate.po;


import lombok.Data;
import lombok.experimental.Accessors;

import java.sql.Timestamp;

/**
 * @author xiamingyu
 */
@Data
@Accessors(chain = true)
public class AppBundleDiff {

    private Integer id;

    private String moduleCode;

    private Integer mainBundleVersionCode;

    private Integer diffBundleVersionCode;

    private String diffVersionName;

    private String downloadUrl;

    private String fileMd5;

    private Timestamp createTime;

    private Timestamp updateTime;

    private Integer deleteFlag;

}