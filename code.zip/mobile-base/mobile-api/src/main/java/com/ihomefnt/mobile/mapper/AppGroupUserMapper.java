package com.ihomefnt.mobile.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ihomefnt.mobile.domain.group.AppGroupUser;

public interface AppGroupUserMapper extends BaseMapper<AppGroupUser> {
}
