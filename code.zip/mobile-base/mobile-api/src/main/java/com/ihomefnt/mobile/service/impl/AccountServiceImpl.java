package com.ihomefnt.mobile.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.account.Account;
import com.ihomefnt.mobile.domain.account.dto.LoginDto;
import com.ihomefnt.mobile.domain.account.vo.AccountVo;
import com.ihomefnt.mobile.mapper.AccountMapper;
import com.ihomefnt.mobile.service.AccountService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-12 10:37
 */
@Service
public class AccountServiceImpl extends ServiceImpl<AccountMapper, Account> implements AccountService {

    @Resource
    private AccountMapper accountMapper;

    @Override
    public ResponseVo<AccountVo> login(LoginDto loginDto) {
        QueryWrapper<Account> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Account::getUserName, loginDto.getUserName());
        Account account = accountMapper.selectOne(queryWrapper);
        if (account == null) {
            return ResponseVo.fail("账户名错误");
        }
        if (!account.getPassword().equals(loginDto.getPassword())) {
            return ResponseVo.fail("密码不正确");
        }
        AccountVo accountVo = new AccountVo().setId(account.getId());
        return ResponseVo.success(accountVo);
    }
}
