package com.ihomefnt.mobile.domain.doc.dto;

import com.ihomefnt.mobile.common.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:32
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class AddComponentDto extends BaseEntity {

    @ApiModelProperty(value = "组件名称", required = true)
    private String componentName;

    @ApiModelProperty(value = "组件描述", required = true)
    private String componentDescription;

    @ApiModelProperty(value = "组件类型", required = true)
    private String componentType;

    @ApiModelProperty(value = "组件分类", required = true)
    private String componentCategory;

    @ApiModelProperty(value = "组件适用文档", required = true)
    private String componentDoc;

    @ApiModelProperty(value = "组件适用平台", required = true)
    private String componentPlatform;
}
