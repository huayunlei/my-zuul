package com.ihomefnt.mobile.common;

/**
 * 一句话功能简述
 * 功能详细描述
 *
 * @author jiangjun
 * @version 2.0, 2018-04-11 下午3:08
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class BusinessException extends RuntimeException{

    private int code;
    private String message;

    public BusinessException(int code, String message) {
        super(message);
        this.message = message;
        this.code = code;
    }

    public BusinessException(String message) {
        super(message);
        this.code = 2;
    }
    
    
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
