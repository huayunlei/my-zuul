package com.ihomefnt.mobile.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ihomefnt.mobile.domain.hotupdate.BasebandVersion;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-10-08 14:24
 */
public interface BasebandMapper extends BaseMapper<BasebandVersion> {
}
