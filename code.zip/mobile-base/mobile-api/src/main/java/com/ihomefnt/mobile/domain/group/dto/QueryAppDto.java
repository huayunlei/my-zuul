package com.ihomefnt.mobile.domain.group.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class QueryAppDto {

    @ApiModelProperty(value = "组id",required = true)
    private Integer groupId;
}
