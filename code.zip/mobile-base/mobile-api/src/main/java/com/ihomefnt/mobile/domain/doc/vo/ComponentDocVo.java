package com.ihomefnt.mobile.domain.doc.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:22
 */
@Data
public class ComponentDocVo {

    @ApiModelProperty(value = "组件id")
    private Integer id;

    @ApiModelProperty(value = "组件名称")
    private String componentName;

    @ApiModelProperty(value = "组件描述")
    private String componentDescription;

    @ApiModelProperty(value = "组件类型")
    private String componentType;

    @ApiModelProperty(value = "组件分类")
    private String componentCategory;

    @ApiModelProperty(value = "组件适用平台")
    private String componentPlatform;
}
