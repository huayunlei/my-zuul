package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.doc.dto.AddComponentDto;
import com.ihomefnt.mobile.domain.doc.dto.ModifyComponentDto;
import com.ihomefnt.mobile.domain.doc.dto.QueryComponentDto;
import com.ihomefnt.mobile.domain.doc.vo.ComponentDocDetailVo;
import com.ihomefnt.mobile.domain.doc.vo.ComponentDocVo;
import com.ihomefnt.mobile.service.ComponentDocService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:12
 */
@RestController
@Api(description = "文档")
@RequestMapping("/component/doc")
public class ComponentController {

    @Resource
    private ComponentDocService componentDocService;

    @ApiOperation("查询文档列表")
    @GetMapping("/query-list")
    public ResponseVo<List<ComponentDocVo>> queryList(QueryComponentDto queryDto) {
        return componentDocService.queryList(queryDto);
    }

    @ApiOperation("查询文档详情")
    @GetMapping("/query-detail/{id}")
    public ResponseVo<ComponentDocDetailVo> queryDetail(@PathVariable Integer id) {
        return componentDocService.queryDetail(id);
    }

    @ApiOperation("新增文档")
    @PostMapping("/add")
    public ResponseVo add(@RequestBody AddComponentDto componentDto) {
        return componentDocService.add(componentDto);
    }

    @ApiOperation("修改文档")
    @PostMapping("/modify")
    public ResponseVo add(@RequestBody ModifyComponentDto componentDto) {
        return componentDocService.modify(componentDto);
    }
}
