package com.ihomefnt.mobile.proxy.upload.impl;


import com.ihomefnt.common.api.ResponseVo;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.mobile.domain.upload.dto.UploadFileRequest;
import com.ihomefnt.mobile.proxy.upload.IUploadProxy;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;


/**
 * @author xiamingyu
 */
@Service
public class UploadProxyImpl implements IUploadProxy {

    @Resource
    private OkHttpClient okHttpClient;

    @Value("${aladdin.unify.host}")
    private String uploadHost;

    @Override
    public ResponseVo uploadStaticFile(UploadFileRequest uploadFileRequest,String fileName) {
        String url = null;
        try {
            url = uploadHost;
        } catch (Exception e) {
            e.getMessage();
        }
        if (url == null) {
            return null;
        }
        File uploadFile = uploadFileRequest.getMultipartFile();

        try {
            RequestBody fileBody = RequestBody.create(MediaType.parse("application/octet-stream"), uploadFile);

            MultipartBody multipartBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("bucketType",uploadFileRequest.getBucketType().toString())
                    .addFormDataPart("multipartFile",fileName,fileBody)
                    .addFormDataPart("businessSystemName", uploadFileRequest.getBusinessSystemName())
                    .addFormDataPart("sceneName", uploadFileRequest.getSceneName())
                    .build();

            Request request = new Request.Builder()
                    .url(url)
                    .post(multipartBody)
                    .build();

            Response response = okHttpClient.newCall(request).execute();
            HttpStatus httpStatus = HttpStatus.valueOf(response.code());
            String responseBody = response.body().string();
            response.body().close();
            if (httpStatus == HttpStatus.OK) {
                ResponseVo responseVo = JsonUtils.json2obj(responseBody,ResponseVo.class);
                return responseVo;
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return null;
    }
}
