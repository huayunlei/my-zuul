package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author xiamingyu
 * @date 2018/12/26
 */

@ApiModel(description = "查询模块信息")
@Data
@Accessors(chain = true)
public class QueryModuleRequest extends BaseRequest {

    @ApiModelProperty(value = "每页条数")
    private Integer pageSize;

    @ApiModelProperty("查询的页码")
    private Integer pageNo;

}
