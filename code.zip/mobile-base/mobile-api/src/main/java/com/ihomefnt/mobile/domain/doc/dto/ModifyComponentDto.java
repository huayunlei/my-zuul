package com.ihomefnt.mobile.domain.doc.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:36
 */
@Data
public class ModifyComponentDto extends AddComponentDto {

    @ApiModelProperty(value = "文档id", required = true)
    private Integer id;
}
