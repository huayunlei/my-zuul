package com.ihomefnt.mobile.constant.hotupdate;

/**
 * @author xiamingyu
 */

public enum ModuleCreateEnum {

    SUCCESS(1,"成功"),
    ONLY_LETTER(1041,"模块名称仅支持纯英文字母");

    private Integer code;

    private String msg;


    ModuleCreateEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static ModuleCreateEnum getEnumByCode(int code){
        ModuleCreateEnum[] values = values();
        for (ModuleCreateEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }


    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
