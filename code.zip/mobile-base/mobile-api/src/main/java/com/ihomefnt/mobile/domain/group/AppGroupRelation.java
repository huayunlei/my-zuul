package com.ihomefnt.mobile.domain.group;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ihomefnt.mobile.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Accessors(chain = true)
@TableName("t_app_group_relation")
@EqualsAndHashCode(callSuper = true)
public class AppGroupRelation extends BaseEntity {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 组id
     */
    private Integer groupId;

    /**
     * appId
     */
    private String appId;

    /**
     * app名称
     */
    private String appName;

    /**
     * 图标
     */
    private String icon;

    /**
     * 分发地址
     */
    private String url;

    /**
     * app类型  1:IOS 2:Android
     */
    private Integer appType;

    /**
     * 来源 1: mop 2:其他来源
     */
    private Integer source;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
}
