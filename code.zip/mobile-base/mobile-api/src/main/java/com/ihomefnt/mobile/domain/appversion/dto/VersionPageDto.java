package com.ihomefnt.mobile.domain.appversion.dto;

import com.ihomefnt.mobile.common.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper = true)
public class VersionPageDto extends BasePageRequest {

    @ApiModelProperty("上架状态 0:未上架")
    private Integer putAwayState;

    @ApiModelProperty("app名称")
    private String appName;

    @ApiModelProperty("类型  1:ios 2:安卓")
    private Integer appType;

}
