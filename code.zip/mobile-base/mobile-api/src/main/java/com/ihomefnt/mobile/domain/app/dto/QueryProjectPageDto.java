package com.ihomefnt.mobile.domain.app.dto;

import com.ihomefnt.mobile.common.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-23 12:59
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class QueryProjectPageDto extends BasePageRequest {

    @ApiModelProperty(value = "账户id")
    private Integer accountId;
}
