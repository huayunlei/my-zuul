package com.ihomefnt.mobile.common.utils.cache;

import com.alibaba.fastjson.JSON;
import com.ihomefnt.common.util.RedisUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Component
public class RedisCacheUtil {
	private static Logger logger = LoggerFactory.getLogger(RedisCacheUtil.class);


	public <T> void msetBin(final Map<String, T> hash, final int time) {
		Jedis jedis = null;
		try {
			jedis = RedisUtil.getResource();
			Pipeline pipeline = jedis.pipelined();
			for (Map.Entry<String, T> entry : hash.entrySet()) {
				pipeline.setex(entry.getKey(), time, jsonEncode(entry.getValue()));
			}
			pipeline.sync();
			
		} catch (Exception e) {
			logger.error("msetBin {}", hash);
		} finally {
			RedisUtil.returnResource(jedis);
		}
	}

	public <T> void setBin(final String key, final T value, final int time) {
		Jedis jedis = null;
		try {
			jedis = RedisUtil.getResource();
			jedis.setex(key, time, jsonEncode(value));
		} catch (Exception e) {
			logger.error("setBin {}", e);
		} finally {
			RedisUtil.returnResource(jedis);
		}
	}

	public <T> T getBin(final String key, final Class<T> type) {
		Jedis jedis = null;
		try {
			jedis = RedisUtil.getResource();
			return jsonDecode(jedis.get(key), type);
		} catch (Exception e) {
			logger.error("getBin {}", e);
		} finally {
			RedisUtil.returnResource(jedis);
		}
		return null;
	}

	public <T> void del(final String key) {
		Jedis jedis = null;
		try {
			jedis = RedisUtil.getResource();
			jedis.del(key);
		} catch (Exception e) {
			logger.error("del {}", e);
		} finally {
			RedisUtil.returnResource(jedis);
		}
	}
	
	
	/**生成缓存key（拼冒号）
	 * @param namespace
	 * @param keys
	 * @return
	 */
	public String generateCacheKey(String namespace, Object... keys) {
		StringBuilder out = new StringBuilder();
		out.append(namespace);
		if (keys != null && keys.length > 0) {
			out.append(":");
			for (int i = 0; i < keys.length; i++) {
				out.append(keys[i]);
				if (i != keys.length - 1) {
					out.append(":");
				}
			}
		}
		return out.toString();
	}
	
	/**生成不拼冒号的缓存key
	 * @param namespace
	 * @param keys
	 * @return
	 */
	public String generateNoColonCacheKey(String namespace, Object... keys) {
		StringBuilder out = new StringBuilder();
		out.append(namespace);
		if (keys != null && keys.length > 0) {
			out.append(":");
			for (int i = 0; i < keys.length; i++) {
				out.append(keys[i]);
			}
		}
		return out.toString();
	}
	
	
	public String jsonEncode(Object object) {
		if (object == null) {
			return null;
		}
		return JSON.toJSONString(object);
	}

	public <T> T jsonDecode(String input, Class<T> type) {
		if (input == null || input.length() == 0) {
			return null;
		}
		return JSON.parseObject(input, type);
	}

	public <T> List<T> jsonDecodeArray(String input, Class<T> type) {
		if (input == null || input.length() == 0) {
			return Collections.emptyList();
		}
		return JSON.parseArray(input, type);
	}

	/**
	 * list to array
	 *
	 * @param objects
	 *            serial list
	 * @return byte[][]
	 */
	private String[] objectsToJsonArray(Object... objects) {
		int length = objects.length;
		String[] result = new String[length];
		for (int i = 0; i < length; i++) {
			result[i] = jsonEncode(objects[i]);
		}
		return result;
	}

	private String[] objectsToJsonArrayReverse(Object... objects) {
		int length = objects.length;
		String[] result = new String[length];
		for (int i = 0; i < length; i++) {
			result[i] = jsonEncode(objects[length - i - 1]);
		}
		return result;
	}
}
