/*
 * Copyright (C) 2006-2016 AiJia All rights reserved
 * Author: zhang
 * Date: 2017年3月4日
 * Description:PageResponse.java
 */
package com.ihomefnt.mobile.common;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhang
 */
@Data
public class PageResponse<T> {

    public PageResponse() {
        this.pageNo = 1;
        this.pageSize = 10;
        this.totalCount = 0;
        this.totalPage = 1;
        this.list = new ArrayList<T>();
    }

    /**
     * 返回的主体数据
     */
    private List<T> list;
    /**
     * 当前页码
     */
    private int pageNo;
    /**
     * 每页的数据条数
     */
    private int pageSize;
    /**
     * 总记录数
     */
    private long totalCount;

    /**
     * 总页数
     */
    private long totalPage;

}
