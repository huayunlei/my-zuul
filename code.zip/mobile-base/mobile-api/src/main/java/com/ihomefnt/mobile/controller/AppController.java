package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.BaseRequest;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseCodeEnum;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.app.dto.CreateAppDto;
import com.ihomefnt.mobile.domain.app.dto.QueryAppDto;
import com.ihomefnt.mobile.domain.app.dto.QueryAppPageDto;
import com.ihomefnt.mobile.domain.app.dto.UpdateAppDto;
import com.ihomefnt.mobile.domain.app.vo.AppDetailVo;
import com.ihomefnt.mobile.domain.app.vo.AppVo;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryBaseBandDto;
import com.ihomefnt.mobile.service.AppService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author xiamingyu
 * @date 2019/1/3
 */
@RestController
@Api(description = "应用相关API")
@RequestMapping(value = "/app")
public class AppController {

    @Resource
    private AppService appService;

    @ApiOperation("创建APP")
    @PostMapping(value = "/createApp")
    public ResponseVo createApp(@RequestBody CreateAppDto appDto) {
        ResponseVo responseVo;
        if (appDto == null || StringUtils.isBlank(appDto.getAppName())
                || appDto.getGroupId() == null
                || StringUtils.isBlank(appDto.getBundleId())
                || appDto.getAppType() == null) {
            responseVo = ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            responseVo = appService.createApp(appDto);
        }
        return responseVo;
    }

    @ApiOperation("更新APP")
    @PostMapping(value = "/updateApp")
    public ResponseVo updateApp(@RequestBody UpdateAppDto appDto) {
        return appService.updateApp(appDto);
    }


    @PostMapping("/query-page")
    @ApiOperation("查询app列表")
    public ResponseVo<PageResponse<AppVo>> queryPage(@RequestBody QueryAppPageDto pageDto) {
        return ResponseVo.success(appService.queryPage(pageDto));
    }

    @GetMapping("/ipa/{appId}/{appVersion}/ipa.plist")
    @ApiOperation("ios描述文件")
    public void ipa(@PathVariable String appId, @PathVariable String appVersion, HttpServletResponse response) {
        appService.ipa(appId, appVersion, response);
    }

    @GetMapping("/query-detail")
    @ApiOperation("查询app详情")
    public ResponseVo<AppDetailVo> queryDetail(String appId) {
        return ResponseVo.success(appService.queryDetail(appId));
    }

    @PostMapping("/delete")
    @ApiOperation("删除app")
    public ResponseVo delete(@RequestBody String appId) {
        appService.delete(appId);
        return ResponseVo.success();
    }

    @PostMapping("/query-list")
    @ApiOperation("查询app列表")
    public ResponseVo<List<AppVo>> queryList(@RequestBody QueryAppDto pageDto) {
        return ResponseVo.success(appService.queryList(pageDto));
    }


    @PostMapping("/download-count")
    @ApiOperation("app下载统计")
    public ResponseVo downloadCount(@RequestBody BaseRequest baseRequest) {
        appService.downloadCount(baseRequest.getAppId());
        return ResponseVo.success();
    }

    @PostMapping("/queryListByBaseband")
    @ApiOperation("查询基带关联的所有app列表")
    public ResponseVo<List<AppVo>> queryListByBaseband(@RequestBody QueryBaseBandDto baseBandDto) {
        return ResponseVo.success(appService.queryListByBaseband(baseBandDto));
    }

}
