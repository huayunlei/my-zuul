package com.ihomefnt.mobile.proxy.upload;

import com.ihomefnt.common.api.ResponseVo;
import com.ihomefnt.mobile.domain.upload.dto.UploadFileRequest;

/**
 * @author xiamingyu
 * @date 2018/12/24
 */

public interface IUploadProxy {

    /**
     * 上传静态文件
     * @param request
     * @param fileName
     * @return
     */
    ResponseVo uploadStaticFile(UploadFileRequest request,String fileName);

}
