package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-24 18:08
 */
@ApiModel(description = "BundleRecordDetailQueryRequest")
@Data
@Accessors(chain = true)
public class BundleRecordDetailQueryRequest extends BaseRequest {

    @ApiModelProperty(value = "bundleRecordId")
    private Integer bundleRecordId;
}
