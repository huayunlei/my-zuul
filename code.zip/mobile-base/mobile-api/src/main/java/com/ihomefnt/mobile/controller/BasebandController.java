package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.hotupdate.dto.BasebandVersionDto;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryBaseBandPageDto;
import com.ihomefnt.mobile.domain.hotupdate.vo.BasebandVo;
import com.ihomefnt.mobile.service.BasebandService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-10-08 14:05
 */
@RestController
@RequestMapping("/baseband")
public class BasebandController {

    @Resource
    private BasebandService basebandService;

    @PostMapping("create")
    public ResponseVo create(@RequestBody BasebandVersionDto versionDto) {
        return basebandService.create(versionDto);
    }

    @GetMapping("/query-all")
    @ApiOperation("查询所有基带版本")
    @ApiImplicitParam(name = "appType", value = "app类型 1:IOS,2:Android")
    public ResponseVo<List<BasebandVo>> queryAll(Integer appType) {
        return basebandService.queryAll(appType);
    }

    @GetMapping("/query-page")
    @ApiOperation("查询所有基带版本")
    public ResponseVo<PageResponse<BasebandVo>> queryPage(QueryBaseBandPageDto pageDto) {
        return basebandService.queryPage(pageDto);
    }

    @PostMapping("delete")
    public ResponseVo delete(@RequestBody Integer id) {
        return basebandService.delete(id);
    }

    @PostMapping("detailById")
    public ResponseVo<BasebandVo> detailById(@RequestBody Integer id) {
        return basebandService.detailById(id);
    }
}
