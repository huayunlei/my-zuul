package com.ihomefnt.mobile.service;

import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryAllModuleDto;
import com.ihomefnt.mobile.domain.hotupdate.vo.request.*;
import com.ihomefnt.mobile.domain.hotupdate.vo.response.AppBundleRecordPageResponse;
import com.ihomefnt.mobile.domain.hotupdate.vo.response.BundleRecordDetailResponse;
import com.ihomefnt.mobile.domain.hotupdate.vo.response.HotUpdateResponse;

/**
 * @author xiamingyu
 * @date 2018/11/22
 */

public interface IHotUpdateService {

    /**
     * 查询热更新信息
     *
     * @param request
     * @return
     */
    ResponseVo queryUpdateInfo(UpdateQueryRequest request);

    /**
     * 创建热更新
     *
     * @param request
     * @return
     */
    ResponseVo createUpdate(UpdateCreateRequest request);

    /**
     * 新增
     *
     * @return
     */
    ResponseVo createNewModule(CreateModuleRequest request);

    /**
     * 通过APPID查询所有模块信息(分页)
     *
     * @param request
     * @return
     */
    ResponseVo queryModuleInfoByAppId(QueryModuleRequest request);

    /**
     * 根据模块唯一码分页查询更新记录
     *
     * @param request
     * @return
     */
    ResponseVo queryBundleRecordByModuleCode(QueryBundleRecordRequest request);

    /**
     * 查询打包配置
     *
     * @param request
     * @return
     */
    ResponseVo queryBundleConfig(BundleConfigRequest request);

    /**
     * 上报日志
     *
     * @param request
     * @return
     */
    ResponseVo uploadLog(UploadLogRequest request);

    HotUpdateResponse queryHotUpdateNew(UpdateQueryRequest request);

    BundleRecordDetailResponse getBundleRecordById(Integer bundleRecordId);

    int updateAppBundleReleaseStatus(AppBundleReleaseStatusUpdateRequest request);

    int updateBundleRecordById(BundleRecordUpdateRequest request);

    int rollback(BundleRecordRollbackRequest request);

    ResponseVo<HotUpdateResponse> queryAllModuleNewVersion(QueryAllModuleDto appId);

    ResponseVo<AppBundleRecordPageResponse> queryBundleRecordByBaseband(QueryBundleRecordRequest request);
}
