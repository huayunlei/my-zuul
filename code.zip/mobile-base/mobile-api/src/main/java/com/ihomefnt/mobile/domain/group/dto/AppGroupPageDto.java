package com.ihomefnt.mobile.domain.group.dto;

import com.ihomefnt.mobile.common.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class AppGroupPageDto  extends BasePageRequest {

    @ApiModelProperty("组名称")
    private String name;
}
