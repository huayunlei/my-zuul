package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author xiamingyu
 * @date 2018/12/27
 */

@ApiModel(description = "获取打包配置")
@Data
@Accessors(chain = true)
public class BundleConfigRequest extends BaseRequest {

    @ApiModelProperty(value = "app版本号")
    private Integer appVersionCode;

    @ApiModelProperty(value = "需要更新的模块")
    private List<String> moduleCode;

}
