package com.ihomefnt.mobile.domain.hotupdate.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author xiamingyu
 * @date 2018/12/28
 */

@ApiModel("打包配置信息返回")
@Data
@Accessors(chain = true)
public class BundleConfigResponse {

    @ApiModelProperty("配置信息")
    private String config;

}
