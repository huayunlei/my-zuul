package com.ihomefnt.mobile.domain.doc.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:20
 */
@Data
public class QueryComponentDto {

    @ApiModelProperty(value = "组件分类")
    private String componentCategory;

    @ApiModelProperty(value = "组件类型")
    private String componentType;
}
