package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.account.Account;
import com.ihomefnt.mobile.domain.account.dto.LoginDto;
import com.ihomefnt.mobile.domain.account.vo.AccountVo;
import com.ihomefnt.mobile.domain.app.vo.AppVo;
import com.ihomefnt.mobile.service.AccountService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-12 10:38
 */
@RestController
@Api(description = "账户")
@RequestMapping("/account")
public class AccountController {

    @Resource
    private AccountService accountService;

    @ApiOperation("登陆")
    @PostMapping("/login")
    public ResponseVo<AccountVo> login(@RequestBody LoginDto loginDto) {
        return accountService.login(loginDto);
    }

}
