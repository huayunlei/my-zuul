package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.domain.group.AppGroupUser;

import java.util.List;

public interface AppGroupUserService extends IService<AppGroupUser> {

    List<Integer> selectAllGroupIdByUserId(Integer userId);

}
