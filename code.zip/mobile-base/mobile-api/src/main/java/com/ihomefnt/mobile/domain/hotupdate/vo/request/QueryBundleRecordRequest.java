package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author xiamingyu
 * @date 2018/12/26
 */

@ApiModel(description = "QueryBundleRecordRequest")
@Data
@Accessors(chain = true)
public class QueryBundleRecordRequest extends BaseRequest {

    @ApiModelProperty(value = "模块唯一码")
    private String moduleCode;

    @ApiModelProperty(value = "基带版本号")
    private Integer basebandVersion;

    @ApiModelProperty(value = "每页条数")
    private Integer pageSize = 10;

    @ApiModelProperty("查询的页码")
    private Integer pageNo = 1;

}
