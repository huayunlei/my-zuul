package com.ihomefnt.mobile.domain.module.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AppModuleVo {

    @ApiModelProperty("模块id")
    private Integer id;

    @ApiModelProperty("appId")
    private String appId;

    @ApiModelProperty("当前版本")
    private Integer version;

    @ApiModelProperty("基带版本")
    private Integer baseVersion;

    @ApiModelProperty("模块名称")
    private String moduleName;

    @ApiModelProperty("模块编码")
    private String moduleCode;

    @ApiModelProperty("是否发布：0:否 :1是")
    private Integer isRelease;

    @ApiModelProperty("模块描述")
    private String moduleDesc;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("最后更新时间")
    private LocalDateTime updateTime;
}
