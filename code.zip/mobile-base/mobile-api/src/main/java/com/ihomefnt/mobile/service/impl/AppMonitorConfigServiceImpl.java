package com.ihomefnt.mobile.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.app.App;
import com.ihomefnt.mobile.domain.monitor.AppMonitorConfigPo;
import com.ihomefnt.mobile.domain.monitor.vo.*;
import com.ihomefnt.mobile.mapper.AppMapper;
import com.ihomefnt.mobile.mapper.AppMonitorConfigMapper;
import com.ihomefnt.mobile.service.AppMonitorConfigService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-27 11:14
 */
@Service
public class AppMonitorConfigServiceImpl implements AppMonitorConfigService {

    @Resource
    private AppMonitorConfigMapper appMonitorConfigMapper;
    @Resource
    private AppMapper appMapper;

    @Override
    public ResponseVo<Integer> add(CreateMonitorConfigRequest createMonitorConfigRequest) {
        QueryWrapper<AppMonitorConfigPo> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppMonitorConfigPo::getAppId, createMonitorConfigRequest.getAppId())
                .eq(AppMonitorConfigPo::getMonitorKey, createMonitorConfigRequest.getMonitorKey())
                .eq(AppMonitorConfigPo::getDelFlag, 0);

        Integer count = appMonitorConfigMapper.selectCount(queryWrapper);
        if (count > 0) {
            return ResponseVo.fail("该app应用对应的业务key已存在");
        }

        AppMonitorConfigPo appMonitorConfigPo = new AppMonitorConfigPo();
        appMonitorConfigPo.setAppId(createMonitorConfigRequest.getAppId())
                .setMonitorKey(createMonitorConfigRequest.getMonitorKey())
                .setMonitorLevel(StringUtils.isEmpty(createMonitorConfigRequest.getMonitorLevel()) ? "高" : createMonitorConfigRequest.getMonitorLevel())
                .setMonitorDesc(createMonitorConfigRequest.getMonitorDesc())
                .setMonitorDingName(createMonitorConfigRequest.getMonitorDingName())
                .setMonitorDingToken(createMonitorConfigRequest.getMonitorDingToken());

        count = appMonitorConfigMapper.insert(appMonitorConfigPo);
        return ResponseVo.success(count);
    }

    @Override
    public ResponseVo<Integer> update(UpdateMonitorConfigRequest updateMonitorConfigRequest) {
        AppMonitorConfigPo appMonitorConfigPo =  appMonitorConfigMapper.selectById(updateMonitorConfigRequest.getId());
        if (appMonitorConfigPo == null || 0 != appMonitorConfigPo.getDelFlag()) {
            return ResponseVo.fail("要删除的数据不存在");
        }

        if (StringUtils.isNotEmpty(updateMonitorConfigRequest.getAppId())) {
            appMonitorConfigPo.setAppId(updateMonitorConfigRequest.getAppId());
        }
        if (StringUtils.isNotEmpty(updateMonitorConfigRequest.getMonitorKey())) {
            appMonitorConfigPo.setMonitorKey(updateMonitorConfigRequest.getMonitorKey());
        }
        if (StringUtils.isNotEmpty(updateMonitorConfigRequest.getMonitorLevel())) {
            appMonitorConfigPo.setMonitorLevel(updateMonitorConfigRequest.getMonitorLevel());
        }
        if (StringUtils.isNotEmpty(updateMonitorConfigRequest.getMonitorDesc())) {
            appMonitorConfigPo.setMonitorDesc(updateMonitorConfigRequest.getMonitorDesc());
        }
        if (StringUtils.isNotEmpty(updateMonitorConfigRequest.getMonitorDingName())) {
            appMonitorConfigPo.setMonitorDingName(updateMonitorConfigRequest.getMonitorDingName());
        }
        if (StringUtils.isNotEmpty(updateMonitorConfigRequest.getMonitorDingToken())) {
            appMonitorConfigPo.setMonitorDingToken(updateMonitorConfigRequest.getMonitorDingToken());
        }
        if (null != updateMonitorConfigRequest.getDelFlag() && 1 == updateMonitorConfigRequest.getDelFlag()) {
            appMonitorConfigPo.setDelFlag(1);
        }

        int count = appMonitorConfigMapper.updateById(appMonitorConfigPo);
        return ResponseVo.success(count);
    }

    @Override
    public ResponseVo<AppMonitorConfigVo> detailById(Integer id) {
        AppMonitorConfigPo appMonitorConfigPo =  appMonitorConfigMapper.selectById(id);
        if (null != appMonitorConfigPo && 0 == appMonitorConfigPo.getDelFlag()) {
            AppMonitorConfigVo appMonitorConfigVo = appMonitorConfigPo.transform(AppMonitorConfigVo.class);
            return ResponseVo.success(appMonitorConfigVo);
        }

        return ResponseVo.success();
    }

    @Override
    public PageResponse<AppMonitorConfigVo> queryPage(PageMonitorConfigRequest pageMonitorConfigRequest) {
        QueryWrapper<AppMonitorConfigPo> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppMonitorConfigPo::getDelFlag, 0);
        if (StringUtils.isNotEmpty(pageMonitorConfigRequest.getAppId())) {
            queryWrapper.lambda().eq(AppMonitorConfigPo::getAppId, pageMonitorConfigRequest.getAppId());
        }

        Page<AppMonitorConfigPo> appMonitorConfigPage = new Page<>(pageMonitorConfigRequest.getPageNo(), pageMonitorConfigRequest.getPageSize());
        appMonitorConfigPage.setDesc("create_time");
        IPage<AppMonitorConfigPo> page = appMonitorConfigMapper.selectPage(appMonitorConfigPage, queryWrapper);

        PageResponse<AppMonitorConfigVo> response = new PageResponse<>();
        List<AppMonitorConfigVo> appMonitorConfigVoList = page.getRecords().stream().map(item -> item.transform(AppMonitorConfigVo.class)).collect(toList());
        response.setTotalPage(page.getPages());
        response.setTotalCount(page.getTotal());
        response.setPageNo(pageMonitorConfigRequest.getPageNo());
        response.setPageSize(pageMonitorConfigRequest.getPageSize());
        response.setList(appMonitorConfigVoList);
        return response;
    }

    @Override
    public ResponseVo<Integer> deleteById(Integer id) {
        AppMonitorConfigPo appMonitorConfigPo =  appMonitorConfigMapper.selectById(id);
        if (null != appMonitorConfigPo && 0 == appMonitorConfigPo.getDelFlag()) {
            appMonitorConfigPo.setDelFlag(1);
            Integer count = appMonitorConfigMapper.updateById(appMonitorConfigPo);
            return ResponseVo.success(count);
        }

        return ResponseVo.fail("删除对象不存在");
    }

    @Override
    public ResponseVo<AppMonitorConfigVo> queryByCondition(QueryMonitorConfigConditionRequest request) {
        QueryWrapper<AppMonitorConfigPo> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppMonitorConfigPo::getDelFlag, 0)
                            .eq(AppMonitorConfigPo::getAppId, request.getAppId())
                            .eq(AppMonitorConfigPo::getMonitorKey, request.getMonitorKey());

        AppMonitorConfigPo appMonitorConfigPo = appMonitorConfigMapper.selectOne(queryWrapper);
        if (null != appMonitorConfigPo) {
            AppMonitorConfigVo appMonitorConfigVo = appMonitorConfigPo.transform(AppMonitorConfigVo.class);
            QueryWrapper<App> queryWrapper2 = new QueryWrapper<>();
            queryWrapper2.lambda().eq(App::getDeleteFlag, 0)
                                .eq(App::getAppId, request.getAppId());
            App app = appMapper.selectOne(queryWrapper2);
            if (null != app) {
                appMonitorConfigVo.setAppName(app.getAppName());
            }

            return ResponseVo.success(appMonitorConfigVo);
        }

        return ResponseVo.success();
    }
}
