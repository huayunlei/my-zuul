package com.ihomefnt.mobile.domain.hotupdate.vo.response;

import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-31 14:39
 */
@ApiModel(description = "AppBundleRecordPageResponse")
@Data
@Accessors(chain = true)
public class AppBundleRecordPageResponse {

    @ApiModelProperty(value = "bundle更新记录")
    private List<AppBundleRecord> records;

    /**
     * 当前页码
     */
    @ApiModelProperty(value = "当前页码")
    private int pageNo;
    /**
     * 总记录数
     */
    @ApiModelProperty(value = "总记录数")
    private int totalCount;
}
