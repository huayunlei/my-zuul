package com.ihomefnt.mobile.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ihomefnt.mobile.domain.doc.ComponentDoc;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:11
 */
public interface ComponentDocMapper extends BaseMapper<ComponentDoc> {
}
