package com.ihomefnt.mobile.common;

/**
*@description: ResponseCodeEnum
*@author: lichensi
*@create: 2018/8/17
*/
public enum ResponseCodeEnum {

    SUCCESS(1,"成功",true),
    FAILED(2,"系统有点小异常，请稍后再试",false),
    HANDLE_FAILED(3,"操作失败",false),
    INVALID_PARAMETER(499,"无效参数",false),
     SYSTEM_EXCEPTION(500,"系统异常",false),
    DATA_TRANSFER_EMPTY(109003, "传入参数有空值,或传入参数有误", false)

    ;

    private Integer code;

    private String msg;

    private boolean success;

    ResponseCodeEnum(Integer code, String msg, boolean success) {
        this.code = code;
        this.msg = msg;
        this.success = success;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public boolean isSuccess() {
        return success;
    }
}
