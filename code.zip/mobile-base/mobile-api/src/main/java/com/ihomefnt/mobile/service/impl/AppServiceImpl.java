package com.ihomefnt.mobile.service.impl;

import com.alibaba.nacos.common.util.Md5Utils;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.app.App;
import com.ihomefnt.mobile.domain.app.dto.CreateAppDto;
import com.ihomefnt.mobile.domain.app.dto.QueryAppDto;
import com.ihomefnt.mobile.domain.app.dto.QueryAppPageDto;
import com.ihomefnt.mobile.domain.app.dto.UpdateAppDto;
import com.ihomefnt.mobile.domain.app.vo.AppDetailVo;
import com.ihomefnt.mobile.domain.app.vo.AppVo;
import com.ihomefnt.mobile.domain.appversion.AppVersion;
import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryBaseBandDto;
import com.ihomefnt.mobile.domain.module.AppModule;
import com.ihomefnt.mobile.mapper.AppBundleRecordMapper;
import com.ihomefnt.mobile.mapper.AppMapper;
import com.ihomefnt.mobile.mapper.AppModuleMapper;
import com.ihomefnt.mobile.mapper.AppVersionMapper;
import com.ihomefnt.mobile.service.AppGroupUserService;
import com.ihomefnt.mobile.service.AppService;
import com.ihomefnt.mobile.service.VersionService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

/**
 * @author xiamingyu
 * @date 2019/1/3
 */
@Slf4j
@Service
public class AppServiceImpl extends ServiceImpl<AppMapper, App> implements AppService {

    /**
     * app下载统计
     */
    private final static String APP_DOWNLOAD_COUNT = "APP_DOWNLOAD_COUNT:";

    @Resource
    private AppMapper appMapper;

    @Resource
    private AppVersionMapper appVersionMapper;

    @Resource
    private VersionService versionService;

    @Resource
    private AppGroupUserService appGroupUserService;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private AppModuleMapper appModuleMapper;

    @Resource
    private AppBundleRecordMapper appBundleRecordMapper;


    @Override
    public ResponseVo createApp(CreateAppDto request) {

        App app = new App().setAppName(request.getAppName())
                .setAppType(request.getAppType())
                .setBundleId(request.getBundleId())
                .setGroupId(request.getGroupId())
                .setIcon(request.getIcon())
                .setType(request.getType())
                .setDescription(request.getDescription())
                .setAppSecret(UUID.randomUUID().toString());
        app.setAppId(Md5Utils.getMD5(request.getAppName() + app.getBundleId() + request.getAppType(), "utf-8").substring(0, 16));
        appMapper.insert(app);
        return ResponseVo.success();

    }

    @Override
    public PageResponse<AppVo> queryPage(QueryAppPageDto pageDto) {
        PageResponse<AppVo> response = new PageResponse<>();
        //查询用户所在的组
//        List<Integer> groupIds = appGroupUserService.selectAllGroupIdByUserId(pageDto.getUserId());
//        if (CollectionUtils.isEmpty(groupIds)) {
//            return response;
//        }
        QueryWrapper<App> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda()
                //.in(App::getAppId,groupIds)
                .eq(App::getDeleteFlag, 0);
        if (StringUtils.isNotEmpty(pageDto.getAppId())) {
            queryWrapper.lambda().eq(App::getAppId, pageDto.getAppId());
        }
        Page<App> appVersionIPage = new Page<>(pageDto.getPageNo(), pageDto.getPageSize());
        IPage<App> page = appMapper.selectPage(appVersionIPage, queryWrapper);
        List<AppVo> appVoList = page.getRecords().stream().map(app -> {
            AppVo appVo = app.transform(AppVo.class);
            AppVersion appVersion = versionService.queryLatestApp(app.getAppId());
            if (appVersion != null) {
                appVo.setState(appVersion.getPutAwayState());
                appVo.setAppVersion(appVersion.getVersion());
                appVo.setUpdateTime(appVersion.getCreateTime());
                appVo.setDownload(appVersion.getDownload());
            }
            return appVo;
        }).collect(toList());
        response.setTotalPage(page.getPages());
        response.setTotalCount(page.getTotal());
        response.setPageNo(pageDto.getPageNo());
        response.setPageSize(pageDto.getPageSize());
        response.setList(appVoList);
        return response;
    }

    @Override
    public void ipa(String appId, String version, HttpServletResponse response) {
        //查询版本信息
        QueryWrapper<AppVersion> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppVersion::getAppId, appId)
                .eq(AppVersion::getDelFlag, 0)
                .eq(AppVersion::getVersion, version);
        Page<AppVersion> page = new Page<>(1, 1);
        page.setDesc("v_id");
        AppVersion appVersion = appVersionMapper.selectPage(page, queryWrapper).getRecords().get(0);
        //查询app信息
        QueryWrapper<App> appQueryWrapper = new QueryWrapper<>();
        appQueryWrapper.lambda().eq(App::getAppId, appId);
        App app = appMapper.selectOne(appQueryWrapper);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        stringBuilder.append("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n");
        stringBuilder.append("<plist version=\"1.0\">\n");
        stringBuilder.append("  <dict>\n");
        stringBuilder.append("      <key>items</key>\n");
        stringBuilder.append("      <array>\n");
        stringBuilder.append("          <dict>\n");
        stringBuilder.append("              <key>assets</key>\n");
        stringBuilder.append("              <array>\n");
        stringBuilder.append("                  <dict>\n");
        stringBuilder.append("                      <key>kind</key>\n");
        stringBuilder.append("                      <string>software-package</string>\n");
        stringBuilder.append("                      <key>url</key>\n");
        stringBuilder.append("                      <string>").append(appVersion.getIpaDownloadUrl()).append("</string>\n");
        stringBuilder.append("                  </dict>\n");
        stringBuilder.append("              </array>\n");
        stringBuilder.append("              <key>metadata</key>\n");
        stringBuilder.append("              <dict>\n");
        stringBuilder.append("                  <key>bundle-identifier</key>\n");
        stringBuilder.append("                  <string>").append(app.getBundleId()).append("</string>\n");
        stringBuilder.append("                  <key>bundle-version</key>\n");
        stringBuilder.append("                  <string>").append(appVersion.getVersion()).append("</string>\n");
        stringBuilder.append("                  <key>kind</key>\n");
        stringBuilder.append("                  <string>software</string>\n");
        stringBuilder.append("                  <key>title</key>\n");
        stringBuilder.append("                  <string>").append(app.getAppName()).append("</string>\n");
        stringBuilder.append("              </dict>\n");
        stringBuilder.append("          </dict>\n");
        stringBuilder.append("      </array>\n");
        stringBuilder.append("  </dict>\n");
        stringBuilder.append("</plist>");
        response.setContentType("application/x-msdownload");
        response.setHeader("Content-Disposition", "attachment; filename=" + "dowload.plist");
        try {
            OutputStream out = response.getOutputStream();
            out.write(stringBuilder.toString().getBytes());
            out.close();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    @Override
    public ResponseVo updateApp(UpdateAppDto appDto) {
        QueryWrapper<App> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(App::getAppId, appDto.getAppId());
        App app = appMapper.selectOne(queryWrapper);
        if (app != null) {
            app.setIcon(appDto.getIcon());
            app.setAppName(appDto.getAppName());
            app.setType(appDto.getType());
            app.setDescription(appDto.getDescription());
            appMapper.updateById(app);
        }
        return ResponseVo.success();
    }

    @Override
    public AppDetailVo queryDetail(String appId) {
        QueryWrapper<App> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(App::getAppId, appId);
        App app = appMapper.selectOne(queryWrapper);
        if (app != null) {
            AppDetailVo appVo = app.transform(AppDetailVo.class);
            AppVersion appVersion = versionService.queryLatestApp(app.getAppId());
            if (appVersion != null) {
                appVo.setState(appVersion.getPutAwayState());
                appVo.setAppVersion(appVersion.getVersion());
                appVo.setDownload(appVersion.getDownload());
                appVo.setUpdateTime(appVersion.getCreateTime());
            }
            //查询模块数量
            QueryWrapper<AppModule> moduleQueryWrapper = new QueryWrapper<>();
            moduleQueryWrapper.lambda().eq(AppModule::getAppId, appId)
                    .eq(AppModule::getDeleteFlag, 0);
            appVo.setBundleCount(appModuleMapper.selectCount(moduleQueryWrapper));
            //查询bundle发布次数
            List<String> modelCode = appModuleMapper.selectList(moduleQueryWrapper).stream().map(AppModule::getModuleCode).collect(toList());
            if (CollectionUtils.isNotEmpty(modelCode)) {
                QueryWrapper<AppBundleRecord> bundleRecordQueryWrapper = new QueryWrapper<>();
                bundleRecordQueryWrapper.lambda().in(AppBundleRecord::getModuleCode, modelCode)
                        .eq(AppBundleRecord::getDeleteFlag, 0);
                appVo.setBundleReleaseCount(appBundleRecordMapper.selectCount(bundleRecordQueryWrapper));
            } else {
                appVo.setBundleReleaseCount(0);
            }
            //查询app发布次数
            QueryWrapper<AppVersion> versionQueryWrapper = new QueryWrapper<>();
            versionQueryWrapper.lambda().eq(AppVersion::getAppId, appId)
                    .eq(AppVersion::getDelFlag, 0);
            appVo.setAppReleaseCount(appVersionMapper.selectCount(versionQueryWrapper));
            //查询app下载次数
            appVo.setBundleCount(appModuleMapper.selectCount(moduleQueryWrapper));
            appVo.setDownloadCount(redissonClient.getAtomicLong(APP_DOWNLOAD_COUNT + appId).get());
            return appVo;
        }
        return null;
    }

    @Override
    public void delete(String appId) {
        QueryWrapper<App> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(App::getAppId, appId);
        App app = appMapper.selectOne(queryWrapper);
        if (app != null) {
            appMapper.deleteById(app.getId());
        }
    }

    @Override
    public List<AppVo> queryList(QueryAppDto pageDto) {
        QueryWrapper<App> queryWrapper = new QueryWrapper<>();
        return appMapper.selectList(queryWrapper).stream()
                .map(app -> app.transform(AppVo.class))
                .collect(toList());
    }

    @Override
    public void downloadCount(String appId) {
        RAtomicLong atomicLong = redissonClient.getAtomicLong(APP_DOWNLOAD_COUNT + appId);
        atomicLong.incrementAndGet();
    }

    @Override
    public List<AppVo> queryListByBaseband(QueryBaseBandDto baseBandDto) {
        // 先查询app record
        QueryWrapper<AppVersion> versionQueryWrapper = new QueryWrapper<>();
        versionQueryWrapper.lambda().eq(AppVersion::getBaseAppVersion, baseBandDto.getBasebandVersion())
                .eq(AppVersion::getDelFlag, 0);
        List<AppVersion> appVersionList = appVersionMapper.selectList(versionQueryWrapper);
        if (CollectionUtils.isNotEmpty(appVersionList)) {
            Set<String> appIdSet = appVersionList.stream().map(appVersion -> appVersion.getAppId()).collect(Collectors.toSet());
            // 再查询app
            QueryWrapper<App> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().in(App::getAppId, appIdSet)
                    .eq(App::getDeleteFlag, 0);

            List<App> appList = appMapper.selectList(queryWrapper);
            if (CollectionUtils.isNotEmpty(appList)) {
                return appList.stream().map(app -> app.transform(AppVo.class)).collect(toList());
            }
        }

        return null;
    }
}
