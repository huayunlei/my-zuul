package com.ihomefnt.mobile.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.common.util.Md5Utils;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.common.util.ModelMapperUtil;
import com.ihomefnt.common.util.StringUtil;
import com.ihomefnt.mobile.common.BusinessException;
import com.ihomefnt.mobile.common.ResponseCodeEnum;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.config.ApplicationParamsConfig;
import com.ihomefnt.mobile.constant.hotupdate.*;
import com.ihomefnt.mobile.domain.appversion.AppVersion;
import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import com.ihomefnt.mobile.domain.module.AppModule;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryAllModuleDto;
import com.ihomefnt.mobile.domain.hotupdate.po.*;
import com.ihomefnt.mobile.domain.hotupdate.vo.request.*;
import com.ihomefnt.mobile.domain.hotupdate.vo.response.*;
import com.ihomefnt.mobile.dao.IHotUpdateMapper;
import com.ihomefnt.mobile.domain.hotupdate.vo.response.Module;
import com.ihomefnt.mobile.service.*;
import com.ihomefnt.mobile.domain.upload.dto.UploadFileRequest;
import com.ihomefnt.mobile.domain.upload.dto.UploadFileResponse;
import com.ihomefnt.mobile.proxy.upload.IUploadProxy;
import com.ihomefnt.mobile.common.utils.FileUtils;
import com.ihomefnt.mobile.common.utils.MD5Util;
import com.ihomefnt.mobile.common.utils.StringUtilCollections;
import com.ihomefnt.mobile.common.utils.diff_match_patch;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.util.*;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

/**
 * @author xiamingyu
 * @date 2018/11/22
 */
@Service
public class HotUpdateServiceImpl implements IHotUpdateService {

    @Resource
    private IHotUpdateMapper IHotUpdateMapper;

    @Resource
    private IUploadProxy uploadProxy;

    @Resource
    private ApplicationParamsConfig paramsConfig;

    @Resource
    private VersionService versionService;

    @Resource
    private AppModuleService appModuleService;

    @Resource
    private AppBundleRecordService appBundleRecordService;


    private final String fileCacheDir = this.getClass().getClassLoader().getResource("").getPath() + "bundle/";

    @Override
    public ResponseVo queryUpdateInfo(UpdateQueryRequest request) {

        try {
            List<String> moduleCodeList = new ArrayList<>();

            Map<String, ReqModule> moduleMap = new HashMap<>(request.getModules().size());

            for (ReqModule module : request.getModules()) {
                if (StringUtils.isNotBlank(module.getModuleCode())) {
                    moduleCodeList.add(module.getModuleCode());
                    moduleMap.put(module.getModuleCode(), module);
                }
            }
            //校验appId与模块code的对应关系
            Map<String, Object> moduleParams = new HashMap<>(3);
            moduleParams.put("appId", request.getAppId());
            moduleParams.put("start", 0);
            moduleParams.put("pageSize", 1000);
            List<AppModule> appModulesInApp = IHotUpdateMapper.queryModuleByAppId(moduleParams);
            boolean appIdMatch = true;
            if (CollectionUtils.isNotEmpty(appModulesInApp)) {
                for (String moduleCode : moduleCodeList) {
                    boolean isInApp = false;
                    for (AppModule appModule : appModulesInApp) {
                        if (moduleCode.equals(appModule.getModuleCode())) {
                            //模块属于APP
                            isInApp = true;
                        }
                    }
                    if (!isInApp) {
                        appIdMatch = false;
                    }
                }
            } else {
                appIdMatch = false;
            }
            if (!appIdMatch) {
                return ResponseVo.buildFailedResponse(QueryUpdateResonseEnum.APPID_NOT_MATCH.getCode(), QueryUpdateResonseEnum.APPID_NOT_MATCH.getMsg());
            }

            //批量查询模块信息及最新的bundle信息
            Map<String, Object> params = new HashMap<>(2);
            params.put("baseAppVersion", request.getAppVersionCode());
            params.put("moduleCodes", moduleCodeList);

            List<AppBundleRecordList> recordLists = IHotUpdateMapper.getBundleListByModuleCodes(params);
            if (CollectionUtils.isEmpty(recordLists)) {
                return ResponseVo.buildFailedResponse(QueryUpdateResonseEnum.NO_MODULE_RECORD.getCode(), QueryUpdateResonseEnum.NO_MODULE_RECORD.getMsg());
            }

            List<Module> moduleList = getModuleList(recordLists, moduleMap);
            return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS).setObj(new HotUpdateResponse().setModules(moduleList));
        } catch (Exception e) {
            return ResponseVo.buildResponse(ResponseCodeEnum.SYSTEM_EXCEPTION);
        }
    }


    private List<Module> getModuleList(List<AppBundleRecordList> recordLists, Map<String, ReqModule> moduleMap) {
        List<Module> moduleList = new ArrayList<>();
        List<AppBundleDiff> appBundleDiffList = new ArrayList<>();

        for (AppBundleRecordList record : recordLists) {
            if (null != record) {
                List<AppBundleRecord> appBundleRecordList = record.getRecords();
                if (CollectionUtils.isNotEmpty(appBundleRecordList)) {
                    AppBundleRecord appBundleRecord = appBundleRecordList.get(0);
                    String moduleCode = appBundleRecord.getModuleCode();
                    //默认不用更新
                    Integer updateFlag = 0;
                    // 默认0-静默更新
                    Integer remindMode = 1;
                    if (appBundleRecord.getVersionCode() < moduleMap.get(moduleCode).getVersionCode()) {
                        //服务器版本 < 客户端版本
                        updateFlag = BundleUpdateEnum.ROLL_BACK.getCode();
                    } else if (appBundleRecord.getVersionCode() > moduleMap.get(moduleCode).getVersionCode()) {
                        updateFlag = appBundleRecord.getUpdateFlag();
                        remindMode = appBundleRecord.getRemindMode();
                        //服务器版本 > 客户端版本
                        for (int i = 1; i < appBundleRecordList.size(); i++) {
                            AppBundleRecord appBundleItem = appBundleRecordList.get(i);
                            if (appBundleItem.getVersionCode() > moduleMap.get(moduleCode).getVersionCode()) {
                                if (!updateFlag.equals(BundleUpdateEnum.FULL_UPDATE.getCode())) {
                                    if (BundleUpdateEnum.FULL_UPDATE.getCode().equals(appBundleItem.getUpdateFlag())) {
                                        updateFlag = BundleUpdateEnum.FULL_UPDATE.getCode();
                                    } else if (BundleUpdateEnum.INCREMENT_UPDATE.getCode().equals(appBundleItem.getUpdateFlag())) {
                                        updateFlag = BundleUpdateEnum.INCREMENT_UPDATE.getCode();
                                    }
                                }

                                if (!remindMode.equals(RemindModeEnum.POPUP_UPDATE.getCode()) && RemindModeEnum.POPUP_UPDATE.getCode().equals(appBundleItem.getRemindMode())) {
                                    remindMode = RemindModeEnum.POPUP_UPDATE.getCode();
                                }
                            }
                        }
                    }

                    Module module = new Module().setModuleCode(appBundleRecord.getModuleCode())
                            .setLatestVersionCode(appBundleRecord.getVersionCode())
                            .setRemindMode(remindMode)
                            .setUpdateFlag(updateFlag)
                            .setFullUrl(appBundleRecord.getDownloadUrl())
                            .setBundleFileMd5(appBundleRecord.getFileMd5());
                    moduleList.add(module);
                    if (updateFlag.equals(BundleUpdateEnum.INCREMENT_UPDATE.getCode())) {
                        appBundleDiffList.add(new AppBundleDiff().setModuleCode(moduleCode)
                                .setMainBundleVersionCode(appBundleRecord.getVersionCode())
                                .setDiffBundleVersionCode(moduleMap.get(moduleCode).getVersionCode())
                        );
                    }


                    if (CollectionUtils.isNotEmpty(appBundleDiffList)) {
                        //查询增量文件
                        List<AppBundleDiff> bundleDiffList = IHotUpdateMapper.getLatestBundleDiff(appBundleDiffList);
                        for (AppBundleDiff appBundleDiff : bundleDiffList) {
                            for (Module moduleItem : moduleList) {
                                if (moduleItem.getModuleCode().equals(appBundleDiff.getModuleCode())) {
                                    moduleItem.setIncrementUrl(appBundleDiff.getDownloadUrl());
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        return moduleList;
    }

    @Override
    public ResponseVo createUpdate(UpdateCreateRequest request) {

        String cacheDir = fileCacheDir + request.getModuleName() + "_" + request.getPlatform() + "_" + request.getVersionCode() + File.separator;

        try {
            //校验模块是否存在
            List<String> moduleCodes = new ArrayList<String>() {{
                add(request.getModuleCode());
            }};
            List<AppModule> appModuleList = IHotUpdateMapper.queryModuleByCodes(moduleCodes);

            if (CollectionUtils.isEmpty(appModuleList)) {
                return ResponseVo.buildFailedResponse(ModuleQueryEnum.NOT_EXIST.getCode(), ModuleQueryEnum.NOT_EXIST.getMsg());
            } else {
                Map<String, Object> recordParams = new HashMap<>(2);
                recordParams.put("baseAppVersion", request.getBaseAppVersion());
                recordParams.put("moduleCodes", moduleCodes);
                Map<String, AppBundleRecord> latestBundleRecordMap = IHotUpdateMapper.getLatestBundleByModuleCodesWithoutFilter(recordParams);
                if (latestBundleRecordMap.get(request.getModuleCode()) != null && latestBundleRecordMap.get(request.getModuleCode()).getVersionCode() >= request.getVersionCode()) {
                    //服务器最新版本已经大于等于当前上传的版本，不能用此版本号
                    return ResponseVo.buildFailedResponse(ModuleQueryEnum.VERSION_CODE_NEW.getCode(), ModuleQueryEnum.VERSION_CODE_NEW.getMsg());
                }
            }

            //创建全量更新
            AppBundleRecord appBundleRecord = new AppBundleRecord().setModuleCode(request.getModuleCode())
                    .setBaseAppVersion(request.getBaseAppVersion())
                    .setDownloadUrl(request.getFullDownloadUrl())
                    .setRemindMode(request.getRemindMode())
                    .setUpdateFlag(request.getUpdateFlag())
                    .setVersionCode(request.getVersionCode())
                    .setUpdateTitle(request.getUpdateTitle())
                    .setUpdateDesc(request.getUpdateDesc())
                    .setIsRelease(request.getIsRelease())
                    .setVersionName(request.getModuleName() + "_" + request.getPlatform() + "_" + request.getVersionCode());

            String bundleMd5 = getBundleMd5(appBundleRecord, request.getModuleName(), request.getPlatform(), cacheDir);

            if (StringUtils.isNotBlank(bundleMd5)) {
                appBundleRecord.setFileMd5(bundleMd5);
            } else {
                FileUtils.deleteDirectory(fileCacheDir);
                return ResponseVo.buildFailedResponse(BundleCreateEnum.GET_MD5_ERROR.getCode(), BundleCreateEnum.GET_MD5_ERROR.getMsg());
            }

            appBundleRecord = IHotUpdateMapper.createNewBundle(appBundleRecord);

            if (request.getUpdateFlag().equals(BundleUpdateEnum.INCREMENT_UPDATE.getCode())) {
                //查询所有基础APP版本相同的低版本

                List<AppBundleRecord> needDiffBundleList = IHotUpdateMapper.queryNeedDiffBundle(appBundleRecord);

                //创建增量更新
                if (CollectionUtils.isNotEmpty(needDiffBundleList)) {
                    Map<Integer, AppBundleDiff> bunndleDiffMap = fileOperation(appBundleRecord, needDiffBundleList, request);

                    //插入diff数据
                    List<AppBundleDiff> appBundleDiffList = new ArrayList<>();
                    for (AppBundleRecord bundleRecord : needDiffBundleList) {
                        AppBundleDiff diff = new AppBundleDiff().setModuleCode(bundleRecord.getModuleCode())
                                .setMainBundleVersionCode(appBundleRecord.getVersionCode())
                                .setDiffVersionName(appBundleRecord.getVersionName() + "_diff_" + bundleRecord.getVersionCode())
                                .setDiffBundleVersionCode(bundleRecord.getVersionCode())
                                .setDownloadUrl(bunndleDiffMap.get(bundleRecord.getVersionCode()).getDownloadUrl())
                                .setFileMd5(bunndleDiffMap.get(bundleRecord.getVersionCode()).getFileMd5());
                        appBundleDiffList.add(diff);
                    }
                    appBundleDiffList = IHotUpdateMapper.createNewDiffs(appBundleDiffList);
                    if (CollectionUtils.isNotEmpty(appBundleDiffList) && appBundleDiffList.get(0).getId() != null) {
                        FileUtils.deleteDirectory(fileCacheDir);
                        return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS);
                    } else {
                        FileUtils.deleteDirectory(fileCacheDir);
                        return ResponseVo.buildFailedResponse(BundleCreateEnum.INCREMENTAL_FAILED.getCode(), BundleCreateEnum.INCREMENTAL_FAILED.getMsg());
                    }
                } else {
                    FileUtils.deleteDirectory(fileCacheDir);
                    return ResponseVo.buildFailedResponse(BundleCreateEnum.GET_NEED_DIFF_ERROR.getCode(), BundleCreateEnum.GET_NEED_DIFF_ERROR.getMsg());
                }

            } else {
                FileUtils.deleteDirectory(fileCacheDir);
                return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS);
            }
        } catch (Exception e) {
            FileUtils.deleteDirectory(fileCacheDir);
            return ResponseVo.buildResponse(ResponseCodeEnum.SYSTEM_EXCEPTION);
        }
    }

    @Override
    public ResponseVo createNewModule(CreateModuleRequest request) {
        if (!StringUtilCollections.letterOnly(request.getModuleName())) {
            return ResponseVo.buildFailedResponse(ModuleCreateEnum.ONLY_LETTER.getCode(), ModuleCreateEnum.ONLY_LETTER.getMsg());
        }
        AppModule module = new AppModule()
                .setModuleName(request.getModuleName())
                .setModuleDesc(request.getModuleDesc())
                .setModuleOrder(2)
                .setAppId(request.getAppId())
                .setModuleCode(Md5Utils.getMD5(request.getModuleName() + request.getPlatform(), "utf-8").substring(2, 7));
        AppModule appModule = IHotUpdateMapper.createNewModule(module);
        return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS).setObj(appModule);
    }

    @Override
    public ResponseVo queryModuleInfoByAppId(QueryModuleRequest request) {
        if (request.getPageSize() == null) {
            request.setPageSize(20);
        }

        if (request.getPageNo() == null) {
            request.setPageNo(1);
        }
        Map<String, Object> params = new HashMap<>(3);
        params.put("appId", request.getAppId());
        params.put("start", (request.getPageNo() - 1) * request.getPageSize());
        params.put("pageSize", request.getPageSize());
        try {
            List<AppModule> appModuleList = IHotUpdateMapper.queryModuleByAppId(params);
            if (CollectionUtils.isNotEmpty(appModuleList)) {
                return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS).setObj(appModuleList);
            } else {
                return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS).setObj(appModuleList).setMsg(ModuleQueryEnum.NOT_EXIST.getMsg());
            }
        } catch (Exception e) {
            return ResponseVo.buildResponse(ResponseCodeEnum.SYSTEM_EXCEPTION);
        }
    }

    @Override
    public ResponseVo queryBundleRecordByModuleCode(QueryBundleRecordRequest request) {
        Map<String, Object> params = new HashMap<>(3);
        params.put("moduleCode", request.getModuleCode());
        params.put("appId", request.getAppId());
        params.put("start", (request.getPageNo() - 1) * request.getPageSize());
        params.put("pageSize", request.getPageSize());
        try {
            int count = IHotUpdateMapper.countBundleRecordByParams(params);
            if (count > 0) {
                List<AppBundleRecord> appBundleRecordList = IHotUpdateMapper.queryBundleRecordByParams(params);
                AppBundleRecordPageResponse recordPageResponse = new AppBundleRecordPageResponse();
                recordPageResponse.setPageNo(request.getPageNo()).setTotalCount(count).setRecords(appBundleRecordList);
                return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS).setObj(recordPageResponse);
            } else {
                return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS).setMsg(ModuleQueryEnum.NOT_EXIST.getMsg());
            }
        } catch (Exception e) {
            return ResponseVo.buildResponse(ResponseCodeEnum.SYSTEM_EXCEPTION);
        }
    }

    @Override
    public ResponseVo queryBundleConfig(BundleConfigRequest request) {
        Map<String, Object> params = new HashMap<>(3);
        params.put("appId", request.getAppId());
        params.put("start", 0);
        params.put("pageSize", 1000);

        try {
            List<AppModule> moduleList = IHotUpdateMapper.queryModuleByAppId(params);

            List<String> allModuleCodeList = new ArrayList<>();

            Map<String, AppModule> moduleMap = new HashMap<>(moduleList.size());

            if (CollectionUtils.isNotEmpty(moduleList)) {
                for (AppModule module : moduleList) {
                    if (StringUtils.isNotBlank(module.getModuleCode())) {
                        allModuleCodeList.add(module.getModuleCode());
                        moduleMap.put(module.getModuleCode(), module);
                    }
                }
            }

            Map<String, Object> recordParams = new HashMap<>(2);
            recordParams.put("baseAppVersion", request.getAppVersionCode());
            recordParams.put("moduleCodes", allModuleCodeList);

            //查询最新的更新记录
            Map<String, AppBundleRecord> latestBundleRecordMap = IHotUpdateMapper.getLatestBundleByModuleCodesWithoutFilter(recordParams);
            Map<String, AppBundleRecord> latestBundleRecordMapAvailable = IHotUpdateMapper.getLatestBundleByModuleCodes(recordParams);

            List<JSONObject> newModuleList = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(moduleList)) {
                for (AppModule appModule : moduleList) {
                    JSONObject newModule = new JSONObject();
                    boolean needUpdate = false;
                    newModule.put("moduleName", appModule.getModuleName());
                    newModule.put("moduleCode", appModule.getModuleCode());
                    if (CollectionUtils.isNotEmpty(request.getModuleCode())) {
                        for (String moduleCode : request.getModuleCode()) {
                            if (moduleCode.equals(appModule.getModuleCode())) {
                                //需要更新的版本号+1
                                Integer newVersionCode = 1;
                                if (latestBundleRecordMap.get(moduleCode) == null) {
                                    newVersionCode = latestBundleRecordMap.get(moduleCode).getVersionCode() + 1;
                                }
                                newModule.put("versionCode", newVersionCode);
                                needUpdate = true;
                                break;
                            }
                        }
                    }

                    if (!needUpdate) {
                        //无需更新，用当前最新可用的版本号
                        newModule.put("versionCode", latestBundleRecordMapAvailable.get(appModule.getModuleCode()) == null ? 1 : latestBundleRecordMapAvailable.get(appModule.getModuleCode()).getVersionCode());
                    }
                    newModuleList.add(newModule);
                }
                return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS).setObj(new BundleConfigResponse().setConfig(JsonUtils.obj2Json(newModuleList, true)));
            } else {
                return ResponseVo.buildFailedResponse(BundleConfigEnum.NO_MODULE.getCode(), BundleConfigEnum.NO_MODULE.getMsg());
            }
        } catch (Exception e) {
            return ResponseVo.buildResponse(ResponseCodeEnum.SYSTEM_EXCEPTION);
        }
    }

    @Override
    public ResponseVo uploadLog(UploadLogRequest request) {

        UpdateLog updateLog = new UpdateLog().setDeviceToken(request.getDeviceToken())
                .setOsType(request.getSystemType())
                .setNetwork(request.getNetwork())
                .setUserInfo(request.getUserInfo())
                .setAppId(request.getAppId())
                .setModuleCode(request.getModuleCode())
                .setType(request.getType())
                .setAppVersionCode(request.getAppVersionCode())
                .setNativeBundleVersionCode(request.getNativeBundleVersionCode())
                .setRemoteBundleVersionCode(request.getRemoteBundleVersionCode())
                .setUpdateFlag(request.getUpdateFlag())
                .setResultCode(request.getResultCode())
                .setResultMsg(request.getResultMsg())
                .setStackLog(request.getStackLog());
        try {
            UpdateLog result = IHotUpdateMapper.insertUpdateLog(updateLog);
            if (result.getId() != null) {
                return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS);
            } else {
                return ResponseVo.buildFailedResponse(LogInsertEnum.INSERT_ERROR.getCode(), LogInsertEnum.INSERT_ERROR.getMsg());
            }
        } catch (Exception e) {
            return ResponseVo.buildResponse(ResponseCodeEnum.SYSTEM_EXCEPTION);
        }
    }


    @Override
    public HotUpdateResponse queryHotUpdateNew(UpdateQueryRequest request) {
        List<String> moduleCodeList = new ArrayList<>();
        Map<String, ReqModule> moduleMap = new HashMap<>(request.getModules().size());

        for (ReqModule module : request.getModules()) {
            if (StringUtils.isNotBlank(module.getModuleCode())) {
                moduleCodeList.add(module.getModuleCode());
                moduleMap.put(module.getModuleCode(), module);
            }
        }
        //校验appId与模块code的对应关系
        Map<String, Object> moduleParams = new HashMap<>(3);
        moduleParams.put("appId", request.getAppId());
        moduleParams.put("start", 0);
        moduleParams.put("pageSize", 1000);
        List<AppModule> appModulesInApp = IHotUpdateMapper.queryModuleByAppId(moduleParams);
        boolean appIdMatch = true;
        if (CollectionUtils.isNotEmpty(appModulesInApp)) {
            for (String moduleCode : moduleCodeList) {
                boolean isInApp = false;
                for (AppModule appModule : appModulesInApp) {
                    if (moduleCode.equals(appModule.getModuleCode())) {
                        //模块属于APP
                        isInApp = true;
                    }
                }
                if (!isInApp) {
                    appIdMatch = false;
                }
            }
        } else {
            appIdMatch = false;
        }
        if (!appIdMatch) {
            throw new BusinessException(QueryUpdateResonseEnum.APPID_NOT_MATCH.getCode(), QueryUpdateResonseEnum.APPID_NOT_MATCH.getMsg());
        }

        // 手机号白名单check
        boolean isWhiteMobile = false;
        if (StringUtil.isNotBlank(request.getMobileNum())) {
            isWhiteMobile = paramsConfig.containMobile(request.getMobileNum());
        }

        //批量查询模块信息及最新的bundle信息
        Map<String, Object> params = new HashMap<>(3);
        params.put("appVersion", request.getAppVersionCode());
        params.put("moduleCodes", moduleCodeList);
        params.put("isWhiteMobile", isWhiteMobile);

        List<AppBundleRecordList> recordLists = IHotUpdateMapper.queryBundleListByParams(params);
        if (CollectionUtils.isEmpty(recordLists)) {
            return new HotUpdateResponse();
        }
        for (AppBundleRecordList record : recordLists) {
            Map<String, Object> queryParams = new HashMap<>(3);
            queryParams.put("moduleCode", record.getModuleCode());
            queryParams.put("baseAppVersion", record.getBaseAppVersion());
            queryParams.put("isWhiteMobile", isWhiteMobile);
            record.setRecords(IHotUpdateMapper.getAppBundleRecord(queryParams));
        }


        List<Module> moduleList = getModuleList(recordLists, moduleMap);
        return new HotUpdateResponse().setModules(moduleList);
    }

    @Override
    public BundleRecordDetailResponse getBundleRecordById(Integer bundleRecordId) {
        AppBundleRecord appBundleRecord = IHotUpdateMapper.getBundleRecordById(bundleRecordId);
        if (null == appBundleRecord) {
            return null;
        }
        return ModelMapperUtil.strictMap(appBundleRecord, BundleRecordDetailResponse.class);
    }

    @Override
    public int updateAppBundleReleaseStatus(AppBundleReleaseStatusUpdateRequest request) {
        Integer isRelease = request.getIsRelease();
        if (isRelease != 0 && isRelease != 1) {
            throw new BusinessException(ResponseCodeEnum.INVALID_PARAMETER.getMsg());
        }
        Map<String, Object> params = new HashMap<>(2);
        params.put("bundleRecordId", request.getBundleRecordId());
        params.put("isRelease", isRelease);
        return IHotUpdateMapper.updateAppBundleReleaseStatus(params);
    }

    @Override
    public int updateBundleRecordById(BundleRecordUpdateRequest request) {
        AppBundleRecord bundleRecord = new AppBundleRecord();
        bundleRecord.setId(request.getId())
                .setBaseAppVersion(request.getBaseAppVersion())
                .setIsRelease(request.getIsRelease())
                .setRemindMode(request.getRemindMode())
                .setUpdateFlag(request.getUpdateFlag())
                .setUpdateDesc(request.getUpdateDesc())
                .setUpdateTitle(request.getUpdateTitle());
        return IHotUpdateMapper.updateBundleRecordById(bundleRecord);
    }

    @Override
    public int rollback(BundleRecordRollbackRequest request) {
        Map<String, Object> params = new HashMap<>(2);
        params.put("bundleRecordId", request.getBundleRecordId());
        params.put("deleteFlag", 1);
        return IHotUpdateMapper.updateBundleRecordDeleteFlag(params);
    }

    /**
     * 获取app下的所有模块的最新bundle包
     *
     * @param queryAllModuleDto app信息
     * @return 所有模块的最新bundle包
     */
    @Override
    public ResponseVo<HotUpdateResponse> queryAllModuleNewVersion(QueryAllModuleDto queryAllModuleDto) {
        //查询app版本信息
        AppVersion appVersion = versionService.queryVersion(queryAllModuleDto.getAppId(), queryAllModuleDto.getAppVersionCode());
        //查询模块版本
        List<AppModule> appModuleList = appModuleService.queryModuleList(queryAllModuleDto.getAppId());
        //模块编码
        List<String> moduleCode = appModuleList.stream().map(AppModule::getModuleCode).collect(toList());
        //查询所有模块的最新包
        List<AppBundleRecord> appBundleRecords = appBundleRecordService.queryModuleNewBundleRecord(moduleCode, appVersion.getBaseAppVersion());
        Map<String, List<AppBundleRecord>> bundleRecordMap = appBundleRecords.stream().collect(groupingBy(AppBundleRecord::getModuleCode));
        HotUpdateResponse hotUpdateResponse = new HotUpdateResponse();
        //获取最新bundle
        List<Module> modules = appModuleList.stream()
                .filter(appModule -> CollectionUtils.isNotEmpty(bundleRecordMap.get(appModule.getModuleCode()))).
                        map(appModule -> {
                            Module module = new Module();
                            List<AppBundleRecord> bundleRecords = bundleRecordMap.get(appModule.getModuleCode());
                            AppBundleRecord appBundleRecord = bundleRecords.get(0);
                            module.setModuleName(appModule.getModuleName());
                            module.setModuleCode(appModule.getModuleCode());
                            module.setUpdateFlag(appBundleRecord.getUpdateFlag());
                            module.setLatestVersionCode(appBundleRecord.getVersionCode());
                            module.setBundleFileMd5(appBundleRecord.getFileMd5());
                            module.setRemindMode(appBundleRecord.getRemindMode());
                            module.setFullUrl(appBundleRecord.getDownloadUrl());
                            return module;
                        }).collect(toList());
        hotUpdateResponse.setModules(modules);
        return ResponseVo.success(hotUpdateResponse);
    }

    @Override
    public ResponseVo queryBundleRecordByBaseband(QueryBundleRecordRequest request) {
        Map<String, Object> params = new HashMap<>(3);
        params.put("basebandVersion", request.getBasebandVersion());
        params.put("start", (request.getPageNo() - 1) * request.getPageSize());
        params.put("pageSize", request.getPageSize());
        if (StringUtils.isNotEmpty(request.getAppId())) {
            params.put("appId", request.getAppId());
        }
        try {
            int count = IHotUpdateMapper.countBundleRecordByParams(params);
            if (count > 0) {
                List<AppBundleRecord> appBundleRecordList = IHotUpdateMapper.queryBundleRecordByParams(params);
                AppBundleRecordPageResponse recordPageResponse = new AppBundleRecordPageResponse();
                recordPageResponse.setPageNo(request.getPageNo()).setTotalCount(count).setRecords(appBundleRecordList);
                return ResponseVo.buildResponse(ResponseCodeEnum.SUCCESS).setObj(recordPageResponse);
            } else {
                return ResponseVo.buildResponse(ResponseCodeEnum.FAILED).setMsg(QueryUpdateResonseEnum.NO_MODULE_RECORD.getMsg());
            }
        } catch (Exception e) {
            return ResponseVo.buildResponse(ResponseCodeEnum.SYSTEM_EXCEPTION);
        }
    }


    private String getBundleMd5(AppBundleRecord mainbundle, String moduleName, String platform, String mainBundleDir) {
        String mainBundleZipFileName = mainbundle.getVersionName() + ".zip";

        String md5;

        try {
            //下载主bundle
            FileUtils.downloadByUrl(mainbundle.getDownloadUrl(), mainBundleZipFileName, mainBundleDir);

            //解压主bundle
            FileUtils.unZip(mainBundleDir + mainBundleZipFileName, mainBundleDir);

            String mainBundleFileDir = mainBundleDir + mainbundle.getVersionName() + File.separator;

            md5 = MD5Util.getFileMD5(new File(mainBundleFileDir + moduleName + ".index." + platform + ".bundle"));

        } catch (Exception e) {
            md5 = null;
            e.printStackTrace();
        }
        return md5;
    }


    private Map<Integer, AppBundleDiff> fileOperation(AppBundleRecord mainbundle, List<AppBundleRecord> needDiffbundles, UpdateCreateRequest request) {
        File f = new File(fileCacheDir);
        String mainBundleDir = f.getPath() + File.separator + mainbundle.getVersionName() + File.separator;
        String mainBundleZipFileName = mainbundle.getVersionName() + ".zip";

        Map<Integer, AppBundleDiff> moduleDiff = new HashMap<>();
        try {
            for (AppBundleRecord needDiffBundle : needDiffbundles) {

                String needDiffBundleDir = f.getPath() + File.separator + needDiffBundle.getVersionName() + File.separator;

                String needDiffBundleZipFileName = needDiffBundle.getVersionName() + ".zip";

                FileUtils.downloadByUrl(needDiffBundle.getDownloadUrl(), needDiffBundleZipFileName, needDiffBundleDir);

                FileUtils.unZip(needDiffBundleDir + needDiffBundleZipFileName, needDiffBundleDir);

                String diffFileDir = f.getPath() + File.separator + mainbundle.getVersionName() + "_diff_" + needDiffBundle.getVersionCode();

                String diffFileZip = f.getPath() + File.separator + mainbundle.getVersionName() + "_diff_" + needDiffBundle.getVersionCode() + ".zip";

                File diffPath = new File(diffFileDir);
                if (!diffPath.exists()) {
                    diffPath.mkdirs();
                }

                String mainBundleFileDir = mainBundleDir + mainbundle.getVersionName();
                String diffbundleFileDir = needDiffBundleDir + needDiffBundle.getVersionName();

                Map<String, String> mainMap = MD5Util.getDirMD5(new File(mainBundleFileDir), true);
                Map<String, String> diffMap = MD5Util.getDirMD5(new File(diffbundleFileDir), true);

                Iterator<String> it = mainMap.keySet().iterator();
                while (it.hasNext()) {
                    String key = it.next();
                    String key2 = key.replace(mainBundleFileDir, diffbundleFileDir);
                    String value = mainMap.get(key);
                    String value2 = diffMap.remove(key2);
                    if (value2 == null) {
                        // 不存在就新增
                        String mainBundle = mainbundle.getVersionName();
                        int length = key.split(mainBundle).length;
                        if (length == 0) {
                            continue;
                        }
                        String newFile = key.split(mainBundle)[1];
                        File newfile = new File(diffFileDir + "/" + newFile);
                        File newFolder = newfile.getParentFile();
                        if (!newFolder.exists()) {
                            newFolder.mkdirs();
                        }
                        FileUtils.copyFile(key, diffFileDir + "/" + newFile);
                    } else if (!value.equals(value2)) {
                        // .meta后缀文件不处理
                        if (key.endsWith(".meta")) {
                            // 不处理
                            continue;
                        }

                        String mainPath = (mainBundleDir + mainBundleZipFileName).replace(".zip", "") + File.separator;
                        // 不相同的diff
                        String newFile = key.replace(mainPath, "");
                        diff_match_patch diff = new diff_match_patch();
                        // 读入 低版本的文件
                        String low = FileUtils.txt2String(new File(key2));
                        // 读入高版本的 文件
                        String high = FileUtils.txt2String(new File(key));
                        // 生成 Patch
                        LinkedList<diff_match_patch.Patch> patches = diff.patch_make(low, high);
                        // list转String 格式转换
                        String textline = diff.patch_toText(patches);
                        // 将diff写入文件
                        FileUtils.contentToTxt(diffPath + "/" + newFile, textline);
                    }
                }

                String diffFileMd5 = MD5Util.getFileMD5(new File(diffFileDir + File.separator + request.getModuleName() + ".index." + request.getPlatform() + ".bundle"));

                FileUtils.zip(diffFileDir, diffFileZip);
                //上传diff文件

                File diffFile = new File(diffFileZip);

                UploadFileRequest uploadFileRequest = new UploadFileRequest().setBucketType(2)
                        .setBusinessSystemName("o2o")
                        .setMultipartFile(diffFile)
                        .setSceneName("AppBundleFile");

                com.ihomefnt.common.api.ResponseVo responseVo = uploadProxy.uploadStaticFile(uploadFileRequest, mainbundle.getVersionName() + "_diff_" + needDiffBundle.getVersionCode() + ".zip");

                String downloadUrl = null;
                if (responseVo != null && responseVo.getData() != null) {
                    UploadFileResponse uploadFileResponse = JsonUtils.json2obj(JsonUtils.obj2json(responseVo.getData()), UploadFileResponse.class);
                    downloadUrl = uploadFileResponse.getFileUrl();
                }
                moduleDiff.put(needDiffBundle.getVersionCode(), new AppBundleDiff().setDownloadUrl(downloadUrl).setFileMd5(diffFileMd5));
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return moduleDiff;
    }
}
