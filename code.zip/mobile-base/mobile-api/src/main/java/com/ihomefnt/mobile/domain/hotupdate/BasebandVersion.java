package com.ihomefnt.mobile.domain.hotupdate;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ihomefnt.mobile.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * @description: 基带版本
 * @author: 何佳文
 * @date: 2019-10-08 14:21
 */
@Data
@TableName("t_app_baseband_version")
@EqualsAndHashCode(callSuper = true)
public class BasebandVersion extends BaseEntity {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 设备类型
     * 1:iPhone客户端，
     * 2:Android客户端
     */
    private Integer osType;

    private Integer basebandVersion;

    private String remark;

    private LocalDateTime createTime;

    private Integer deleteFlag;
}
