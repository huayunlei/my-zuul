package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author xiamingyu
 * @date 2018/12/20
 */

@ApiModel(description = "新增模块")
@Data
@Accessors(chain = true)
public class CreateModuleRequest extends BaseRequest {

    @ApiModelProperty("模块名称")
    private String moduleName;

    @ApiModelProperty("模块描述")
    private String moduleDesc;

    @ApiModelProperty("系统")
    private String platform;

}
