package com.ihomefnt.mobile.domain.app.dto;

import com.ihomefnt.mobile.common.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * @author xiamingyu
 */

@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
public class CreateAppDto extends BaseEntity {

    @ApiModelProperty(value = "app名称",required = true)
    private String appName;

    @ApiModelProperty(value = "app类型 1:IOS 2:Android",required = true)
    private Integer appType;

    @ApiModelProperty(value = "包名",required = true)
    private String bundleId;

    @ApiModelProperty(value = "icon图标",required = true)
    private String icon;

    @ApiModelProperty(value = "Native H5")
    private String type;

    @ApiModelProperty(value = "描述")
    private String description;

    private Integer groupId;

}