package com.ihomefnt.mobile.domain.appversion.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-15 17:56
 */
@Data
@ApiModel("查询大于最小版本号的所有版本请求参数")
public class QueryVersionListByMinVersionDto {

    @ApiModelProperty(value = "最小版本号")
    private String minVersion;

    @ApiModelProperty(value = "appId集合")
    private List<String> appIdList;

    @ApiModelProperty("项目id")
    private Integer projectId;

}
