package com.ihomefnt.mobile.config;

import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;


/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 13:58
 */
@Configuration
@EnableTransactionManagement
@MapperScan("com.ihomefnt.mobile.mapper*")
public class MybatisPlusConfiguration {

    @Bean
    public PaginationInterceptor paginationInterceptor() {
        return new PaginationInterceptor();
    }

}
