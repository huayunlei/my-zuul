package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.group.dto.*;
import com.ihomefnt.mobile.domain.group.vo.AppGroupDetailVo;
import com.ihomefnt.mobile.domain.group.vo.AppGroupVo;
import com.ihomefnt.mobile.domain.group.vo.AppVo;
import com.ihomefnt.mobile.service.AppGroupService;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/app/group")
public class AppGroupController {

    @Resource
    private AppGroupService appGroupService;

    @PostMapping("/query-page")
    @ApiOperation("分组列表")
    public ResponseVo<PageResponse<AppGroupVo>> queryPage(@RequestBody AppGroupPageDto appGroupPageDto) {
        return ResponseVo.success(appGroupService.queryPage(appGroupPageDto));
    }

    @PostMapping("/add")
    @ApiOperation("添加分组")
    public ResponseVo<String> add(@RequestBody AddAppGroupDto addAppGroupDto) {
        return appGroupService.add(addAppGroupDto);
    }

    @PostMapping("/detail")
    @ApiOperation("分组详情")
    public ResponseVo<AppGroupDetailVo> detail(@RequestBody QueryAppDto queryAppDto) {
        return ResponseVo.success(appGroupService.detail(queryAppDto));
    }

    @PostMapping("/add-app")
    @ApiOperation("添加应用到组")
    public ResponseVo<String> addApp(@RequestBody AddAppDto addAppDto) {
        return appGroupService.addApp(addAppDto);
    }

    @PostMapping("/update-app")
    @ApiOperation("修改组内应用")
    public ResponseVo<String> updateApp(@RequestBody UpdateAppDto appDto) {
        return appGroupService.updateApp(appDto);
    }

    @PostMapping("/query-app-list")
    @ApiOperation("查询组下面的应用")
    public ResponseVo<List<AppVo>> queryAppList(@RequestBody QueryAppDto queryAppDto) {
        return ResponseVo.success(appGroupService.queryAppList(queryAppDto));
    }

    @PostMapping("/delete-app")
    @ApiOperation("app移除组")
    public ResponseVo<String> deleteApp(@RequestBody DeleteAppDto deleteAppDto) {
        return appGroupService.deleteApp(deleteAppDto);
    }

}
