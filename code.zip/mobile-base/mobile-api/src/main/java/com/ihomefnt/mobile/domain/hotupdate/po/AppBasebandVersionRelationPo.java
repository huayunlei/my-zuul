package com.ihomefnt.mobile.domain.hotupdate.po;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-24 10:42
 */
@Data
@Accessors(chain = true)
public class AppBasebandVersionRelationPo {
    private Integer id;

    private Integer basebandId;

    private Integer basebandVersion;

    private Integer appVersion;

    private String remark;

    private Date createTime;

    private Integer deleteFlag;
}
