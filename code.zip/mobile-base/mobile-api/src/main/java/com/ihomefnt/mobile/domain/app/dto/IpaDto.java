package com.ihomefnt.mobile.domain.app.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class IpaDto {

    @ApiModelProperty(value = "appId",required = true)
    private String appId;

    @ApiModelProperty(value = "app版本",required = true)
    private String appVersion;

}
