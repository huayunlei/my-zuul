package com.ihomefnt.mobile.domain.monitor.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2020/1/10 2:37 下午
 */
@Data
@ApiModel("DeleteMonitorConfigRequest")
public class DeleteMonitorConfigRequest {

    @ApiModelProperty("id")
    private Integer id;

}
