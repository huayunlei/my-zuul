package com.ihomefnt.mobile.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.appversion.AppVersion;
import com.ihomefnt.mobile.domain.appversion.dto.AddVersionNewDto;

import java.util.List;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-18 15:23
 */
public interface AppVersionMapper  extends BaseMapper<AppVersion> {
    /**
     * 根据最小版本号查询
     * @param version
     * @return
     */
    ResponseVo<List<AddVersionNewDto>> queryVersionListByMinVersion(String version);
}
