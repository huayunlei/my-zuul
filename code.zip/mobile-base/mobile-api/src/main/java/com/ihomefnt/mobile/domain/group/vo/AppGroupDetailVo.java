package com.ihomefnt.mobile.domain.group.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class AppGroupDetailVo {

    @ApiModelProperty("组id")
    private Integer groupId;

    @ApiModelProperty("图标")
    private String icon;

    @ApiModelProperty("组名称")
    private String name;

    @ApiModelProperty("组下面的所有app")
    private List<AppVo> app;
}
