package com.ihomefnt.mobile.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author xiamingyu
 * @date 2018/11/22
 */

@ApiModel("基本请求参数")
@Data
@Accessors(chain = true)
public class BaseRequest {

    @ApiModelProperty("应用唯一码")
    private String appId;

}
