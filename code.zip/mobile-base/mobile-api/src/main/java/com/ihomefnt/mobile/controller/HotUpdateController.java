package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.ResponseCodeEnum;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryAllModuleDto;
import com.ihomefnt.mobile.domain.module.AppModule;
import com.ihomefnt.mobile.domain.hotupdate.vo.request.*;
import com.ihomefnt.mobile.domain.hotupdate.vo.response.*;
import com.ihomefnt.mobile.service.IHotUpdateService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author xiamingyu
 * @date 2018/11/22
 */
@Api(description = "热更新API")
@RestController
@RequestMapping(value = "/hotUpdate")
public class HotUpdateController {

    @Resource
    private IHotUpdateService hotUpdateService;

    @ApiOperation("app查询热更新")
    @PostMapping(value = "/queryUpdate")
    @ResponseBody
    public ResponseVo<HotUpdateResponse> queryUpdate(@RequestBody UpdateQueryRequest request) {
        ResponseVo responseVo;
        if (request == null || StringUtils.isBlank(request.getAppId()) || request.getAppVersionCode() == null || CollectionUtils.isEmpty(request.getModules())) {
            responseVo = ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            responseVo = hotUpdateService.queryUpdateInfo(request);
        }

        return responseVo;
    }

    @ApiOperation("创建新的更新")
    @PostMapping(value = "/createUpdate")
    @ResponseBody
    public ResponseVo createUpdate(@RequestBody UpdateCreateRequest request) {
        ResponseVo responseVo;
        if (request == null || StringUtils.isBlank(request.getAppId()) || StringUtils.isBlank(request.getModuleCode()) || request.getBaseAppVersion() == null || request.getUpdateFlag() == null) {
            responseVo = ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            responseVo = hotUpdateService.createUpdate(request);
        }

        return responseVo;
    }

    @ApiOperation("创建新的模块")
    @PostMapping(value = "/createNewModule")
    @ResponseBody
    public ResponseVo createNewModule(@RequestBody CreateModuleRequest request) {
        ResponseVo responseVo;

        if (request == null || StringUtils.isBlank(request.getAppId()) || StringUtils.isBlank(request.getModuleName())) {
            responseVo = ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            responseVo = hotUpdateService.createNewModule(request);
        }

        return responseVo;
    }

    @ApiOperation("根据APPID分页查询所有模块")
    @PostMapping(value = "/getModuleInfoByAppId")
    @ResponseBody
    public ResponseVo<List<AppModule>> getModuleInfoByAppId(@RequestBody QueryModuleRequest request) {
        ResponseVo responseVo;
        if (request == null || StringUtils.isBlank(request.getAppId())) {
            responseVo = ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            responseVo = hotUpdateService.queryModuleInfoByAppId(request);
        }

        return responseVo;
    }

    @ApiOperation("根据模块唯一码查询模块更新记录")
    @PostMapping(value = "/getBundleRecordByModuleCode")
    @ResponseBody
    public ResponseVo<AppBundleRecordPageResponse> getBundleRecordByModuleCode(@RequestBody QueryBundleRecordRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId())) {
            return ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            return hotUpdateService.queryBundleRecordByModuleCode(request);
        }
    }

    @ApiOperation("上传更新日志")
    @PostMapping(value = "/uploadLog")
    public ResponseVo uploadLog(@RequestBody UploadLogRequest request) {
        ResponseVo responseVo;
        if (request == null || StringUtils.isBlank(request.getAppId())) {
            responseVo = ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            responseVo = hotUpdateService.uploadLog(request);
        }

        return responseVo;
    }

    @ApiOperation("获取APP打包的配置信息")
    @PostMapping(value = "/getAppBundleConfig")
    public ResponseVo<BundleConfigResponse> getAppBundleConfig(@RequestBody BundleConfigRequest request) {
        ResponseVo<BundleConfigResponse> responseVo;
        if (request == null || StringUtils.isBlank(request.getAppId())) {
            responseVo = ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            responseVo = hotUpdateService.queryBundleConfig(request);
        }

        return responseVo;
    }


    @ApiOperation("app查询热更新-new")
    @PostMapping(value = "/queryHotUpdateNew")
    @ResponseBody
    public ResponseVo<HotUpdateResponse> queryHotUpdateNew(@RequestBody UpdateQueryRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId()) || request.getAppVersionCode() == null || CollectionUtils.isEmpty(request.getModules())) {
            return ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        }

        HotUpdateResponse response = hotUpdateService.queryHotUpdateNew(request);
        return ResponseVo.success(response);
    }

    @ApiOperation("根据id查询模块更新记录")
    @PostMapping(value = "/getBundleRecordDetailById")
    public ResponseVo<BundleRecordDetailResponse> getBundleRecordById(@RequestBody BundleRecordDetailQueryRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId()) || null == request.getBundleRecordId()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        }

        BundleRecordDetailResponse response = hotUpdateService.getBundleRecordById(request.getBundleRecordId());
        return ResponseVo.success(response);
    }

    @ApiOperation("发布或下架app bundle")
    @PostMapping(value = "/updateAppBundleReleaseStatus")
    public ResponseVo<Void> updateAppBundleReleaseStatus(@RequestBody AppBundleReleaseStatusUpdateRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId()) || null == request.getBundleRecordId() || null == request.getIsRelease()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        }

        int count = hotUpdateService.updateAppBundleReleaseStatus(request);
        if (count < 1) {
            return ResponseVo.buildResponse(ResponseCodeEnum.HANDLE_FAILED);
        }
        return ResponseVo.success();
    }

    @ApiOperation("更新bundleRecord记录")
    @PostMapping(value = "/updateBundleRecordById")
    public ResponseVo<Void> updateBundleRecordById(@RequestBody BundleRecordUpdateRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId()) || null == request.getId()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        }

        int count = hotUpdateService.updateBundleRecordById(request);
        if (count < 1) {
            return ResponseVo.buildResponse(ResponseCodeEnum.HANDLE_FAILED);
        }
        return ResponseVo.success();
    }

    @ApiOperation("回滚删除bundleRecord记录")
    @PostMapping(value = "/rollback")
    public ResponseVo<Void> rollback(@RequestBody BundleRecordRollbackRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId()) || null == request.getBundleRecordId()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        }

        int count = hotUpdateService.rollback(request);
        if (count < 1) {
            return ResponseVo.buildResponse(ResponseCodeEnum.HANDLE_FAILED);
        }
        return ResponseVo.success();
    }


    @ApiOperation("查询所有模块的最新版本")
    @PostMapping(value = "/queryAllModuleNewVersion")
    public ResponseVo<HotUpdateResponse> queryAllModuleNewVersion(@RequestBody QueryAllModuleDto request) {
        return hotUpdateService.queryAllModuleNewVersion(request);
    }

    @ApiOperation("根据基带查询模块更新记录")
    @PostMapping(value = "/queryBundleRecordByBaseband")
    @ResponseBody
    public ResponseVo<AppBundleRecordPageResponse> queryBundleRecordByBaseband(@RequestBody QueryBundleRecordRequest request) {
        if (request == null || null == request.getBasebandVersion()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.INVALID_PARAMETER);
        } else {
            return hotUpdateService.queryBundleRecordByBaseband(request);
        }
    }

}
