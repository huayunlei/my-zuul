package com.ihomefnt.mobile.domain.appversion.vo;

import com.ihomefnt.mobile.domain.appversion.dto.VersionNewDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("版本查询返回")
@Data
public class VersionNewVo extends VersionNewDto {

    @ApiModelProperty("最近强更版本号")
    private String mustUpdateVersion;

    @ApiModelProperty("当前版本是否强更标记")
    private Boolean must;

    @ApiModelProperty("App名称")
    private String appTypeName;

}
