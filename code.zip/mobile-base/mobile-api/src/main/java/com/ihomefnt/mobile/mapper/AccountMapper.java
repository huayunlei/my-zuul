package com.ihomefnt.mobile.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ihomefnt.mobile.domain.account.Account;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-12 10:34
 */
public interface AccountMapper extends BaseMapper<Account> {
}
