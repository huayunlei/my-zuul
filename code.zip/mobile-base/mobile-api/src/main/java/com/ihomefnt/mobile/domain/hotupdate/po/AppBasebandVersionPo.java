package com.ihomefnt.mobile.domain.hotupdate.po;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-24 10:40
 */
@Data
@Accessors(chain = true)
public class AppBasebandVersionPo {

    private Integer id;

    private String appId;

    private Integer osType; // 设备类型,1:iPhone客户端，2:Android客户端

    private Integer basebandVersion;

    private String remark;

    private Date createTime;

    private Integer deleteFlag;
}
