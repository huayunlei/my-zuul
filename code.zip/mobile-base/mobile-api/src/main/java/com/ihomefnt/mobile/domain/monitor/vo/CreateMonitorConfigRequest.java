package com.ihomefnt.mobile.domain.monitor.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-27 11:29
 */
@Data
@ApiModel("CreateMonitorConfigRequest")
public class CreateMonitorConfigRequest {

    /**
     * appId
     */
    @ApiModelProperty("appId")
    private String appId;

    /**
     * 监控业务key
     */
    @ApiModelProperty("监控业务配置key")
    private String monitorKey;

    /**
     * 告警等级
     */
    @ApiModelProperty("告警等级（高，中，低）")
    private String monitorLevel;

    /**
     * 告警信息
     */
    @ApiModelProperty("告警信息")
    private String monitorDesc;

    /**
     * 钉钉告警群名称
     */
    @ApiModelProperty("钉钉告警群名称")
    private String monitorDingName;

    /**
     * 钉钉群token
     */
    @ApiModelProperty("钉钉群token")
    private String monitorDingToken;


}
