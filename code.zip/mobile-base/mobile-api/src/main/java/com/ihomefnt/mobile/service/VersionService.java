/*
 * Copyright (C) 2006-2016 AiJia All rights reserved
 * Author: zhang
 * Date: 2017年6月20日
 * Description:VersionService.java
 */
package com.ihomefnt.mobile.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ihomefnt.mobile.common.BasePageRequest;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.appversion.AppVersion;
import com.ihomefnt.mobile.domain.appversion.dto.*;
import com.ihomefnt.mobile.domain.appversion.vo.VersionNewVo;
import com.ihomefnt.mobile.domain.appversion.vo.VersionVo;

import java.util.List;

/**
 * @author zhang
 */
public interface VersionService extends IService<AppVersion> {


    /**
     * 查询最新版本（新）
     *
     * @param request
     * @return
     */
    VersionNewVo queryLatestAppNew(VersionQueryNewDto request);

    /**
     * 查询APP版本描述列表
     *
     * @param request
     * @return
     */
    PageResponse<VersionVo> queryAppVersionListNew(BasePageRequest request);

    /**
     * 添加APP版本描述
     *
     * @param request
     * @return
     */
    boolean addAppVersion(AddVersionNewDto request);


    /**
     * 更新APP版本描述
     *
     * @param request
     * @return
     */
    ResponseVo updateAppVersion(UpdateVersionDto request);

    /**
     * @param id app版本Id
     * @return
     */
    ResponseVo putAway(Integer id);

    /**
     * 根据appId获取最新的版本
     *
     * @param appId appId
     * @return 最新的版本
     */
    AppVersion queryVersion(String appId,Integer appVersionCode);

    /**
     * 根据最小版本号查询版本号信息
     *
     * @param request
     * @return
     */
    List<AppVersion> queryRecordListByMinVersion(QueryVersionListByMinVersionDto request);

    /**
     * 更新记录
     * @param pageDto
     * @return
     */
    PageResponse<VersionVo> queryPage(VersionPageDto pageDto);

    /**
     * 查询最后一个版本
     * @param appId  appId
     * @return 版本信息
     */
    AppVersion queryLatestApp(String appId);

    /**
     * 删除版本
     * @param version
     * @return
     */
    ResponseVo batchDelete(DeleteVersionDto version);
}
