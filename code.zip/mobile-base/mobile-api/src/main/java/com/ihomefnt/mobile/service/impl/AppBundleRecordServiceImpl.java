package com.ihomefnt.mobile.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.mobile.domain.appversion.AppVersion;
import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import com.ihomefnt.mobile.domain.hotupdate.vo.response.Module;
import com.ihomefnt.mobile.mapper.AppBundleRecordMapper;
import com.ihomefnt.mobile.service.AppBundleRecordService;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.management.Query;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-26 11:18
 */
@Service
public class AppBundleRecordServiceImpl extends ServiceImpl<AppBundleRecordMapper, AppBundleRecord> implements AppBundleRecordService {

    @Resource
    private AppBundleRecordMapper appBundleRecordMapper;

    @Override
    public List<AppBundleRecord> queryModuleNewBundleRecord(List<String> moduleList, Integer baseAppVersion) {
        List<AppBundleRecord> appBundleRecords = new ArrayList<>();
        for (String moduleCode : moduleList) {
            AppBundleRecord appBundleRecord = queryNewBundleRecord(moduleCode, baseAppVersion);
            if(appBundleRecord!=null){
                appBundleRecords.add(appBundleRecord);
            }
        }
        return appBundleRecords;
    }

    @Override
    public AppBundleRecord queryLatestBundle(String moduleCode) {
        QueryWrapper<AppBundleRecord> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppBundleRecord::getModuleCode, moduleCode)
                .eq(AppBundleRecord::getDeleteFlag, 0);
        Page<AppBundleRecord> appVersionIPage = new Page<>(1, 1);
        appVersionIPage.setDesc("version_code");
        List<AppBundleRecord> bundleRecords = appBundleRecordMapper.selectPage(appVersionIPage, queryWrapper).getRecords();
        if (!CollectionUtils.isEmpty(bundleRecords)) {
            return bundleRecords.get(0);
        }
        return null;
    }


    /**
     * 查询最新的bundle
     *
     * @param moduleCode     模块编码
     * @param baseAppVersion 基带版本号
     * @return 最新包
     */
    private AppBundleRecord queryNewBundleRecord(String moduleCode, Integer baseAppVersion) {
        QueryWrapper<AppBundleRecord> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppBundleRecord::getModuleCode, moduleCode)
                .eq(AppBundleRecord::getBaseAppVersion, baseAppVersion)
                .eq(AppBundleRecord::getDeleteFlag, 0);
        Page<AppBundleRecord> appVersionIPage = new Page<>(1, 1);
        appVersionIPage.setDesc("version_code");
        List<AppBundleRecord> bundleRecords = appBundleRecordMapper.selectPage(appVersionIPage, queryWrapper).getRecords();
        if (!CollectionUtils.isEmpty(bundleRecords)) {
            return bundleRecords.get(0);
        }
        return null;
    }

}
