/*
 * Copyright (C) 2006-2016 AiJia All rights reserved
 * Author: zhang
 * Date: 2017年6月20日
 * Description:VersionServiceImpl.java
 */
package com.ihomefnt.mobile.service.impl;

import com.alibaba.nacos.api.config.annotation.NacosValue;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.common.util.ModelMapperUtil;
import com.ihomefnt.mobile.common.BasePageRequest;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.common.utils.cache.RedisCacheUtil;
import com.ihomefnt.mobile.constant.common.CacheConstant;
import com.ihomefnt.mobile.domain.app.App;
import com.ihomefnt.mobile.domain.appversion.AppVersion;
import com.ihomefnt.mobile.domain.appversion.dto.*;
import com.ihomefnt.mobile.domain.appversion.vo.VersionNewVo;
import com.ihomefnt.mobile.domain.appversion.vo.VersionVo;
import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import com.ihomefnt.mobile.domain.hotupdate.vo.request.UpdateCreateRequest;
import com.ihomefnt.mobile.mapper.AppBundleRecordMapper;
import com.ihomefnt.mobile.mapper.AppMapper;
import com.ihomefnt.mobile.mapper.AppVersionMapper;
import com.ihomefnt.mobile.service.IHotUpdateService;
import com.ihomefnt.mobile.service.VersionService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;


/**
 * @author zhang
 */
@Slf4j
@Service
public class VersionServiceImpl extends ServiceImpl<AppVersionMapper, AppVersion> implements VersionService {


    @Resource
    private AppVersionMapper appVersionMapper;

    @Resource
    private AppBundleRecordMapper appBundleRecordMapper;

    @Resource
    private IHotUpdateService iHotUpdateService;

    @Resource
    private RedisCacheUtil redisCacheUtil;

    @Resource
    private AppMapper appMapper;

    @Resource
    private RedissonClient redissonClient;

    @NacosValue(value = "${app.partnervalue.type.name}", autoRefreshed = true)
    private String appPartnerValueTypeName;


    @Override
    public PageResponse<VersionVo> queryAppVersionListNew(BasePageRequest request) {
        try {
            PageResponse<VersionVo> response = new PageResponse<>();
            Page<AppVersion> appVersionIPage = new Page<>(request.getPageNo(), request.getPageSize());
            QueryWrapper<AppVersion> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(AppVersion::getAppId, request.getAppId())
                    .eq(AppVersion::getDelFlag, 0);
            if (null != request.getBasebandVersion() && request.getBasebandVersion() > 0) {
                queryWrapper.lambda().eq(AppVersion::getBaseAppVersion, request.getBasebandVersion());
            }
            appVersionIPage.setDesc("type");
            appVersionIPage.setDesc("version_comment");
            appVersionIPage.setDesc("v_id");
            IPage<AppVersion> page = appVersionMapper.selectPage(appVersionIPage, queryWrapper);

            List<VersionVo> versionResponses = page.getRecords().stream().map(appVersion -> {
                VersionVo versionResponse = new VersionVo();
                versionResponse.setAppType(appVersion.getType());
                AppPartnerValueTypeNameDto appTypeDto = getAppTypeDto("", appVersion.getType());
                versionResponse.setAppTypeName(appTypeDto.getAppTypeName());
                versionResponse.setDownload(appVersion.getDownload());
                boolean must = false;//强制更新标志  0不更新   1更新
                if (appVersion.getUpdateFlag() != null && appVersion.getUpdateFlag().equals(1)) {
                    must = true;
                }
                versionResponse.setPutAwayState(appVersion.getPutAwayState());
                versionResponse.setMust(must);
                versionResponse.setPartnerValue(appVersion.getPartnerValue());
                versionResponse.setUpdateContent(appVersion.getUpdateContent());
                versionResponse.setUpdateTime(appVersion.getUpdateTime());
                versionResponse.setVersion(appVersion.getVersion());
                versionResponse.setVId(appVersion.getVId());
                versionResponse.setOperator(appVersion.getOperator());
                versionResponse.setBaseAppVersion(appVersion.getBaseAppVersion());
                return versionResponse;
            }).collect(toList());

            response.setTotalPage(page.getPages());
            response.setTotalCount(page.getTotal());
            response.setPageNo(request.getPageNo());
            response.setPageSize(request.getPageSize());

            response.setList(versionResponses);
            return response;
        } catch (Exception e) {
            log.error("VersionService.queryAppVersionListNew ERROR", e);
            return null;
        }
    }

    @Override
    public boolean addAppVersion(AddVersionNewDto request) {
        try {
            AppVersion appVersion = new AppVersion();
            appVersion.setAppId(request.getAppId());
            appVersion.setDownload(request.getDownload());
            appVersion.setType(request.getAppType());
            appVersion.setVersion(request.getVersion());
            appVersion.setOperator(request.getOperator());
            appVersion.setVersionComment(initVersionComment(request.getVersion()));
            appVersion.setPutAwayState(0);
            appVersion.setBaseAppVersion(request.getBaseAppVersion());
            appVersion.setIpaDownloadUrl(request.getIpaDownloadUrl());
            appVersion.setCreateTime(LocalDateTime.now());
            appVersion.setUpdateTime(LocalDateTime.now());
            appVersion.setPutAwayState(request.getPutAwayState());
            appVersion.setUpdateFlag(request.getUpdateFlag());

            //todo 艾家生活IOS暂时替换为app store的地址
            if (request.getAppType() == 1 && "washriwvd8c6r6nz".equals(request.getAppId())) {
                appVersion.setIpaDownloadUrl(request.getDownload());
                appVersion.setDownload("https://itunes.apple.com/cn/app/ai-jia-jia-ju/id964151928?mt=8");
            }

            appVersion.setUpdateContent(JsonUtils.obj2json(request.getUpdateContent()));

            int result = appVersionMapper.insert(appVersion);
            if (CollectionUtils.isNotEmpty(request.getBindBundles())) {
                for (BindBundleDto bindBundleDto : request.getBindBundles()) {
                    QueryWrapper<AppBundleRecord> queryWrapper = new QueryWrapper<>();
                    queryWrapper.lambda().eq(AppBundleRecord::getModuleCode, bindBundleDto.getModuleCode())
                            .eq(AppBundleRecord::getVersionCode, bindBundleDto.getVersionCode())
                            .eq(AppBundleRecord::getBaseAppVersion, request.getBaseAppVersion())
                            .eq(AppBundleRecord::getDeleteFlag, 0);
                    AppBundleRecord appBundleRecord = appBundleRecordMapper.selectOne(queryWrapper);
                    //如果随包发布的bundle版本不存在存在,则发布
                    if (appBundleRecord == null) {
                        UpdateCreateRequest updateCreateRequest = bindBundleDto.transform(UpdateCreateRequest.class)
                                .setBaseAppVersion(request.getBaseAppVersion())
                                .setPlatform(request.getAppType() == 1 ? "ios" : "android")
                                .setIsRelease(0)
                                .setRemindMode(1)
                                .setUpdateFlag(1);
                        updateCreateRequest.setAppId(request.getAppId());
                        iHotUpdateService.createUpdate(updateCreateRequest);
                    } else {
                        //未上线的重发一次
                        if (appBundleRecord.getIsRelease() == 0) {
                            appBundleRecordMapper.deleteById(appBundleRecord.getId());
                            UpdateCreateRequest updateCreateRequest = bindBundleDto.transform(UpdateCreateRequest.class)
                                    .setBaseAppVersion(request.getBaseAppVersion())
                                    .setPlatform(request.getAppType() == 1 ? "ios" : "android")
                                    .setIsRelease(0)
                                    .setRemindMode(1)
                                    .setUpdateFlag(1);
                            updateCreateRequest.setAppId(request.getAppId());
                            iHotUpdateService.createUpdate(updateCreateRequest);
                        }
                    }
                }
            }
            //删除缓存
            String versionCacheKey = redisCacheUtil.generateCacheKey(CacheConstant.APP_VERSION_UPDATE, request.getAppId());
            redissonClient.getBucket(versionCacheKey).delete();
            return result > 0;
        } catch (Exception e) {
            log.error("VersionService.addAppVersion ERROR", e);
            return false;
        }
    }

    @Override
    public ResponseVo updateAppVersion(UpdateVersionDto request) {
        AppVersion appVersion = appVersionMapper.selectById(request.getVId());
        appVersion.setBaseAppVersion(request.getBaseAppVersion());
        appVersion.setVersion(request.getVersion());
        if (CollectionUtils.isNotEmpty(request.getUpdateContent())) {
            appVersion.setUpdateContent(JsonUtils.obj2json(request.getUpdateContent()));
        }
        appVersion.setVersionComment(Integer.parseInt(request.getVersion().replaceAll("\\.", "0")));
        appVersion.setUpdateTime(LocalDateTime.now());
        appVersionMapper.updateById(appVersion);
        //删除缓存
        String versionCacheKey = redisCacheUtil.generateCacheKey(CacheConstant.APP_VERSION_UPDATE, appVersion.getAppId());
        redissonClient.getBucket(versionCacheKey).delete();
        return ResponseVo.success();
    }

    @Override
    public ResponseVo putAway(Integer id) {
        AppVersion appVersion = appVersionMapper.selectById(id);
        if (appVersion == null || appVersion.getDelFlag() == 1) {
            return ResponseVo.fail("该版本不存在");
        }
        appVersion.setPutAwayState(1);
        appVersionMapper.updateById(appVersion);
        return ResponseVo.success();
    }

    /**
     * 获取最新的App版本
     *
     * @param appId appId
     * @return app版本
     */
    @Override
    public AppVersion queryVersion(String appId, Integer appVersionCode) {
        QueryWrapper<AppVersion> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppVersion::getAppId, appId)
                .eq(AppVersion::getVersionComment, appVersionCode)
                .eq(AppVersion::getDelFlag, 0);
        return appVersionMapper.selectOne(queryWrapper);
    }

    @Override
    public VersionNewVo queryLatestAppNew(VersionQueryNewDto request) {
        try {

            String versionCacheKey = redisCacheUtil.generateCacheKey(CacheConstant.APP_VERSION_UPDATE, request.getAppId());
            RBucket<VersionNewVo> versionBucket = redissonClient.getBucket(versionCacheKey);
            if (null != versionBucket.get()) {
                return versionBucket.get();
            }
            QueryWrapper<AppVersion> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(AppVersion::getAppId, request.getAppId());
            //查询已经上架的
            queryWrapper.lambda().eq(AppVersion::getPutAwayState, 1)
                    .eq(AppVersion::getDelFlag, 0);
            Page<AppVersion> page = new Page<>(1, 1);
            page.setDesc("version_comment");
            page.setDesc("v_id");
            List<AppVersion> appVersionList = appVersionMapper.selectPage(page, queryWrapper).getRecords();
            if (CollectionUtils.isEmpty(appVersionList)) {
                return new VersionNewVo();
            }

            AppVersion appVersion = appVersionList.get(0);
            VersionNewVo result = ModelMapperUtil.strictMap(appVersion, VersionNewVo.class);
            if (result.getUpdateFlag() != null && 1 == result.getUpdateFlag()) {
                result.setMust(true);
            } else {
                result.setMust(false);
            }
            // 查询最近的强更版本号
            queryWrapper.lambda().eq(AppVersion::getUpdateFlag, 1);
            List<AppVersion> records = appVersionMapper.selectPage(page, queryWrapper).getRecords();
            if (CollectionUtils.isNotEmpty(records)) {
                appVersion = records.get(0);
                result.setMustUpdateVersion(appVersion.getVersion());
            }
            versionBucket.set(result, 1, TimeUnit.HOURS);
            return result;
        } catch (Exception e) {
            log.error("VersionService.queryLatestAppNew ERROR", e);
            return null;
        }

    }

    @Override
    public List<AppVersion> queryRecordListByMinVersion(QueryVersionListByMinVersionDto request) {
        List<String> appIdList = request.getAppIdList();
        if (CollectionUtils.isEmpty(appIdList)) {
            LambdaQueryWrapper<App> appLambdaQueryWrapper = new LambdaQueryWrapper<>();
            appLambdaQueryWrapper.eq(App::getDeleteFlag, 0);
            List<App> apps = appMapper.selectList(appLambdaQueryWrapper);
            appIdList = apps.stream().map(App::getAppId).collect(Collectors.toList());
        }
        if (CollectionUtils.isNotEmpty(appIdList)) {
            LambdaQueryWrapper<AppVersion> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.ge(AppVersion::getVersion, request.getMinVersion())
                    .in(AppVersion::getAppId, appIdList)
                    .eq(AppVersion::getDelFlag, 0);
            return appVersionMapper.selectList(queryWrapper);
        }
        return Collections.emptyList();
    }

    @Override
    public PageResponse<VersionVo> queryPage(VersionPageDto pageDto) {
        PageResponse<VersionVo> response = new PageResponse<>();
        QueryWrapper<AppVersion> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppVersion::getDelFlag, 0);
        if (StringUtils.isNotEmpty(pageDto.getAppId())) {
            queryWrapper.lambda().eq(AppVersion::getAppId, pageDto.getAppId());
        }
        if (pageDto.getPutAwayState() != null) {
            queryWrapper.lambda().eq(AppVersion::getPutAwayState, pageDto.getPutAwayState());
        }
        if (StringUtils.isNotEmpty(pageDto.getAppName())) {
            QueryWrapper<App> appQueryWrapper = new QueryWrapper<>();
            appQueryWrapper.lambda().like(App::getAppName, pageDto.getAppName());
            List<String> appIds = appMapper.selectList(appQueryWrapper).stream().map(App::getAppId).collect(toList());
            if (CollectionUtils.isNotEmpty(appIds)) {
                queryWrapper.lambda().in(AppVersion::getAppId, appIds);
            }
        }
        if (pageDto.getAppType() != null) {
            queryWrapper.lambda().eq(AppVersion::getType, pageDto.getAppType());
        }
        Page<AppVersion> appVersionIPage = new Page<>(pageDto.getPageNo(), pageDto.getPageSize());
        appVersionIPage.setDesc("create_time");
        IPage<AppVersion> page = appVersionMapper.selectPage(appVersionIPage, queryWrapper);
        List<VersionVo> versionVoList = page.getRecords().stream().map(appVersion -> {
            VersionVo versionVo = appVersion.transform(VersionVo.class);
            QueryWrapper<App> appQueryWrapper = new QueryWrapper<>();
            appQueryWrapper.lambda().eq(App::getAppId, appVersion.getAppId())
                    .eq(App::getDeleteFlag, 0);
            App app = appMapper.selectOne(appQueryWrapper);
            if (app != null) {
                versionVo.setAppType(app.getAppType());
                versionVo.setAppId(app.getAppId());
                versionVo.setAppName(app.getAppName());
                versionVo.setIcon(app.getIcon());
            }
            return versionVo;
        }).collect(toList());
        response.setTotalPage(page.getPages());
        response.setTotalCount(page.getTotal());
        response.setPageNo(pageDto.getPageNo());
        response.setPageSize(pageDto.getPageSize());
        response.setList(versionVoList);
        return response;
    }

    /**
     * 查询最后一个版本
     *
     * @param appId appId
     * @return 版本信息
     */
    @Override
    public AppVersion queryLatestApp(String appId) {
        QueryWrapper<AppVersion> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(AppVersion::getAppId, appId)
                .eq(AppVersion::getDelFlag, 0);
        Page<AppVersion> appVersionIPage = new Page<>(1, 1);
        appVersionIPage.setDesc("v_id");
        List<AppVersion> appVersionList = appVersionMapper.selectPage(appVersionIPage, queryWrapper).getRecords();
        if (!org.springframework.util.CollectionUtils.isEmpty(appVersionList)) {
            return appVersionList.get(0);
        }
        return null;
    }

    @Override
    public ResponseVo batchDelete(DeleteVersionDto version) {
        QueryWrapper<AppVersion> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().in(AppVersion::getVId, version.getIds());
        List<AppVersion> appVersionList = appVersionMapper.selectList(queryWrapper);
        appVersionList.forEach(appVersion -> {
            appVersion.setDelFlag(1);
            appVersionMapper.updateById(appVersion);
            String versionCacheKey = redisCacheUtil.generateCacheKey(CacheConstant.APP_VERSION_UPDATE, appVersion.getAppId());
            redissonClient.getBucket(versionCacheKey).delete();
        });
        return ResponseVo.success();
    }

    private int initVersionComment(String version) {
        String[] versionList = version.split("\\.");
        double versionComment = 0;
        for (int i = 0; i < versionList.length; i++) {
            versionComment += Integer.parseInt(versionList[i].trim()) * Math.pow(100, (versionList.length - 1 - i));// 用100进制转为int，做排序使用
        }
        return (int) versionComment;
    }

    private AppPartnerValueTypeNameDto getAppTypeDto(String partnerValue, Integer appType) {
        List<AppPartnerValueTypeNameDto> demo = JsonUtils.json2list(appPartnerValueTypeName, AppPartnerValueTypeNameDto.class);
        for (AppPartnerValueTypeNameDto dto : demo) {
            if (appType != null && appType != 0) {
                if (dto.getAppType().equals(appType)) {
                    return dto;
                }
            } else {
                if (dto.getPartnerValue().contains(partnerValue)) {
                    return dto;
                }
            }
        }
        return null;
    }

}
