package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-24 10:40
 */
@ApiModel(description = "BasebandVersionRequest")
@Data
@Accessors(chain = true)
public class BasebandVersionRequest extends BaseRequest {

    @ApiModelProperty(value = "设备类型,1:iPhone客户端，2:Android客户端")
    private Integer osType; // 设备类型,1:iPhone客户端，2:Android客户端

    @ApiModelProperty(value = "基带版本号")
    private Integer basebandVersion;

    @ApiModelProperty(value = "备注描述")
    private String remark;

}
