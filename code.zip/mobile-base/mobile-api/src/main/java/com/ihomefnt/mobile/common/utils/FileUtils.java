package com.ihomefnt.mobile.common.utils;

import org.apache.commons.lang.StringUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;

/**
 * 文件工具类
 * @author ZHAO
 */
public class FileUtils {
	
	/**
	 * 获得文件名称后缀
	 * 
	 * @param fileName
	 * @return
	 */
	public static String getExtention(String fileName) {
		return fileName == null ? "" : fileName.substring(fileName
				.lastIndexOf("."));
	}

	/**
	 * 根据日前获得文件夹名称
	 * 
	 * @param baseDir
	 *            根目录
	 * @param mask
	 *            日前格式，默认为yyyy/MM/dd
	 * @return
	 */
	public static String createDirByDate(String baseDir, String mask) {
		//baseDir = ConfigUtil.getString("auto_upload_baseDir");
		StringBuffer path = new StringBuffer();
		if (StringUtils.isNotBlank(baseDir)) {
			path.append(baseDir);
			if (!baseDir.endsWith("/")) {
				path.append("/");
			}
		} else {
			path.append("/");
		}

		if (StringUtils.isBlank(mask)) {
			mask = "yyyy/MM/dd";
		}
		String temp[] = new SimpleDateFormat(mask).format(new Date())
				.split("/");
		for (int i = 0; null != temp && i < temp.length; i++) {
			path.append(temp[i]);
			path.append("/");
		}
		String dir = path.toString();
		File file = new File(dir);
		if (!file.exists()) {
			file.mkdirs();
		}
		return dir;
	}

	/**
	 * 下载文件
	 * 
	 * @param filePath
	 *            文件路径
	 * @param fileName
	 *            用户打开的下载窗口中显示的文件名
	 * @param response
	 *            response对象
	 */
	public static void downloadFile(String filePath, String fileName,
			HttpServletResponse response) {
		response.reset();
		InputStream is = null;
		OutputStream os = null;
		try {
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename="
					+ new String((fileName).getBytes("GBK"), "ISO8859-1"));
			is = new FileInputStream(new File(filePath));
			os = new BufferedOutputStream(response.getOutputStream());
			byte[] bytes = new byte[10240];
			int len;
			while ((len = is.read(bytes)) != -1) {
				os.write(bytes, 0, len);
			}
		} catch (Exception ex) {
             ex.printStackTrace(); 
		} finally {
			try {
				os.flush();
				os.close();
				is.close();
			} catch (IOException e) {

			}
		}
	}
	/**
	 * 
	 *<p>删除文件</p>
	 * @Author: hudaofa
	 * @Date: 2012-8-6上午10:43:45
	 * @param sPath
	 * @return
	 */
	public static boolean deleteFile(String sPath) {   
		boolean flag = false;   
	    File file = new File(sPath);   
	    // 路径为文件且不为空则进行删除   
	    if (file.isFile() && file.exists()) {   
	        file.delete();   
	        flag = true;   
	    }   
	    return flag;   
	}  
	
	/**
	 * 
	 *<p>删除目录</p>
	 * @Author: hudaofa
	 * @Date: 2012-8-6上午10:44:35
	 * @param sPath
	 * @return
	 */
	public static  boolean deleteDirectory(String sPath) {   
	    //如果sPath不以文件分隔符结尾，自动添加文件分隔符   
	    if (!sPath.endsWith(File.separator)) {   
	        sPath = sPath + File.separator;   
	    }   
	    File dirFile = new File(sPath);   
	    //如果dir对应的文件不存在，或者不是一个目录，则退出   
	    if (!dirFile.exists() || !dirFile.isDirectory()) {   
	        return false;   
	    }   
	    boolean flag = true;   
	    //删除文件夹下的所有文件(包括子目录)   
	    File[] files = dirFile.listFiles();   
	    for (int i = 0; i < files.length; i++) {   
	        //删除子文件   
	        if (files[i].isFile()) {   
	            flag = deleteFile(files[i].getAbsolutePath());
				if (flag) {
					continue;
				}
				break;
			} //删除子目录
	        else {   
	            flag = deleteDirectory(files[i].getAbsolutePath());   
	            if (!flag) {
					break;
				}
	        }   
	    }   
	    if (!flag) {
			return false;
		}
	    //删除当前目录   
	    if (dirFile.delete()) {   
	        return true;   
	    } else {   
	        return false;   
	    }   
	}  
	
	/**
	 * 
	 *<p>删除文件夹下面所有的文件，不包含目录</p>
	 * @Author: chenjuya
	 * @Date: 2012-8-27下午01:23:09
	 * @param sPath
	 * @return
	 */
	public static  boolean deleteDirectoryFiles(String sPath) {   
	    //如果sPath不以文件分隔符结尾，自动添加文件分隔符   
	    if (!sPath.endsWith(File.separator)) {   
	        sPath = sPath + File.separator;   
	    }   
	    File dirFile = new File(sPath);   
	    //如果dir对应的文件不存在，或者不是一个目录，则退出   
	    if (!dirFile.exists() || !dirFile.isDirectory()) {   
	        return false;   
	    }   
	    boolean flag = true;   
	    //删除文件夹下的所有文件(包括子目录)   
	    File[] files = dirFile.listFiles();   
	    for (int i = 0; i < files.length; i++) {   
	        //删除子文件   
	        if (files[i].isFile()) {   
	            flag = deleteFile(files[i].getAbsolutePath());   
	            if (!flag) {
					break;
				}
	        }
	    }   
	    return flag;   
	} 

	/**
	 * 
	 * 读取文件目录下文件列表-用于文件树
	 * 
	 * @Author: sc
	 * @param sPath
	 * @return
	 */
	public static List<Map<String, Object>> getFileList(String sPath) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> item = new HashMap<String, Object>();
		// 如果sPath不以文件分隔符结尾，自动添加文件分隔符
		if (!sPath.endsWith(File.separator)) {
			sPath = sPath + File.separator;
		}
		File dirFile = new File(sPath);
		// 如果dir对应的文件不存在，或者不是一个目录，则退出
		if (!dirFile.exists() || !dirFile.isDirectory()) {
			return null;
		}
		// 获得文件夹下的所有文件(包括子目录)
		File[] files = dirFile.listFiles();
		for (int i = 0; i < files.length; i++) {
			if (files[i].getName().equals(".svn")) {
				continue;
			}
			item = new HashMap<String, Object>();
			// 获取子文件
			item.put("id", files[i].getAbsolutePath());
			item.put("name", files[i].getName());
			item.put("code", files[i].getPath());
			item.put("alias", files[i].isFile());
			item.put("pId", sPath);
			list.add(item);
		}
		return list;
	}

	public static void downloadByUrl(String urlString, String filename, String savePath) throws Exception {
		// 构造URL
		URL url = new URL(urlString);
		// 打开连接
		URLConnection con = url.openConnection();
		//LOG.info("url:{}",urlString);
		// 设置请求超时为5s
		con.setConnectTimeout(5 * 1000);
		// 输入流
		InputStream is = con.getInputStream();

		// 1K的数据缓冲
		byte[] bs = new byte[1024];
		// 读取到的数据长度
		int len;
		// 输出的文件流
		File sf = new File(savePath);
		if (!sf.exists()) {
			sf.mkdirs();
		}
	
		OutputStream os = new FileOutputStream(sf.getPath() + "/" + filename);
		//LOG.info("src:{}",sf.getPath() + "/" + filename);
		// 开始读取
		while ((len = is.read(bs)) != -1) {
			os.write(bs, 0, len);
		}
		// 完毕，关闭所有链接
		os.close();
		is.close();
		//LOG.info("download end");
	}
	
	/**
	 * 复制单个文件
	 * 
	 * @param oldPath
	 *            String 原文件路径 如：c:/fqf.txt
	 * @param newPath
	 *            String 复制后路径 如：f:/fqf.txt
	 * @return boolean
	 */
	public static boolean copyFile(String oldPath, String newPath) {
		try {
			int byteread = 0;
			File oldfile = new File(oldPath);
			if (oldfile.exists()) { // 文件存在时
				InputStream inStream = new FileInputStream(oldPath); // 读入原文件
				FileOutputStream fs = new FileOutputStream(newPath);
				byte[] buffer = new byte[1444];
				while ((byteread = inStream.read(buffer)) != -1) {
					fs.write(buffer, 0, byteread);
				}
				inStream.close();
				fs.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static String txt2String(File file) {
		StringBuilder result = new StringBuilder();
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));// 构造一个BufferedReader类来读取文件
			String s = null;
			int i = 0;
			while ((s = br.readLine()) != null) {// 使用readLine方法，一次读一行
				if (i == 0) {
					result.append(s);
				} else {
					result.append("\n" + s);
				}
				i++;
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static void contentToTxt(String filePath, String content) {
		try {
			RandomAccessFile raf = new RandomAccessFile(filePath, "rw");
			raf.writeBytes(content);
			raf.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 *
	 * @param src
	 *            源路径
	 * @param dest
	 *            目标路径
	 * @return
	 */
	@SuppressWarnings("resource")
	public static Boolean unZip(String src, String dest) {
		try {
			ZipInputStream zin = new ZipInputStream(new FileInputStream(src));
			java.util.zip.ZipEntry entry;
			// 创建文件夹
			while ((entry = zin.getNextEntry()) != null) {
				if (entry.isDirectory()) {
					File directory = new File(dest, entry.getName());
					if (!directory.exists()) {
						if (!directory.mkdirs()) {
							System.exit(0);
						}
					}
					zin.closeEntry();
				} else {
					File myFile = new File(entry.getName());
					FileOutputStream fout = new FileOutputStream(dest + myFile.getPath());
					DataOutputStream dout = new DataOutputStream(fout);
					byte[] b = new byte[1024];
					int len = 0;
					while ((len = zin.read(b)) != -1) {
						dout.write(b, 0, len);
					}
					dout.close();
					fout.close();
					zin.closeEntry();
				}
			}
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 压缩
	 *
	 * @param src
	 *            源路径
	 * @param dest
	 *            目标路径
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void zip(String src, String dest) throws FileNotFoundException, IOException {
		// ----压缩文件：
		FileOutputStream f = new FileOutputStream(dest);
		// 使用指定校验和创建输出流
		CheckedOutputStream csum = new CheckedOutputStream(f, new CRC32());

		ZipOutputStream zos = new ZipOutputStream(csum);
		// 支持中文
		zos.setEncoding("GBK");
		BufferedOutputStream out = new BufferedOutputStream(zos);
		// 启用压缩
		zos.setMethod(ZipOutputStream.DEFLATED);
		// 压缩级别为最强压缩，但时间要花得多一点
		zos.setLevel(Deflater.BEST_COMPRESSION);

		File srcFile = new File(src);

		// 获取压缩源所在父目录
		src = src.replaceAll("\\\\", "/");
		String prefixDir = null;
		if (srcFile.isFile()) {
			prefixDir = src.substring(0, src.lastIndexOf("/") + 1);
		} else {
			prefixDir = (src.replaceAll("/$", "") + "/");
		}

		// 如果不是根目录
		if (prefixDir.indexOf("/") != (prefixDir.length() - 1)) {
			prefixDir = prefixDir.replaceAll("[^/]+/$", "");
		}

		// 开始压缩
		writeRecursive(zos, out, srcFile, prefixDir);

		out.close();
		// 注：校验和要在流关闭后才准备，一定要放在流被关闭后使用
		System.out.println("Checksum: " + csum.getChecksum().getValue());

	}

	/**
	 * 递归压缩
	 *
	 * 使用 org.apache.tools.zip.ZipOutputStream 类进行压缩，它的好处就是支持中文路径， 而Java类库中的
	 * java.util.zip.ZipOutputStream 压缩中文文件名时压缩包会出现乱码。 使用 apache 中的这个类与 java
	 * 类库中的用法是一新的，只是能设置编码方式了。
	 *
	 * @param zos
	 * @param bo
	 * @param srcFile
	 * @param prefixDir
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private static void writeRecursive(ZipOutputStream zos, BufferedOutputStream bo, File srcFile, String prefixDir)
			throws IOException, FileNotFoundException {
		ZipEntry zipEntry;

		String filePath = srcFile.getAbsolutePath().replaceAll("\\\\", "/").replaceAll("//", "/");
		if (srcFile.isDirectory()) {
			filePath = filePath.replaceAll("/$", "") + "/";
		}
		String entryName = filePath.replace(prefixDir, "").replaceAll("/$", "");
		if (srcFile.isDirectory()) {
			if (!"".equals(entryName)) {
				System.out.println("正在创建目录 - " + srcFile.getAbsolutePath() + "  entryName=" + entryName);

				// 如果是目录，则需要在写目录后面加上 /
				zipEntry = new ZipEntry(entryName + "/");
				zos.putNextEntry(zipEntry);
			}

			File srcFiles[] = srcFile.listFiles();
			for (int i = 0; i < srcFiles.length; i++) {
				writeRecursive(zos, bo, srcFiles[i], prefixDir);
			}
		} else {
			System.out.println("正在写文件 - " + srcFile.getAbsolutePath() + "  entryName=" + entryName);
			BufferedInputStream bi = new BufferedInputStream(new FileInputStream(srcFile));

			// 开始写入新的ZIP文件条目并将流定位到条目数据的开始处
			zipEntry = new ZipEntry(entryName);
			zos.putNextEntry(zipEntry);
			byte[] buffer = new byte[1024];
			int readCount = bi.read(buffer);

			while (readCount != -1) {
				bo.write(buffer, 0, readCount);
				readCount = bi.read(buffer);
			}
			// 注，在使用缓冲流写压缩文件时，一个条件完后一定要刷新一把，不
			// 然可能有的内容就会存入到后面条目中去了
			bo.flush();
			// 文件读完后关闭
			bi.close();
		}
	}
}
