package com.ihomefnt.mobile.dao;

import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import com.ihomefnt.mobile.domain.module.AppModule;
import com.ihomefnt.mobile.domain.hotupdate.po.*;

import java.util.List;
import java.util.Map;

/**
 * @author xiamingyu
 */
public interface IHotUpdateMapper {

    /**
     * 批量获取模块的最新bundle信息
     *
     * @param params 模块码
     * @return
     */
    Map<String, AppBundleRecord> getLatestBundleByModuleCodes(Map<String, Object> params);

    /**
     * 批量获取所有模块的bundle信息()
     *
     * @param params 模块码
     * @return
     */
    Map<String, AppBundleRecord> getLatestBundleByModuleCodesWithoutFilter(Map<String, Object> params);


    /**
     * 查询模块最新的增量更新
     *
     * @param appBundleDiffList
     * @return
     */
    List<AppBundleDiff> getLatestBundleDiff(List<AppBundleDiff> appBundleDiffList);


    /**
     * 创建新bundle
     *
     * @param bundleRecord
     * @return
     */
    AppBundleRecord createNewBundle(AppBundleRecord bundleRecord);

    /**
     * 创建新的diff
     *
     * @param appBundleDiffList
     * @return
     */
    List<AppBundleDiff> createNewDiffs(List<AppBundleDiff> appBundleDiffList);

    /**
     * 查询所有需要diff的低版本bundle
     *
     * @param appBundleRecord
     * @return
     */
    List<AppBundleRecord> queryNeedDiffBundle(AppBundleRecord appBundleRecord);

    /**
     * 创建新的模块
     *
     * @param module
     * @return
     */
    AppModule createNewModule(AppModule module);

    /**
     * 通过APPID分页查询模块信息
     *
     * @param params
     * @return
     */
    List<AppModule> queryModuleByAppId(Map<String, Object> params);

    /**
     * 通过模块唯一码分页查询模块更新记录
     *
     * @param params
     * @return
     */
    List<AppBundleRecord> queryBundleRecordByParams(Map<String, Object> params);

    /**
     * 根据模块码批量查询模块信息
     *
     * @param moduleCodes
     * @return
     */
    List<AppModule> queryModuleByCodes(List<String> moduleCodes);

    /**
     * 插入更新日志
     *
     * @param updateLog
     * @return
     */
    UpdateLog insertUpdateLog(UpdateLog updateLog);

    List<AppBundleRecordList> getBundleListByModuleCodes(Map<String, Object> params);


    List<AppBundleRecordList> queryBundleListByParams(Map<String, Object> params);


    AppBundleRecord getBundleRecordById(Integer bundleRecordId);

    int updateAppBundleReleaseStatus(Map<String, Object> params);

    int updateBundleRecordById(AppBundleRecord bundleRecord);

    int updateBundleRecordDeleteFlag(Map<String, Object> params);

    int countBundleRecordByParams(Map<String, Object> params);

    List<AppBundleRecord> getAppBundleRecord(Map<String, Object> params);
}