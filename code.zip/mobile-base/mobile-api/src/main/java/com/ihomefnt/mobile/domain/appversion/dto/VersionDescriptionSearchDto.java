package com.ihomefnt.mobile.domain.appversion.dto;

import com.ihomefnt.mobile.common.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @author ZHAO
 */
@ApiModel("app版本描述查询请求参数")
@Data
public class VersionDescriptionSearchDto extends BasePageRequest {
	@ApiModelProperty("APP类型 1艾佳安卓、2艾佳iOS")
	private Integer appType;

}
