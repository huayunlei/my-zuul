package com.ihomefnt.mobile.domain.appversion.dto;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel("app最新版本查询")
public class VersionQueryNewDto extends BaseRequest {

}
