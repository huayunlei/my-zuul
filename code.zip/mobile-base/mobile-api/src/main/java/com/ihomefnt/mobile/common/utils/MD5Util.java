/*
 * Copyright (C) 2006-2016 AiJia All rights reserved
 * Author: zhang
 * Date: 2017年12月25日
 * Description:FileMD5Util.java 
 */
package com.ihomefnt.mobile.common.utils;

import java.io.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;


/**
 * @author zhang
 */
public class MD5Util {

	/**
	 * 
	 * 获取单个文件的MD5值！
	 * 
	 * 
	 * 
	 * @param file
	 * 
	 * @return
	 */

	public static String getFileMD5(File file) {

		if (!file.isFile()) {

			return null;

		}

		MessageDigest digest = null;

		FileInputStream in = null;

		byte buffer[] = new byte[1024];

		int len;

		try {

			digest = MessageDigest.getInstance("MD5");

			in = new FileInputStream(file);

			while ((len = in.read(buffer, 0, 1024)) != -1) {

				digest.update(buffer, 0, len);

			}

			in.close();

		} catch (Exception e) {

			e.printStackTrace();

			return null;

		}

		BigInteger bigInt = new BigInteger(1, digest.digest());

		return bigInt.toString(16);

	}

	/**
	 * 
	 * 获取文件夹中文件的MD5值
	 * 
	 * 
	 * 
	 * @param file
	 * 
	 * @param listChild
	 * 
	 *            ;true递归子目录中的文件
	 * 
	 * @return
	 */

	public static Map<String, String> getDirMD5(File file, boolean listChild) {

		if (!file.isDirectory()) {

			return null;

		}

		Map<String, String> map = new HashMap<String, String>();

		String md5;

		File files[] = file.listFiles();

		for (int i = 0; i < files.length; i++) {

			File f = files[i];

			if (f.isDirectory() && listChild) {

				map.putAll(getDirMD5(f, listChild));

			} else {

				md5 = getFileMD5(f);

				if (md5 != null) {

					map.put(f.getPath(), md5);

				}

			}

		}

		return map;

	}

	/**
	 *
	 * 获取文件夹中bundle文件的MD5值
	 *
	 *
	 *
	 * @param file
	 *
	 * @param listChild
	 *
	 *            ;true递归子目录中的文件
	 *
	 * @return
	 */

	public static String getBundleMD5(File file,String bundleName,boolean listChild) {

		if (!file.isDirectory()) {

			return null;

		}

		String md5 = null;

		File files[] = file.listFiles();

		for (int i = 0; i < files.length; i++) {

			File f = files[i];

			if(f.getName().equals(bundleName)){
				md5 = getFileMD5(f);
			}

		}

		return md5;
	}

	public static String txt2String(File file) {
		StringBuilder result = new StringBuilder();
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));// 构造一个BufferedReader类来读取文件
			String s = null;
			int i = 0;
			while ((s = br.readLine()) != null) {// 使用readLine方法，一次读一行
				if (i == 0) {
					result.append(s);
				} else {
					result.append("\n" + s);
				}
				i++;
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static void contentToTxt(String filePath, String content) {
		try {
			RandomAccessFile raf = new RandomAccessFile(filePath, "rw");
			raf.writeBytes(content);
			raf.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
