package com.ihomefnt.mobile.common.constant;

/**
 * Created by shirely_geng on 15-1-14.
 */
public interface MessageConstant {

    String USER_NOT_EXISTS = "用户或密码不正确！";
    String USER_NICK_EXISTS = "用户昵称已经存在！";
    String USER_PASS_EMPTY = "用户名密码为空！";
    String USER_REGISTERED = "用户已经注册";
    String USER_NOT_LOGIN = "你的账号已在其他地方登录，请重新登录";
    String QUERY_FAILED = "查询失败";
    String WRONG_REQUEST = "错误的请求";
    String DATE_EMPTY = "没有更多数据了";

    //登录注册优化提示
    String USER_LOGIN_FAILED_PSD = "登录失败，若忘记密码请通过验证码登录";

    String DATA_TRANSFER_EMPTY = "传入参数有空值,或传入参数有误";
    String DRAFT_NOT_EXIST = "数据不存在，请刷新后重试";

    String ILLEGAL_USER = "非法用户";
    String QUERY_SUCCESS = "查询成功";
    String PARAMS_NOT_EXISTS = "参数为空或者参数格式不正确";
    String SUCCESS = "成功";
    String FAILED = "系统有点小异常，请稍后再试";




}
