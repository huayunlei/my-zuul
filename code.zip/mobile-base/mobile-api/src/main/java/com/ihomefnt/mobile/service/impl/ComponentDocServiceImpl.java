package com.ihomefnt.mobile.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.common.util.StringUtil;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.doc.ComponentDoc;
import com.ihomefnt.mobile.domain.doc.dto.AddComponentDto;
import com.ihomefnt.mobile.domain.doc.dto.ModifyComponentDto;
import com.ihomefnt.mobile.domain.doc.dto.QueryComponentDto;
import com.ihomefnt.mobile.domain.doc.vo.ComponentDocDetailVo;
import com.ihomefnt.mobile.domain.doc.vo.ComponentDocVo;
import com.ihomefnt.mobile.mapper.ComponentDocMapper;
import com.ihomefnt.mobile.service.ComponentDocService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-10 14:10
 */
@Service
public class ComponentDocServiceImpl extends ServiceImpl<ComponentDocMapper, ComponentDoc> implements ComponentDocService {

    @Resource
    private ComponentDocMapper componentDocMapper;

    /**
     * 查询文档列表
     *
     * @param queryDto 查询条件
     * @return 文档列表
     */
    @Override
    public ResponseVo<List<ComponentDocVo>> queryList(QueryComponentDto queryDto) {
        QueryWrapper<ComponentDoc> queryWrapper = new QueryWrapper<>();
        //按分类查询
        if (!StringUtil.isEmpty(queryDto.getComponentCategory())) {
            queryWrapper.lambda().eq(ComponentDoc::getComponentCategory, queryDto.getComponentCategory());
        }
        if (!StringUtil.isEmpty(queryDto.getComponentType())) {
            queryWrapper.lambda().eq(ComponentDoc::getComponentType, queryDto.getComponentType());
        }
        List<ComponentDocVo> docList = componentDocMapper.selectList(queryWrapper).stream()
                .map(componentDoc -> componentDoc.transform(ComponentDocVo.class))
                .collect(toList());
        return ResponseVo.success(docList);
    }

    /**
     * 查询文档详情
     *
     * @param id 文档id
     * @return 文档详情
     */
    @Override
    public ResponseVo<ComponentDocDetailVo> queryDetail(Integer id) {
        ComponentDoc doc = componentDocMapper.selectById(id);
        if (doc != null) {
            return ResponseVo.success(doc.transform(ComponentDocDetailVo.class));
        }
        return ResponseVo.fail("文档不存在");
    }

    /**
     * 创建文档
     *
     * @param componentDto 文档信息
     * @return 创建结果
     */
    @Override
    public ResponseVo add(AddComponentDto componentDto) {
        componentDocMapper.insert(componentDto.transform(ComponentDoc.class));
        return ResponseVo.success();
    }

    /**
     * 修改文档
     *
     * @param componentDto 修改信息
     * @return 修改结果
     */
    @Override
    public ResponseVo modify(ModifyComponentDto componentDto) {
        componentDocMapper.updateById(componentDto.transform(ComponentDoc.class));
        return ResponseVo.success();
    }

}
