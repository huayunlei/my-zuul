package com.ihomefnt.mobile.domain.app.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class QueryAppDto {

    @ApiModelProperty(value = "组id")
    private Integer groupId;
}
