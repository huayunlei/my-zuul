package com.ihomefnt.mobile.domain.group.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AddAppGroupDto {

    @ApiModelProperty(value = "组名称",required = true)
    private String name;

    @ApiModelProperty(value = "图标",required = true)
    private String icon;

    @ApiModelProperty("备注")
    private String remark;
}
