package com.ihomefnt.mobile.domain.account.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-09-12 15:36
 */
@Data
@Accessors(chain = true)
public class AccountVo {

    @ApiModelProperty(value = "账号id")
    private Integer id;

}
