package com.ihomefnt.mobile.domain.hotupdate.vo.request;

import com.ihomefnt.mobile.common.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-07-24 10:42
 */
@ApiModel(description = "BasebandVersionRelationRequest")
@Data
@Accessors(chain = true)
public class BasebandVersionRelationRequest extends BaseRequest {

    @ApiModelProperty(value = "基带id")
    private Integer basebandId;

    @ApiModelProperty(value = "app版本号")
    private Integer appVersion;

    @ApiModelProperty(value = "基带版本号")
    private Integer basebandVersion;

    @ApiModelProperty(value = "备注描述")
    private String remark;

}
