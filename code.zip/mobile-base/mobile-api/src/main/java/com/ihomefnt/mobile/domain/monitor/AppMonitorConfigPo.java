package com.ihomefnt.mobile.domain.monitor;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ihomefnt.mobile.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Accessors(chain = true)
@TableName("t_app_monitor_config")
@EqualsAndHashCode(callSuper = true)
public class AppMonitorConfigPo extends BaseEntity {

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * appId
     */
    private String appId;

    /**
     * 监控来源类型：1，o2o监控；2，wcm监控；3，sky监控；4，通用监控；5，collector监控
     */
    private int monitorType = 5;
    /**
     * 监控业务key
     */
    private String monitorKey;

    /**
     * 告警等级
     */
    private String monitorLevel;

    /**
     * 告警信息
     */
    private String monitorDesc;

    /**
     * 钉钉告警群名称
     */
    private String monitorDingName;

    /**
     * 钉钉群token
     */
    private String monitorDingToken;

    /**
     * 删除标志（0未删除  1已删除）
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

}
