/*
 * Copyright (C) 2006-2016 AiJia All rights reserved
 * Author: zhang
 * Date: 2017年6月20日
 * Description:VersionController.java
 */
package com.ihomefnt.mobile.controller;

import com.ihomefnt.mobile.common.BasePageRequest;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseCodeEnum;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.appversion.AppVersion;
import com.ihomefnt.mobile.domain.appversion.dto.*;
import com.ihomefnt.mobile.domain.appversion.vo.VersionNewVo;
import com.ihomefnt.mobile.domain.appversion.vo.VersionVo;
import com.ihomefnt.mobile.service.VersionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author zhang
 */
@RestController
@Api(value = "版本 API", description = "版本接口")
@RequestMapping("/version")
public class VersionController {

    @Resource
    private VersionService versionService;


    @ApiOperation(value = "查询版本", notes = "测试查询版本是否正常")
    @PostMapping("/queryLatestApp")
    public ResponseVo<VersionNewVo> queryLatestApp(@RequestBody VersionQueryNewDto request) {
        VersionNewVo result = versionService.queryLatestAppNew(request);
        if (null == result) {
            return ResponseVo.buildResponse(ResponseCodeEnum.FAILED);
        }
        return ResponseVo.success(result);
    }

    @ApiOperation(value = "查询APP版本描述列表", notes = "查询APP版本描述列表")
    @PostMapping("/queryAppVersionList")
    public ResponseVo<PageResponse<VersionVo>> queryAppVersionList(@RequestBody BasePageRequest request) {
        if (request == null || StringUtils.isBlank(request.getAppId())) {
            return ResponseVo.buildResponse(ResponseCodeEnum.DATA_TRANSFER_EMPTY);
        }
        request.setPageSize(request.getPageSize() < 1 ?
                10 : request.getPageSize());
        request.setPageNo(request.getPageNo() < 1 ?
                1 : request.getPageNo());

        PageResponse<VersionVo> result = versionService.queryAppVersionListNew(request);
        return ResponseVo.success(result);
    }

    @ApiOperation(value = "添加APP版本", notes = "添加APP版本")
    @PostMapping("/addAppVersion")
    public ResponseVo<String> addAppVersion(@RequestBody AddVersionNewDto request) {
        if (request == null || StringUtils.isBlank(request.getAppId()) || request.getAppType() == null ||
                CollectionUtils.isEmpty(request.getUpdateContent()) ||
                StringUtils.isBlank(request.getVersion()) ||
                null == request.getDownload()) {
            return ResponseVo.buildResponse(ResponseCodeEnum.DATA_TRANSFER_EMPTY);
        }
        boolean result = versionService.addAppVersion(request);
        if (!result) {
            return ResponseVo.buildResponse(ResponseCodeEnum.FAILED);
        }
        return ResponseVo.success("添加成功");
    }


    @ApiOperation(value = "更新APP版本记录", notes = "更新APP版本记录")
    @PostMapping("/updateAppVersion")
    public ResponseVo updateAppVersion(@RequestBody UpdateVersionDto request) {
        return  versionService.updateAppVersion(request);

    }

    @ApiOperation("上架")
    @PostMapping("/putAway")
    public ResponseVo putAway(@RequestBody PutAwayDto putAwayDto) {
        return versionService.putAway(putAwayDto.getId());
    }

    @ApiOperation("根据最小版本号查询所有版本号信息")
    @PostMapping("/queryRecordListByMinVersion")
    public ResponseVo<List<AppVersion>> queryRecordListByMinVersion(@RequestBody QueryVersionListByMinVersionDto request) {
        return ResponseVo.success(versionService.queryRecordListByMinVersion(request));
    }

    @ApiOperation("更新记录查询")
    @PostMapping("/query-page")
    public ResponseVo<PageResponse<VersionVo>> queryPage(@RequestBody VersionPageDto pageDto) {
        return ResponseVo.success(versionService.queryPage(pageDto));
    }

    @ApiOperation("批量删除记录")
    @PostMapping("/batch-delete")
    public ResponseVo batchDelete(@RequestBody DeleteVersionDto version) {
        return versionService.batchDelete(version);
    }

}
