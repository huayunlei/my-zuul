package com.ihomefnt.mobile.domain.app.dto;

import com.ihomefnt.mobile.common.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * @author xiamingyu
 */

@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
public class UpdateAppDto extends BaseEntity {

    @ApiModelProperty(value = "appId",required = true)
    private String appId;

    @ApiModelProperty(value = "app名称",required = true)
    private String appName;

    @ApiModelProperty(value = "icon图标",required = true)
    private String icon;

    @ApiModelProperty(value = "Native H5")
    private String type;

    @ApiModelProperty(value = "描述")
    private String description;

}