package com.ihomefnt.mobile.domain.appversion.dto;

import com.ihomefnt.mobile.common.BaseRequest;
import com.ihomefnt.mobile.domain.appversion.dto.BindBundleDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author ZHAO
 */

@Data
@ApiModel("app新增版本描述请求")
@EqualsAndHashCode(callSuper = true)
public class AddVersionNewDto extends BaseRequest {

    @ApiModelProperty(value = "APP类型", required = true)
    private Integer appType;

    @ApiModelProperty(value = "版本号", required = true)
    private String version;

    @ApiModelProperty(value = "版本描述", required = true)
    private List<String> updateContent;

    @ApiModelProperty(value = "是否强制更新 0:否 1:是", required = true)
    private Integer updateFlag;

    @ApiModelProperty(value = "下载地址", required = true)
    private String download;

    @ApiModelProperty("操作人")
    private String operator;

    @ApiModelProperty("ios ipa下载")
    private String ipaDownloadUrl;

    @ApiModelProperty(value = "基础版本", required = true)
    private Integer baseAppVersion;

    @ApiModelProperty(value = "上架标记 0 未上架 1已上架", required = true)
    private Integer putAwayState = 0;

    @ApiModelProperty("随版本发布的bundle")
    List<BindBundleDto> bindBundles;

}
