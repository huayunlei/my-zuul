package com.ihomefnt.mobile.constant.hotupdate;

/**
 * @author xiamingyu
 */

public enum ModuleQueryEnum {

    SUCCESS(1,"成功"),
    NOT_EXIST(1001,"未查询到模块信息"),
    VERSION_CODE_NEW(1002,"上传版本号必须大于当前服务器最新版本");

    private Integer code;

    private String msg;


    ModuleQueryEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static ModuleQueryEnum getEnumByCode(int code){
        ModuleQueryEnum[] values = values();
        for (ModuleQueryEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }


    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
