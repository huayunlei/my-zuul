package com.ihomefnt.mobile.domain.group.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AppGroupVo {

    @ApiModelProperty("组id")
    private Integer groupId;

    @ApiModelProperty("图标")
    private String icon;

    @ApiModelProperty("组名称")
    private String name;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

}
