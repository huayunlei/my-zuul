package com.ihomefnt.mobile.domain.appversion.dto;

import lombok.Data;

import java.util.List;

@Data
public class AppPartnerValueTypeNameDto {

    /**
     * 渠道编号
     */
    private List<String> partnerValue;

    /**
     * 渠道名称
     */
    private String appTypeName;

    /**
     * appType
     */
    private Integer appType;
}
