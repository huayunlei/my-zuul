package com.ihomefnt.mobile.domain.group.dto;

import com.ihomefnt.mobile.common.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class UpdateAppDto extends BaseEntity  {

    @ApiModelProperty(value = "id", required = true)
    private Integer id;

    @ApiModelProperty(value = "appId")
    private String appId;

    @ApiModelProperty(value = "app名称", required = true)
    private String appName;

    @ApiModelProperty(value = "图标", required = true)
    private String icon;

    @ApiModelProperty(value = "分发地址", required = true)
    private String url;

    @ApiModelProperty(value = "app类型  1:IOS 2:Android", required = true)
    private Integer appType;

    @ApiModelProperty(value = "来源 1: mop 2:其他来源", required = true)
    private Integer source;
}
