package com.ihomefnt.mobile.common.constant;

/**
 * Created by shirely_geng on 15-1-14.
 */
public class HttpResponseCode {

    public static final int SUCCESS = 1;
    public static final int FAILED = 2;
    public static final int Data_EXISTS = 3;
    public static final int WRONG_REQUEST = 7;// 错误的请求
    public static final int QUERY_FAILED = 23;// 查询失败
    public static final int PARAMS_NOT_EXISTS = 4;// 参数缺失
    public static final int ADMIN_ILLEGAL = 3;//未登录或该账号在其他地方登录

    // 返回为空 MessageConstant.DRAFT_NOT_EXIST
    public static final int RESPONSE_DATE_NOT_EXIST = 103005;


}
