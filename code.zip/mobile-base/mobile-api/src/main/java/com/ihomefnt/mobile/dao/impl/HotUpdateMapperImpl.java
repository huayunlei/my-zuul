package com.ihomefnt.mobile.dao.impl;

import com.ihomefnt.mobile.domain.hotupdate.AppBundleRecord;
import com.ihomefnt.mobile.domain.module.AppModule;
import com.ihomefnt.mobile.domain.hotupdate.po.*;
import com.ihomefnt.mobile.dao.IHotUpdateMapper;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author xiamingyu
 * @date 2018/11/22
 */

@Service
public class HotUpdateMapperImpl implements IHotUpdateMapper {

    private static String NAME_SPACE = "com.ihomefnt.mobile.module.hotupdate.";

    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;

    @Override
    public Map<String, AppBundleRecord> getLatestBundleByModuleCodes(Map<String, Object> params) {
        return sqlSessionTemplate.selectMap(NAME_SPACE + "getLatestBundleByModuleCodes", params, "moduleCode");
    }

    @Override
    public Map<String, AppBundleRecord> getLatestBundleByModuleCodesWithoutFilter(Map<String, Object> params) {
        return sqlSessionTemplate.selectMap(NAME_SPACE + "getLatestBundleByModuleCodesWithoutFilter", params, "moduleCode");
    }

    @Override
    public List<AppBundleDiff> getLatestBundleDiff(List<AppBundleDiff> appBundleDiffList) {
        return sqlSessionTemplate.selectList(NAME_SPACE + "getLatestBundleDiff", appBundleDiffList);
    }

    @Override
    public AppBundleRecord createNewBundle(AppBundleRecord bundleRecord) {
        sqlSessionTemplate.insert(NAME_SPACE + "insertBundle", bundleRecord);
        return bundleRecord;
    }

    @Override
    public List<AppBundleDiff> createNewDiffs(List<AppBundleDiff> appBundleDiffList) {
        sqlSessionTemplate.insert(NAME_SPACE + "insertDiffs", appBundleDiffList);
        return appBundleDiffList;
    }

    @Override
    public List<AppBundleRecord> queryNeedDiffBundle(AppBundleRecord appBundleRecord) {
        return sqlSessionTemplate.selectList(NAME_SPACE + "getNeedDiffBundle", appBundleRecord);
    }

    @Override
    public AppModule createNewModule(AppModule module) {
        sqlSessionTemplate.insert(NAME_SPACE + "insertModule", module);
        return module;
    }

    @Override
    public List<AppModule> queryModuleByAppId(Map<String, Object> params) {
        return sqlSessionTemplate.selectList(NAME_SPACE + "getModuleByAppId", params);
    }

    @Override
    public List<AppBundleRecord> queryBundleRecordByParams(Map<String, Object> params) {
        return sqlSessionTemplate.selectList(NAME_SPACE + "queryBundleRecordByParams", params);
    }

    @Override
    public List<AppModule> queryModuleByCodes(List<String> moduleCodes) {
        return sqlSessionTemplate.selectList(NAME_SPACE + "getModuleByCodes", moduleCodes);
    }

    @Override
    public UpdateLog insertUpdateLog(UpdateLog updateLog) {
        sqlSessionTemplate.insert(NAME_SPACE + "insertUpdateLogSelective", updateLog);
        return updateLog;
    }

    @Override
    public List<AppBundleRecordList> getBundleListByModuleCodes(Map<String, Object> params) {
        return sqlSessionTemplate.selectList(NAME_SPACE + "getBundleListByModuleCodes", params);
    }

    @Override
    public List<AppBundleRecordList> queryBundleListByParams(Map<String, Object> params) {
        return sqlSessionTemplate.selectList(NAME_SPACE + "queryBundleListByParams", params);
    }

    @Override
    public AppBundleRecord getBundleRecordById(Integer bundleRecordId) {
        Map<String, Object> params = new HashMap<>(1);
        params.put("id", bundleRecordId);
        return sqlSessionTemplate.selectOne(NAME_SPACE + "getBundleRecordById", params);
    }

    @Override
    public int updateAppBundleReleaseStatus(Map<String, Object> params) {
        return sqlSessionTemplate.update(NAME_SPACE + "updateAppBundleReleaseStatus", params);
    }

    @Override
    public int updateBundleRecordById(AppBundleRecord bundleRecord) {
        return sqlSessionTemplate.update(NAME_SPACE + "updateBundleRecordById", bundleRecord);
    }

    @Override
    public int updateBundleRecordDeleteFlag(Map<String, Object> params) {
        return sqlSessionTemplate.update(NAME_SPACE + "updateBundleRecordDeleteFlag", params);
    }


    @Override
    public int countBundleRecordByParams(Map<String, Object> params) {
        return sqlSessionTemplate.selectOne(NAME_SPACE + "countBundleRecordByParams", params);
    }

    @Override
    public List<AppBundleRecord> getAppBundleRecord(Map<String, Object> params) {
        return sqlSessionTemplate.selectList(NAME_SPACE + "getAppBundleRecord", params);
    }

}
