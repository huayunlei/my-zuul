package com.ihomefnt.mobile.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ihomefnt.mobile.common.PageResponse;
import com.ihomefnt.mobile.common.ResponseVo;
import com.ihomefnt.mobile.domain.hotupdate.BasebandVersion;
import com.ihomefnt.mobile.domain.hotupdate.dto.BasebandVersionDto;
import com.ihomefnt.mobile.domain.hotupdate.dto.QueryBaseBandPageDto;
import com.ihomefnt.mobile.domain.hotupdate.vo.BasebandVo;
import com.ihomefnt.mobile.mapper.BasebandMapper;
import com.ihomefnt.mobile.service.BasebandService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * @description:
 * @author: 何佳文
 * @date: 2019-10-08 14:25
 */
@Service
public class BasebandServiceImpl extends ServiceImpl<BasebandMapper, BasebandVersion> implements BasebandService {

    @Resource
    private BasebandMapper basebandMapper;

    @Override
    public ResponseVo create(BasebandVersionDto versionDto) {
        BasebandVersion basebandVersion = versionDto.transform(BasebandVersion.class);
        basebandVersion.setCreateTime(LocalDateTime.now());
        basebandVersion.setDeleteFlag(0);
        basebandMapper.insert(basebandVersion);
        return ResponseVo.success();
    }

    /**
     * 查询所有基带版本
     *
     * @param osType 系统类型 1:IOS,2:Android
     * @return 所有基带版本
     */
    @Override
    public ResponseVo<List<BasebandVo>> queryAll(Integer osType) {
        QueryWrapper<BasebandVersion> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(BasebandVersion::getDeleteFlag, 0)
                .eq(BasebandVersion::getOsType, osType);
        List<BasebandVo> basebandVos = basebandMapper.selectList(queryWrapper).stream()
                .map(baseband -> baseband.transform(BasebandVo.class))
                .collect(toList());
        return ResponseVo.success(basebandVos);
    }

    /**
     * 分页查询基带版本信息
     *
     * @param pageDto 分页信息
     * @return 基带版本信息
     */
    @Override
    public ResponseVo<PageResponse<BasebandVo>> queryPage(QueryBaseBandPageDto pageDto) {
        QueryWrapper<BasebandVersion> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(BasebandVersion::getDeleteFlag, 0);
        if (null != pageDto.getOsType() && pageDto.getOsType() > 0) {
            queryWrapper.lambda().eq(BasebandVersion::getOsType, pageDto.getOsType());
        }
        Page<BasebandVersion> basebandPage = new Page<>(pageDto.getPageNo(), pageDto.getPageSize());
        basebandPage.setDesc("baseband_version");
        IPage<BasebandVersion> page = basebandMapper.selectPage(basebandPage, queryWrapper);
        List<BasebandVo> basebandVoList = page.getRecords().parallelStream()
                .map(baseband -> baseband.transform(BasebandVo.class))
                .collect(toList());
        PageResponse<BasebandVo> pageResponse = new PageResponse<>();
        pageResponse.setPageSize(pageDto.getPageSize());
        pageResponse.setTotalPage(page.getPages());
        pageResponse.setTotalCount(page.getTotal());
        pageResponse.setPageNo(pageDto.getPageNo());
        pageResponse.setList(basebandVoList);
        return ResponseVo.success(pageResponse);
    }

    @Override
    public ResponseVo delete(Integer id) {
        BasebandVersion basebandVersion = basebandMapper.selectById(id);
        if (basebandVersion != null) {
            basebandVersion.setDeleteFlag(1);
            basebandMapper.updateById(basebandVersion);
        }
        return ResponseVo.success();
    }

    @Override
    public ResponseVo<BasebandVo> detailById(Integer id) {
        BasebandVersion basebandVersion = basebandMapper.selectById(id);
        return ResponseVo.success(basebandVersion.transform(BasebandVo.class));
    }
}
