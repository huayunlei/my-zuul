package com.ihomefnt.mobile.domain.hotupdate.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description:
 * @Author hua
 * @Date 2020/1/15 4:33 下午
 */
@Data
@Accessors(chain = true)
@ApiModel(description = "QueryBaseBandDto")
public class QueryBaseBandDto {

    @ApiModelProperty(value = "基带版本号")
    private Integer basebandVersion;
}
