package com.ihomefnt.o2o.intf.domain.activity.dto;

import lombok.Data;

import java.util.List;
@Data
public class HomeLetterWinningDto {
	private List<HomeLetterVo> winningResult;
}
