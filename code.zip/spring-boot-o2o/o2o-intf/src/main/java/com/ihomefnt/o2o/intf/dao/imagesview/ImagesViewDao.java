package com.ihomefnt.o2o.intf.dao.imagesview;

import com.ihomefnt.o2o.intf.domain.imagesview.dto.ImagesView;

public interface ImagesViewDao {
	
	Long addImagesView(ImagesView imagesView);

}
