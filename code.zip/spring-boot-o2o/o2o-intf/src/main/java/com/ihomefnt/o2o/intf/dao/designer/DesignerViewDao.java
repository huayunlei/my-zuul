package com.ihomefnt.o2o.intf.dao.designer;

import com.ihomefnt.o2o.intf.domain.designer.dto.DesignerView;

public interface DesignerViewDao {
	
	Long addDesignerView(DesignerView designerView);

}
