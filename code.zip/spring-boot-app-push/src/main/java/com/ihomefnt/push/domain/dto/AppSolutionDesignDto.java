package com.ihomefnt.push.domain.dto;

import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-21 15:57
 */
@Data
public class AppSolutionDesignDto {

    private Integer taskId;//任务Id

    private Integer solutionId;//方案Id

    private Integer dnaId;

    private String dnaName;

    private String dnaHeadImg;
}
