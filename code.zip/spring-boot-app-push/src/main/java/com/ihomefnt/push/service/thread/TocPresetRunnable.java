package com.ihomefnt.push.service.thread;

import com.google.common.collect.Sets;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.common.util.ServiceLocator;
import com.ihomefnt.message.RocketMQTemplate;
import com.ihomefnt.push.common.constans.MessageStatus;
import com.ihomefnt.push.common.constant.MessageQueueName;
import com.ihomefnt.push.dao.MessageRecordDao;
import com.ihomefnt.push.domain.dto.CustomerSimpleInfoDto;
import com.ihomefnt.push.domain.dto.FeedMessageDto;
import com.ihomefnt.push.domain.dto.MessageCardInfoDto;
import com.ihomefnt.push.domain.dto.TocMessageInfoRequest;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.dto.BaseMessage;
import com.ihomefnt.push.dto.SendJPushMessage;
import com.ihomefnt.push.po.MessageSource;
import com.ihomefnt.push.po.MessageType;
import com.ihomefnt.push.po.jpush.JPushExtra;
import com.ihomefnt.push.po.jpush.PhoneOS;
import com.ihomefnt.push.po.jpush.TargetClients;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;

import java.util.*;

/**
 * @author wanyunxin
 * @create 2020-03-05 15:47
 */
@Slf4j
public class TocPresetRunnable implements Runnable {
    private String tags;
    private List<CustomerSimpleInfoDto> subList;
    private PushTemplatePo constructionNotifyPushTemplatePo;
    private volatile boolean isInited = false;
    private RocketMQTemplate rocketMQTemplate;
    private MessageRecordDao messageRecordDao;
    private TocMessageInfoRequest tocMessageInfoRequest;

    public TocPresetRunnable(List<CustomerSimpleInfoDto> subList, String tags, PushTemplatePo constructionNotifyPushTemplatePo, TocMessageInfoRequest tocMessageInfoRequest) {
        this.subList = subList;
        this.tags = tags;
        this.constructionNotifyPushTemplatePo = constructionNotifyPushTemplatePo;
        this.tocMessageInfoRequest = tocMessageInfoRequest;
    }

    private synchronized void init() {
        if (isInited) {
            return;
        }
        this.rocketMQTemplate = (RocketMQTemplate) ServiceLocator.init().getService(RocketMQTemplate.class);
        this.messageRecordDao = (MessageRecordDao) ServiceLocator.init().getService(MessageRecordDao.class);
        this.isInited = true;
    }

    @Override
    public void run() {
        try {
            if (!isInited) {
                init();
            }
            List<MessageRecordPo> addRecordList = new ArrayList<>();
            for (CustomerSimpleInfoDto item : subList) {
                MessageRecordPo messageRecordPo = new MessageRecordPo();
                BeanUtils.copyProperties(constructionNotifyPushTemplatePo, messageRecordPo);
                messageRecordPo.setPushStatus(-6)
                        .setUserId(item.getUserId().intValue())
                        .setOrderId(item.getOrderId())
                        .setPushTime(new Date())
                        .setAlias(item.getMobile())
                        .setTags(tags);


                checkSaveMessageRecordNull(messageRecordPo);
                // 推送消息
                assembleAndSendJPushMessage(messageRecordPo);
                addRecordList.add(messageRecordPo);
            }
            if(tocMessageInfoRequest.getMsgType().equals(27)){
                // 批量保存MessageRecordPo
                messageRecordDao.batchSaveMessageRecord(addRecordList);
            }
            log.info("TocPresetRunnable run success");
        } catch (Exception e) {
            log.error("TocPresetRunnable run error", e);
        } finally {
        }
    }

    private void assembleAndSendJPushMessage(MessageRecordPo messageRecordPo) {
        SendJPushMessage jPushMessage = new SendJPushMessage();
        if ("MESSAGE".equals(constructionNotifyPushTemplatePo.getPushType())) {
            jPushMessage.setDiyMsg(true);
        } else {
            jPushMessage.setDiyMsg(false);
        }
        if(tocMessageInfoRequest.getMsgType().equals(24)){//通知类消息
            jPushMessage.setMsgTitle(constructionNotifyPushTemplatePo.getTitle());
            jPushMessage.setMsgContent(constructionNotifyPushTemplatePo.getContent());
        }else{
            jPushMessage.setMsgTitle("");
            jPushMessage.setMsgContent("");
        }

        jPushMessage.setMessageType(MessageType.JPUSH);

        TargetClients targetClients = new TargetClients();
        String mobile = messageRecordPo.getAlias();;
        String version = messageRecordPo.getTags();
        if (StringUtils.isBlank(version)) {// 版本号为空不推送
            return;
        }
        if (StringUtils.isBlank(mobile)) {// 手机号为空不推送
            return;
        }
        version = version.replace(".", "_");
        targetClients.setAlias(new HashSet<>(Arrays.asList(mobile.split(","))));
        // 版本号可能会重复，此处去重
        targetClients.setTag(new HashSet<>(Arrays.asList(version.split(","))));
        jPushMessage.setTargetClients(targetClients);
        jPushMessage.setPlatform(Sets.newHashSet(PhoneOS.ALL));
        jPushMessage.setReceiveTime(System.currentTimeMillis());
        jPushMessage.setMessageStatus(MessageStatus.RECEIVED.getValue());

        JPushExtra pushExtra = assembleJPushExtra(messageRecordPo, constructionNotifyPushTemplatePo.getRefreshType());
        jPushMessage.setExtra(pushExtra);

        pushMessage(jPushMessage);

    }

    private JPushExtra assembleJPushExtra(MessageRecordPo messageRecord, int refreshType) {
        JPushExtra pushExtra = new JPushExtra();
        pushExtra.setMsgType(tocMessageInfoRequest.getMsgType());
        pushExtra.setCreateTime(System.currentTimeMillis());// 发送时间
        pushExtra.setUnReadCount(0);// 未读数加1
        pushExtra.setSaveInMsgCenter(0);// 是否是消息组 :1是0否
        pushExtra.setMsgTitle(messageRecord.getTitle());// 消息标题
        pushExtra.setMessageGroupStatus(0);// 是否需要消息分组 :1是0否
        pushExtra.setOpenPage(messageRecord.getOpenUrl());
        pushExtra.setMsgImg(messageRecord.getImg());//消息图标

        FeedMessageDto feedMessageDto = new FeedMessageDto();
        List<MessageCardInfoDto> feedMessage = new ArrayList<>(1);
        Date date = new Date();

        MessageCardInfoDto messageCardInfoDto = new MessageCardInfoDto();
        messageCardInfoDto.setCardType(messageRecord.getCardType())
                .setContent(messageRecord.getContent())
                .setSubContent(messageRecord.getSubContent())
                .setTitle(messageRecord.getTitle())
                .setSubTitle(messageRecord.getSubTitle())
                .setHasRead(0)
                .setIsPushTop(messageRecord.getIsPushTop())
                .setOpenUrl(messageRecord.getOpenUrl())
                .setImgList(Arrays.asList(messageRecord.getCardImgs().split(",")))
                .setPushTime(date)
                .setCreateTime(date)
                .setUpdateTime(date)
                .setMessageNum(messageRecord.getMessageNum());
        feedMessage.add(messageCardInfoDto);

        if (messageRecord.getOrderId() != null) {
            feedMessageDto.setOrderId(messageRecord.getOrderId());
        }
        feedMessageDto.setRefreshType(refreshType).setFeedMessage(feedMessage);
        pushExtra.setMsgContent(JsonUtils.obj2json(feedMessageDto));//消息内容

        return pushExtra;
    }

    // mq 推送消息
    private int pushMessage(BaseMessage baseMessage) {
        try {
            baseMessage.setSource(MessageSource.O2O);
            rocketMQTemplate.syncSend(MessageQueueName.RECEIVE_MESSAGE_PREFIX + baseMessage.getMessageType().getValue(), baseMessage);
        } catch (Exception e) {
            log.error("send message by mq exception {}", e.getMessage(), e);
            return 0;
        }
        log.info("send message by mq params:{}", JsonUtils.obj2json(baseMessage));
        return 1;
    }

    private void checkSaveMessageRecordNull(MessageRecordPo messageRecordPo) {
        if (null == messageRecordPo.getUserId()) {
            messageRecordPo.setUserId(0);
        }
        if (null == messageRecordPo.getOrderId()) {
            messageRecordPo.setOrderId(0);
        }
        if (null == messageRecordPo.getPlatform()) {
            messageRecordPo.setPlatform("");
        }
        if (null == messageRecordPo.getPushTarget()) {
            messageRecordPo.setPushTarget("");
        }
        if (null == messageRecordPo.getTags()) {
            messageRecordPo.setTags("");
        }
        if (null == messageRecordPo.getAlias()) {
            messageRecordPo.setAlias("");
        }
        if (null == messageRecordPo.getPushType()) {
            messageRecordPo.setPushType("");
        }
        if (null == messageRecordPo.getTitle()) {
            messageRecordPo.setTitle("");
        }
        if (null == messageRecordPo.getSubTitle()) {
            messageRecordPo.setSubTitle("");
        }
        if (null == messageRecordPo.getContent()) {
            messageRecordPo.setContent("");
        }
        if (null == messageRecordPo.getSubContent()) {
            messageRecordPo.setSubContent("");
        }
        if (null == messageRecordPo.getCardImgs()) {
            messageRecordPo.setCardImgs("");
        }
        if (null == messageRecordPo.getOpenUrl()) {
            messageRecordPo.setOpenUrl("");
        }
        if (null == messageRecordPo.getErrorMsg()) {
            messageRecordPo.setErrorMsg("");
        }
    }
}