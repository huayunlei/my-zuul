package com.ihomefnt.push.common.constant;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description:艾商城商品图片
 * @Author hua
 * @Date 2019-12-02 09:27
 */
public class AijiaShopProductImgs {

    /**
     * 抱枕
     */
    private static List<String> bolsterImgs = new ArrayList<>(4);
    /**
     * 垫子
     */
    private static List<String> cushionImgs = new ArrayList<>(5);
    /**
     * 手机壳
     */
    private static List<String> phoneShellImgs = new ArrayList<>(10);

    static {
        bolsterImgs.add("https://static.ihomefnt.com/common-system/staticImage/抱枕1.jpg");
        bolsterImgs.add("https://static.ihomefnt.com/common-system/staticImage/抱枕2.jpg");
        bolsterImgs.add("https://static.ihomefnt.com/common-system/staticImage/抱枕3.jpg");
        bolsterImgs.add("https://static.ihomefnt.com/common-system/staticImage/抱枕4.jpg");

        cushionImgs.add("https://static.ihomefnt.com/common-system/staticImage/硅藻土地垫1.jpg");
        cushionImgs.add("https://static.ihomefnt.com/common-system/staticImage/硅藻土地垫2.jpg");
        cushionImgs.add("https://static.ihomefnt.com/common-system/staticImage/硅藻土地垫3.jpg");
        cushionImgs.add("https://static.ihomefnt.com/common-system/staticImage/硅藻土地垫4.jpg");
        cushionImgs.add("https://static.ihomefnt.com/common-system/staticImage/硅藻土地垫5.jpg");

        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳1.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳2.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳3.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳4.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳5.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳6.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳7.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳8.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳9.jpg");
        phoneShellImgs.add("https://static.ihomefnt.com/common-system/staticImage/手机壳10.jpg");
    }

    public static String getCompressImgs() {
        List<String> list = new ArrayList<>(3);
        int number = (int)(Math.random()*bolsterImgs.size());
        list.add(bolsterImgs.get(number)+"!H-SMALL");

        number = (int)(Math.random()*cushionImgs.size());
        list.add(cushionImgs.get(number)+"!H-SMALL");

        number = (int)(Math.random()*phoneShellImgs.size());
        list.add(phoneShellImgs.get(number)+"!H-SMALL");

        return list.stream().collect(Collectors.joining(","));
    }

    public static void main(String args[]) {
        System.out.println(AijiaShopProductImgs.getCompressImgs());
    }

}
