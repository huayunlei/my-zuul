package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-18 18:44
 */
@Data
@Accessors(chain = true)
@ApiModel("FeedMessageDto")
public class FeedMessageDto {

    @ApiModelProperty("1：只刷新核心区，2：只刷新信息区，3：都刷新")
    private int refreshType;

    @ApiModelProperty("订单id")
    private Integer orderId;

    @ApiModelProperty("消息流")
    private List<MessageCardInfoDto> feedMessage;
}
