package com.ihomefnt.push.service.push;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.push.common.constans.MessageStatus;
import com.ihomefnt.push.configuration.AppPushCommonNacosCofig;
import com.ihomefnt.push.dao.OriginalMessageDao;
import com.ihomefnt.push.domain.dto.*;
import com.ihomefnt.push.domain.po.OriginalMessagePo;
import com.ihomefnt.push.dto.SendJPushMessage;
import com.ihomefnt.push.po.MessageSource;
import com.ihomefnt.push.po.MessageType;
import com.ihomefnt.push.po.jpush.JPushExtra;
import com.ihomefnt.push.po.jpush.PhoneOS;
import com.ihomefnt.push.po.jpush.TargetClients;
import com.ihomefnt.push.proxy.AladdinOrderProxy;
import com.ihomefnt.push.proxy.AppVersionProxy;
import com.ihomefnt.push.proxy.UserProxy;
import com.ihomefnt.push.service.message.MqMessagePushService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @Description:只记原信息，刷新核心区 或者只记原信息
 * @Author hua
 * @Date 2019-11-21 11:14
 */
@Slf4j
@Service
public class OnlyRefreshOrOriginalMessageHandle {
    @Autowired
    private UserProxy userProxy;
    @Autowired
    private AladdinOrderProxy aladdinOrderProxy;
    @Autowired
    private OriginalMessageDao originalMessageDao;
    @Autowired
    private MqMessagePushService mqMessagePushService;
    @Autowired
    private AppVersionProxy appVersionProxy;
    @Autowired
    private AppPushCommonNacosCofig appPushCommonNacosCofig;

    public void processMessage(ReceiveBaseMessage receiveBaseMessage, int messageTriggerType, UserDto userDto) {
        ReceiveBaseMessage.MessageInfo messageInfo = receiveBaseMessage.getMessageInfo();
        if (messageInfo == null || !checkUserIdAndOrderId(messageInfo)) {
            log.error(" userId and orderId 不能同时为空， param:{}", receiveBaseMessage);
            return;
        }

        //  save OriginalMessagePo
        saveOriginalMessagePo(receiveBaseMessage);

        // 2 只记原信息，刷新核心区 3 只记原信息
        if (2 == messageTriggerType) {
            //  发送消息
            assembleAndSendJPushMessage(receiveBaseMessage, userDto);
        }

    }

    private void assembleAndSendJPushMessage(ReceiveBaseMessage receiveBaseMessage, UserDto userDto) {
        SendJPushMessage jPushMessage = new SendJPushMessage();
        jPushMessage.setDiyMsg(true);
        jPushMessage.setMsgTitle("");
        jPushMessage.setMsgContent("");
        jPushMessage.setMessageType(MessageType.JPUSH);

        TargetClients targetClients = new TargetClients();
        // 手机号
        if (StringUtils.isBlank(userDto.getMobile())) {
            return;
        }
        targetClients.setAlias(new HashSet<>(Arrays.asList(userDto.getMobile().split(","))));

        // tags、alias模版中有就以模版中为准，没有就查询
        Set<String> tags = appPushCommonNacosCofig.getAppPushVersionSet();
        if (CollectionUtils.isEmpty(tags)) {
            List<AppVersionDto> versionDtoList = appVersionProxy.queryRecordListByMinVersion(appPushCommonNacosCofig.getApp_push_min_version(), Lists.newArrayList("washriwvd8c6r6nz","eax4kpvv3nsuk837"));
            if (!CollectionUtils.isEmpty(versionDtoList)) {
                tags = versionDtoList.parallelStream().map(versionDto -> versionDto.getVersion()).collect(Collectors.toSet());
            }
        }
        targetClients.setTag(tags);

        if (CollectionUtils.isEmpty(targetClients.getTag())) {
            return;
        }
        jPushMessage.setTargetClients(targetClients);

        jPushMessage.setPlatform(Sets.newHashSet(PhoneOS.ALL));
        jPushMessage.setReceiveTime(System.currentTimeMillis());
        jPushMessage.setMessageStatus(MessageStatus.RECEIVED.getValue());

        JPushExtra pushExtra = assembleJPushExtra();
        jPushMessage.setExtra(pushExtra);

        mqMessagePushService.pushMessage(jPushMessage);
    }

    private JPushExtra assembleJPushExtra() {
        JPushExtra pushExtra = new JPushExtra();
        pushExtra.setMsgType(27);
        pushExtra.setCreateTime(System.currentTimeMillis());// 发送时间
        pushExtra.setUnReadCount(1);// 未读数加1
        pushExtra.setSaveInMsgCenter(1);// 是否是消息组 :1是0否
        pushExtra.setMsgTitle("");// 消息标题
        pushExtra.setMessageGroupStatus(0);// 是否需要消息分组 :1是0否
        pushExtra.setOpenPage("");
        pushExtra.setMsgImg("");//消息图标

        FeedMessageDto feedMessageDto = new FeedMessageDto();
        feedMessageDto.setRefreshType(1);
        pushExtra.setMsgContent(JsonUtils.obj2json(feedMessageDto));//消息内容

        return pushExtra;
    }

    private int saveOriginalMessagePo(ReceiveBaseMessage receiveBaseMessage) {
        OriginalMessagePo originalMessagePo = new OriginalMessagePo();
        originalMessagePo.setTriggerNodeName(receiveBaseMessage.getTriggerNodeName())
                .setSource(receiveBaseMessage.getSource())
                .setMessageInfo(JsonUtils.obj2json(receiveBaseMessage.getMessageInfo()))
                .setStatus(0);
        int cnt = originalMessageDao.saveOriginalMessagePo(originalMessagePo);
        if (cnt > 0) {
            return originalMessagePo.getId();
        }
        return 0;
    }


    private boolean checkUserIdAndOrderId(ReceiveBaseMessage.MessageInfo messageInfo) {
        if (null == messageInfo) {
            return false;
        }
        if ((messageInfo.getUserId() == null || messageInfo.getUserId() <= 0)
                && (messageInfo.getOrderId() == null || messageInfo.getOrderId() <= 0)) {
            return false;
        }

        return true;
    }

    public UserDto getUserInfo(Integer userId, Integer orderId) {
        try {
            if (userId != null && userId > 0) {
                return userProxy.getUserById(userId);
            }
            if (orderId != null && orderId > 0) {
                UserInfoDto userInfoDto = aladdinOrderProxy.getCustomerInfoByOrderId(orderId);
                if (null != userInfoDto) {
                    UserDto userDto = new UserDto();
                    userDto.setMobile(userInfoDto.getMobile())
                            .setId(userInfoDto.getUserId())
                            .setUsername(userInfoDto.getCustomerName());
                    return userDto;
                }
            }
        } catch (Exception e) {
            log.error(" getUserInfo 异常， userId:{}，orderId:{}", userId, orderId);
        }

        return null;
    }

}
