package com.ihomefnt.push.dao;

import com.ihomefnt.push.domain.po.MessageRecordPo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-12 10:15
 */
@Repository
public interface MessageRecordDao {
    int saveMessageRecord(MessageRecordPo messageRecordPo);

    int queryMessageCount(@Param("userId") Integer userId, @Param("orderId") Integer orderId, @Param("triggerNodeName") String triggerNodeName);

    int updateMessageRecordStatus(@Param("id") int id, @Param("pushStatus") int pushStatus);

    void batchSaveMessageRecord(List<MessageRecordPo> list);

    List<MessageRecordPo> queryMessageRecordFlow(@Param("userId") Integer userId, @Param("orderId") Integer orderId, @Param("from") Integer from, @Param("pageSize") Integer pageSize);

    int countMessageRecordFlow(@Param("userId") Integer userId, @Param("orderId") Integer orderId, @Param("from") Integer from, @Param("pageSize") Integer pageSize);

    int updateOpenUrlByOrderAndMsgNum(@Param("userId") Integer userId, @Param("orderId") Integer orderId, @Param("messageNum") Integer messageNum, @Param("openUrl") String openUrl);

    List<MessageRecordPo> queryMessageRecordByNode(@Param("userId") Integer userId, @Param("orderId") Long orderId, @Param("triggerNodeName") String triggerNodeName);

    void deleteMessageRecordByIds(List<Integer> list);
}
