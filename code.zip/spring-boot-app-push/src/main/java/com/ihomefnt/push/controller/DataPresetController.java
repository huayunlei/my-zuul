package com.ihomefnt.push.controller;

import com.ihomefnt.push.common.http.HttpBaseResponse;
import com.ihomefnt.push.domain.dto.TocMessageInfoRequest;
import com.ihomefnt.push.service.message.DataPresetService;
import com.ihomefnt.push.service.message.TocPresetService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-26 18:44
 */
@RestController
@Slf4j
public class DataPresetController {

    @Autowired
    private DataPresetService dataPresetService;
    @Autowired
    private TocPresetService tocPresetService;

    @ApiOperation(value = "fixBugDataPreset", notes = "处理老数据预置 签约后取消签约无设计需求的bug")
    @PostMapping("/fixBugDataPreset")
    public HttpBaseResponse fixBugDataPreset() {
        dataPresetService.fixBugDataPreset();
        return HttpBaseResponse.success();
    }

    @ApiOperation(value = "tocDataPreset", notes = "toc老数据信息流处理")
    @PostMapping("/tocDataPreset")
    public HttpBaseResponse tocDataPreset(@RequestBody TocMessageInfoRequest request) throws Exception {
        if(request==null || request.getTriggerNodeName()==null || request.getMsgType()==null){
            HttpBaseResponse.fail("请求参数不正确！");
        }
        tocPresetService.process(request);
        return HttpBaseResponse.success();
    }

}
