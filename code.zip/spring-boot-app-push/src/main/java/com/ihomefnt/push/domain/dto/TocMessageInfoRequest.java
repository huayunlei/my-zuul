package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author wanyunxin
 * @create 2020-03-06 14:44
 */
@Api("toc信息预置参数")
@Data
public class TocMessageInfoRequest {

    @ApiModelProperty("消息模版名称")
    private String triggerNodeName;

    @ApiModelProperty("消息类型 27为信息流 24为toc老用户邀请通知")
    private Integer msgType;
}
