package com.ihomefnt.push.controller;

import com.alibaba.nacos.api.config.annotation.NacosValue;
import com.ihomefnt.common.constant.MessageConstant;
import com.ihomefnt.message.RocketMQTemplate;
import com.ihomefnt.push.common.constant.MessageTriggerNodeEnum;
import com.ihomefnt.push.common.http.HttpBaseResponse;
import com.ihomefnt.push.domain.dto.PersonalAgentMessage;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.vo.DeleteOfflineDrawMessageRequestVo;
import com.ihomefnt.push.domain.vo.MessageRecordFlowResponseVo;
import com.ihomefnt.push.domain.vo.QueryMessageRecordFlowRequestVo;
import com.ihomefnt.push.service.message.MessageRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-12 13:29
 */
@Slf4j
@RestController
@Api(value = "PushController", description = "push 接口")
public class PushController {

    @Resource
    private RocketMQTemplate rocketMQTemplate;
    @Resource
    private MessageRecordService messageRecordService;

    @NacosValue(value = "${app.push.message.flow}", autoRefreshed = true)
    private String app_push_message_flow;

    @NacosValue(value = "${app.become.personal.agent}",autoRefreshed = true)
    private String app_become_personal_agent;

    @ApiOperation(value = "push", notes = "push接口")
    @PostMapping("/push")
    public HttpBaseResponse push(@RequestBody ReceiveBaseMessage request) {
        try {
            rocketMQTemplate.syncSend(app_push_message_flow, request);
        } catch (Exception e) {
            log.error("send message by mq exception {}", e.getMessage(), e);
            return HttpBaseResponse.fail("send message fail");
        }
        return HttpBaseResponse.success();
    }

    @ApiOperation(value = "tocPush", notes = "toc push消息模拟")
    @PostMapping("/tocPush")
    public HttpBaseResponse tocPush(@RequestBody PersonalAgentMessage request) {
        try {
            rocketMQTemplate.syncSend(app_become_personal_agent, request);
        } catch (Exception e) {
            log.error("send message by mq exception {}", e.getMessage(), e);
            return HttpBaseResponse.fail("send message fail");
        }
        return HttpBaseResponse.success();
    }

    @ApiOperation(value = "queryMessageRecordFlow", notes = "查询信息流接口")
    @PostMapping("/queryMessageRecordFlow")
    public HttpBaseResponse<MessageRecordFlowResponseVo> queryMessageRecordFlow(@RequestBody QueryMessageRecordFlowRequestVo request) {
        if (request.getOrderId() == null && request.getUserId() == null) {
            // 游客用户查询模版表
            MessageRecordFlowResponseVo responseVo = messageRecordService.queryMessageRecordsByTemplate(MessageTriggerNodeEnum.unLoginUser.name());
            return HttpBaseResponse.success(responseVo);
        }
        if (request.getPageNo() == null || request.getPageNo() < 1) {
            request.setPageNo(1);
        }
        if (request.getPageSize() == null || request.getPageSize() < 1) {
            request.setPageSize(10);
        }

        MessageRecordFlowResponseVo responseVo = messageRecordService.queryMessageRecordFlow(request);
        return HttpBaseResponse.success(responseVo);
    }

    @ApiOperation(value = "deleteOfflineDrawMessage", notes = "删除离线渲染信息流接口")
    @PostMapping("/deleteOfflineDrawMessage")
    public HttpBaseResponse<String> deleteOfflineDrawMessage(@RequestBody DeleteOfflineDrawMessageRequestVo request) {
        if (request.getOrderId() == null || request.getUserId() == null || request.getDraftProfileNum() == null) {
            return HttpBaseResponse.fail(MessageConstant.PARAMS_NOT_EXISTS);
        }

        messageRecordService.deleteOfflineDrawMessage(request);
        return HttpBaseResponse.success(MessageConstant.SUCCESS);
    }

}
