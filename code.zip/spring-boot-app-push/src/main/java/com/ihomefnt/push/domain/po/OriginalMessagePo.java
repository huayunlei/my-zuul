package com.ihomefnt.push.domain.po;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @Description:原消息po
 * @Author hua
 * @Date 2019-11-15 13:56
 */
@Data
@Accessors(chain = true)
public class OriginalMessagePo {
    private int id;

    private String triggerNodeName; //消息触发节点名称

    private String source; //消息来源，user-web、dolly-web

    private String messageInfo; //内容

    private int status; //状态 ： 0待推送，1已推送 ， -1推送失败

    private int delFlag; //删除标识 ： 0可用 ， 1删除

    private Date createTime;

    private Date updateTime;
}