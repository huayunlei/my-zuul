package com.ihomefnt.push.proxy;

import com.ihomefnt.common.api.ResponseVo;
import com.ihomefnt.common.http.HttpResponseCode;
import com.ihomefnt.push.common.constant.ServiceNameConstants;
import com.ihomefnt.push.common.http.HttpBaseResponse;
import com.ihomefnt.push.domain.dto.*;
import com.ihomefnt.zeus.finder.ServiceCaller;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wanyunxin
 * @create 2019-11-22 10:24
 */
@Service
public class WcmProxy {


    @Resource
    private ServiceCaller serviceCaller;

    public Integer addDecorationProcess(DecorationProcessDto decorationProcessDto) {
        ResponseVo<Integer> response = serviceCaller.post(ServiceNameConstants.ADD_DECORATION_PROCESS, decorationProcessDto,
                new TypeReference<ResponseVo<Integer>>() {
                });

        if (null != response && response.isSuccess()) {
            return response.getData();
        }
        return null;
    }

    public List<ShareOrderResponseDto> getShareOrderList(ShareOrderRequestDto params) {
        HttpBaseResponse<List<ShareOrderResponseDto>> response = serviceCaller.post(ServiceNameConstants.GET_SHARE_ORDER_LIST, params,
                new TypeReference<HttpBaseResponse<List<ShareOrderResponseDto>>>() {
                });

        if (null != response && HttpResponseCode.SUCCESS.equals(response.getCode())) {
            return response.getObj();
        }
        return null;
    }

    public DraftSimpleRequestPage queryDraftList(Integer orderId, int pageNo, int pageSize) {
        Map<String, Object> params = new HashMap<String, Object>();

        params.put("orderNum", orderId);
        params.put("pageNo", pageNo);
        params.put("pageSize", pageSize);
        HttpBaseResponse<DraftSimpleRequestPage> responseVo = serviceCaller.post(
                ServiceNameConstants.QUERY_DRAFT_LIST_BY_PAGE, params, new TypeReference<HttpBaseResponse<DraftSimpleRequestPage>>() {
                });

        if (responseVo != null && responseVo.getObj() != null) {
            return responseVo.getObj();
        }

        return null;
    }

    //条件查询方案记录数
    public Integer countOrderDraftRecords(Integer orderId) {
        Map<String, Object> params = new HashMap<String, Object>();

        params.put("orderNum", orderId);
        HttpBaseResponse<Integer> responseVo = serviceCaller.post(
                ServiceNameConstants.COUNT_ORDER_DRAFT_RECORDS, params, new TypeReference<HttpBaseResponse<Integer>>() {
                });

        if (responseVo != null && responseVo.getObj() != null) {
            return responseVo.getObj();
        }

        return null;
    }

    //分组查询可选方案数
    public List<OrderDraftCountGroupDto> countOrderDraftGroupByOrderNum(List<Integer> orderIdList) {
        HttpBaseResponse<List<OrderDraftCountGroupDto>> responseVo = serviceCaller.post(
                ServiceNameConstants.COUNT_ORDER_DRAFT_GROUP_BY_ORDER_NUM, orderIdList, new TypeReference<HttpBaseResponse<List<OrderDraftCountGroupDto>>>() {
                });

        if (responseVo != null && responseVo.getObj() != null) {
            return responseVo.getObj();
        }

        return null;
    }

    public PageResponse<TransferDto> getTransferDtoList(Map<String, Object> params) {
        if (params == null) {
            return null;
        }
        HttpBaseResponse<PageResponse<TransferDto>> responseVo = null;
        try {
            responseVo = serviceCaller.post(ServiceNameConstants.GET_TRANSFER_DTO_LIST, params,
                    new TypeReference<HttpBaseResponse<PageResponse<TransferDto>>>() {
                    });
        } catch (Exception e) {
            return null;
        }

        if (responseVo == null || responseVo.getObj() == null) {
            return null;
        }
        return responseVo.getObj();
    }

    public List<ShareOrderResponseDto> getShareOrderListByIds(List<String> shareIdList) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("shareIdList", shareIdList);
        HttpBaseResponse<List<ShareOrderResponseDto>> responseVo = null;
        try {
            responseVo = serviceCaller.post(ServiceNameConstants.GET_SHARE_ORDER_LIST_BY_IDS, params,
                    new TypeReference<HttpBaseResponse<List<ShareOrderResponseDto>>>() {
                    });
        } catch (Exception e) {
            return null;
        }

        if (responseVo == null || responseVo.getObj() == null) {
            return null;
        }
        return responseVo.getObj();
    }
}
