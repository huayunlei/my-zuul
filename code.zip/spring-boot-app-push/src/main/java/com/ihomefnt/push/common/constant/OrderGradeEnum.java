package com.ihomefnt.push.common.constant;

/**
 * @Description:等级id：0-普通 1-黄金 2-铂金 3-钻石 4-白银 5-青铜
 * @Author hua
 * @Date 2019-12-03 12:32
 */
public enum OrderGradeEnum {

    grade_0(0,"普通"),
    grade_1(1,"黄金"),
    grade_2(2,"铂金"),
    grade_3(3,"钻石"),
    grade_4(4,"白银"),
    grade_5(5,"青铜")
    ;

    private Integer gradeId;

    private String gradeName;

    OrderGradeEnum(Integer gradeId, String gradeName) {
        this.gradeId = gradeId;
        this.gradeName = gradeName;
    }

    public static String getGradeNameByGradeId(Integer gradeId){
        for (OrderGradeEnum item : OrderGradeEnum.values()) {
            if (gradeId == item.gradeId) {
                return item.gradeName;
            }
        }
        return null;
    }

}
