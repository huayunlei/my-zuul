package com.ihomefnt.push.service.push;

import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Description:实际开工推送消息处理
 * @Author hua
 * @Date 2019-11-19 17:30
 */
@Slf4j
@Service
public class StartDisclosureMessageHandle extends AbstactMessagePushHandle {

    public StartDisclosureMessageHandle() {
        super();
    }

    @Override
    protected List<MessageRecordPo> process(ReceiveBaseMessage receiveBaseMessage, List<PushTemplatePo> pushTemplateList) {
        log.info("StartDisclosureMessageHandle 实际开工推送消息处理， params:{}", receiveBaseMessage);
        List<MessageRecordPo> messageRecordPoList = new ArrayList<>(pushTemplateList.size());
        final ReceiveBaseMessage baseMessage = receiveBaseMessage;
        for (PushTemplatePo pushTemplatePo : pushTemplateList) {
            MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage);
            messageRecordPoList.add(messageRecordPo);
        }

        return messageRecordPoList;

    }

    private MessageRecordPo assemblePushRecordPo(PushTemplatePo pushTemplatePo, ReceiveBaseMessage baseMessage) {
        ReceiveBaseMessage.MessageInfo messageInfo = baseMessage.getMessageInfo();
        MessageRecordPo messageRecordPo = new MessageRecordPo();
        BeanUtils.copyProperties(pushTemplatePo, messageRecordPo);

        String content = pushTemplatePo.getContent();
        String subContent = pushTemplatePo.getSubContent();
        String openUrl = pushTemplatePo.getOpenUrl();
        if (StringUtils.isNotBlank(openUrl)) {
            openUrl = openUrl.replace("{orderId}", String.valueOf(messageInfo.getOrderId()));
        }

        messageRecordPo.setUserId(messageInfo.getUserId())
                .setOrderId(messageInfo.getOrderId())
                .setTitle(pushTemplatePo.getTitle())
                .setSubTitle(pushTemplatePo.getSubTitle())
                .setContent(content)
                .setSubContent(subContent)
                .setOpenUrl(openUrl)
                .setPushStatus(1)
                .setPushTime(new Date())
        ;

        return messageRecordPo;
    }

}

