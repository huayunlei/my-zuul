package com.ihomefnt.push.service.push;

import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.push.domain.dto.*;
import com.ihomefnt.push.proxy.AladdinOrderProxy;
import com.ihomefnt.push.proxy.DollyWebProxy;
import com.ihomefnt.push.proxy.WcmProxy;
import io.swagger.annotations.ApiModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author wanyunxin
 * @create 2019-11-22 10:34
 */
@Slf4j
@Service
@ApiModel(value = "装修历程数据处理")
public class DecorationProcessHandle {

    @Autowired
    private WcmProxy wcmProxy;

    @Autowired
    private DollyWebProxy dollyWebProxy;

    @Autowired
    private AladdinOrderProxy aladdinOrderProxy;


    public Integer addDecorationProcess(ReceiveBaseMessage receiveBaseMessage, UserDto userInfo){
        try {
            DecorationProcessDto decorationProcessDto = new DecorationProcessDto();
            decorationProcessDto.setOrderNum(receiveBaseMessage.getMessageInfo().getOrderId());
            decorationProcessDto.setTriggerNodeName(receiveBaseMessage.getTriggerNodeName());
            decorationProcessDto.setUserId(userInfo.getId());
            if(receiveBaseMessage.getTriggerNodeName().equals("completeHardDisclosureStage")//硬装竣工
                    ||receiveBaseMessage.getTriggerNodeName().equals("createLoanAijia")//申请装修贷款
                    ||receiveBaseMessage.getTriggerNodeName().equals("completeSoftDisclosureStage")){//软装到货安装
                decorationProcessDto.setEventContent("");
                log.info("add decoration process1 {}", JsonUtils.obj2json(decorationProcessDto));
                return wcmProxy.addDecorationProcess(decorationProcessDto);
            }
            if(receiveBaseMessage.getTriggerNodeName().equals("completeHardDisclosureSubStage")){//硬装阶段完工
                decorationProcessDto.setEventContent(receiveBaseMessage.getMessageInfo().getHardSubStatusName());
                log.info("add decoration process2 {}", JsonUtils.obj2json(decorationProcessDto));
                return wcmProxy.addDecorationProcess(decorationProcessDto);
            }

            if(receiveBaseMessage.getTriggerNodeName().equals("cancelScheme")//取消方案
                    ||receiveBaseMessage.getTriggerNodeName().equals("sendProgramOpinionForConfirm")//提交修改意见
                    ||receiveBaseMessage.getTriggerNodeName().equals("completeDesignDemand")){//专属方案上线
                decorationProcessDto.setEventContent(getSolutionNameById(receiveBaseMessage.getMessageInfo().getSolutionId()));
                log.info("add decoration process3 {}", JsonUtils.obj2json(decorationProcessDto));
                return wcmProxy.addDecorationProcess(decorationProcessDto);
            }

            if(receiveBaseMessage.getTriggerNodeName().equals("signAContract")//提交签约方案
                    ||receiveBaseMessage.getTriggerNodeName().equals("payAllMoney")){//付清全款
                Integer solutionId = receiveBaseMessage.getMessageInfo().getSolutionId();
                String solutionName = "";
                if(solutionId == null){//方案id为空，主动查询
                    SolutionInfo solutionInfo = aladdinOrderProxy.querySolutionInfo(receiveBaseMessage.getMessageInfo().getOrderId());
                    if(solutionInfo!=null && solutionInfo.getSolutionName()!=null){
                        solutionName= solutionInfo.getSolutionName();
                    }
                }else{
                    solutionName = getSolutionNameById(solutionId);
                }
                decorationProcessDto.setEventContent(solutionName);
                log.info("add decoration process4 {}", JsonUtils.obj2json(decorationProcessDto));
                return wcmProxy.addDecorationProcess(decorationProcessDto);
            }

        }catch (Exception e){
            log.error("add decoration process error",e);
        }
        return 1;
    }

    /**
     * 根据方案id获取方案名称
     * @param solutionId
     * @return
     */
    private String getSolutionNameById(Integer solutionId){
        if(solutionId == null){
            return "";
        }
        SolutionDetailResponseDto solutionDetailResponseDto = dollyWebProxy.getProgramDetailById(solutionId);
        return solutionDetailResponseDto.getSolutionName();
    }

}
