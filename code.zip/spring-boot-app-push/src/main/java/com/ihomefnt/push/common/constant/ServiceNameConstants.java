package com.ihomefnt.push.common.constant;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-15 18:13
 */
public interface ServiceNameConstants {
    String QUERY_RECORD_LIST_BY_MIN_VERSION = "mobile-api.version.queryRecordListByMinVersion";

    /**
     * 根据用户id查询用户信息
     */
    String GET_USER_BY_ID = "user-web.user.getUserById";


    /**
     * 根据订单ID查询用户ID和手机号
     */
    String QUERY_CUSTOMER_INFO_BY_ORDER_ID = "aladdin-order.masterOrder-app.queryCustomerInfo";

    /**
     * 个性化需求
     */
    String QUERY_DESIGN_DEMOND_HISTORY = "dolly-web.design-api.queryDesignDemondHistory";

    /**
     * 个性化需求
     */
    String QUERY_DESIGN_DEMOND = "dolly-web.design-api.queryDesignDemond";


    /**
     * 新增装修历程
     */
    String ADD_DECORATION_PROCESS="wcm-web.decorationQuotation.addDecorationProcess";

    /**
     * App5.0大订单基础信息查询
     */
    String QUERY_APP_ORDER_BASE_INFO="aladdin-order.masterOrder-app.v5_0.queryAppOrderBaseInfo";

    /**
     * 查询可升级权益
     */
    String QUERY_NEW_UPGRADE_INFO="aladdin-order.order-rights.newUpgradeInfo";

    /**
     * 批量查询方案信息
     */
    String BATCH_QUERY_SOLUTION_BASEINFO="dolly-web.solution.batchQuerySolutionBaseInfo";

    /**
     * 查询爱家贷
     */
    String LOAN_APP_QUERY_LOAN_INFOS = "aladdin-order.loanInfo-app.loan.appQueryLoanInfos";

    /**
     * 权益版本查询
     */
    String ALADDIN_ORDER_MASTERORDER_APP_QUERYORDERVERSION = "aladdin-order.masterOrder-app.queryOrderVersion";

    /**
     * 查询晒家列表
     */
    String GET_SHARE_ORDER_LIST = "wcm-web.shareorder.getShareOrderList";

    String GET_TRANSFER_DTO_LIST = "wcm-web.transfer.getTransferDtoList";
    String GET_SHARE_ORDER_LIST_BY_IDS = "wcm-web.shareorder.getShareOrderListByIds";



    String QUERY_SOLUTION_LIST = "dolly-web.solution-app.querySolutionList";

    String QUERY_ORDER_SOLUTION_INFO = "aladdin-order.masterOrder-app.queryOrderSolutionInfo";

    String QUERY_DRAFT_LIST_BY_PAGE = "wcm-web.draftNew.queryDraftListByPage";

    String COUNT_ORDER_DRAFT_RECORDS = "wcm-web.draftNew.countOrderDraftRecords";

    String COUNT_ORDER_DRAFT_GROUP_BY_ORDER_NUM = "wcm-web.draftNew.countOrderDraftGroupByOrderNum";

    String QUERY_AVAILABLE_SOLUTION_COUNT = "dolly-web.solution-app.queryAvailableSolutionCount";

}
