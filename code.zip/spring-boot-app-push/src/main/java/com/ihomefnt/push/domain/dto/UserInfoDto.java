package com.ihomefnt.push.domain.dto;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-20 13:50
 */
@Data
@Accessors(chain = true)
public class UserInfoDto {
    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 用户名
     */
    private String customerName;

    /**
     * 手机号码
     */
    private String mobile;
}
