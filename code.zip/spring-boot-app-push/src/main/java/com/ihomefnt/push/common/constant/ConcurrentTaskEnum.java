package com.ihomefnt.push.common.constant;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-03 14:47
 */
public enum ConcurrentTaskEnum {
    QUERY_SOLUTION_DESC_LIST,
    COUNT_ORDER_DRAFT_RECORDS,
    QUERY_DRAFT_LIST
}
