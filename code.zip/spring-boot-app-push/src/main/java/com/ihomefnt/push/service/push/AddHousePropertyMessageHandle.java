package com.ihomefnt.push.service.push;

import com.ihomefnt.push.common.constant.DnaHeadImgsData;
import com.ihomefnt.push.common.constant.LifeArticleHeadImgsData;
import com.ihomefnt.push.common.constant.MessageTriggerNodeEnum;
import com.ihomefnt.push.dao.MessageRecordDao;
import com.ihomefnt.push.dao.PushTemplateDao;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.service.cache.PushTemplateCacheService;
import com.ihomefnt.redis.GracefulRedisTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Description:维护房产消息处理
 * @Author hua
 * @Date 2019-11-18 18:10
 */
@Slf4j
@Service
public class AddHousePropertyMessageHandle extends AbstactMessagePushHandle {
    @Autowired
    private MessageRecordDao messageRecordDao;
    @Resource
    private GracefulRedisTemplate gracefulRedisTemplate;
    @Autowired
    private PushTemplateDao pushTemplateDao;
    @Autowired
    private PushTemplateCacheService pushTemplateCacheService;


    @Override
    protected List<MessageRecordPo> process(ReceiveBaseMessage receiveBaseMessage, List<PushTemplatePo> pushTemplateList) {
        log.info("AddHousePropertyMessageHandle 维护房产消息处理， params:{}", receiveBaseMessage);
        List<MessageRecordPo> messageRecordPoList = new ArrayList<>(pushTemplateList.size());
        ReceiveBaseMessage.MessageInfo messageInfo = receiveBaseMessage.getMessageInfo();

        for (PushTemplatePo pushTemplatePo : pushTemplateList) {
            MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, messageInfo);
            messageRecordPoList.add(messageRecordPo);
        }

        // orderId回写装修贷款信息流的二级跳转url
        List<PushTemplatePo> addUserTemplateList = pushTemplateCacheService.getByTriggerNodeName(MessageTriggerNodeEnum.addNewUser.name(),1);
        if (CollectionUtils.isNotEmpty(addUserTemplateList)) {
            String openUrl = null;
            for (PushTemplatePo po : addUserTemplateList) {
                if (8 == po.getMessageNum()) {
                    openUrl = po.getOpenUrl();
                    break;
                }
            }
            if (StringUtils.isNotBlank(openUrl)) {
                openUrl = openUrl + "?orderId="+messageInfo.getOrderId();
                messageRecordDao.updateOpenUrlByOrderAndMsgNum(messageInfo.getUserId(), 0, 8, openUrl);
            }
        }
        return messageRecordPoList;
    }

    private MessageRecordPo assemblePushRecordPo(PushTemplatePo pushTemplatePo, ReceiveBaseMessage.MessageInfo messageInfo) {
        MessageRecordPo messageRecordPo = new MessageRecordPo();
        BeanUtils.copyProperties(pushTemplatePo, messageRecordPo);

        String content = pushTemplatePo.getContent();
        String subContent = pushTemplatePo.getSubContent();
        String openUrl = pushTemplatePo.getOpenUrl();
        if (openUrl != null) {
            openUrl = openUrl.replace("{orderId}", String.valueOf(messageInfo.getOrderId()));
        }
        // 设计案例
        if (9 == pushTemplatePo.getMessageNum() && StringUtils.isBlank(pushTemplatePo.getCardImgs())) {
            messageRecordPo.setCardImgs(DnaHeadImgsData.getCompressImgs(pushTemplatePo.getCardType()));
        }
        // 装修故事
        if (11 == pushTemplatePo.getMessageNum() && StringUtils.isBlank(pushTemplatePo.getCardImgs())) {
            messageRecordPo.setCardImgs(LifeArticleHeadImgsData.getCompressImgs(pushTemplatePo.getCardType(), 5));
        }

        messageRecordPo.setUserId(messageInfo.getUserId())
                .setOrderId(messageInfo.getOrderId())
                .setTitle(pushTemplatePo.getTitle())
                .setSubTitle(pushTemplatePo.getSubTitle())
                .setContent(content)
                .setSubContent(subContent)
                .setOpenUrl(openUrl)
                .setPushStatus(1)
                .setPushTime(new Date())
        ;

        return messageRecordPo;
    }
}
