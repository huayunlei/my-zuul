package com.ihomefnt.push.service.push;

import com.ihomefnt.push.domain.dto.AppOrderBaseInfoResponseVo;
import com.ihomefnt.push.domain.dto.AppSolutionDesignDto;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.proxy.AladdinOrderProxy;
import com.ihomefnt.push.proxy.DollyWebProxy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Description:小艾发送设计需求给客户消息处理
 * @Author hua
 * @Date 2019-11-18 18:19
 */
@Slf4j
@Service
public class SendDesignDemandForConfirmMessageHandle extends AbstactMessagePushHandle {
    @Autowired
    private AladdinOrderProxy aladdinOrderProxy;
    @Autowired
    private DollyWebProxy dollyWebProxy;

    @Override
    protected List<MessageRecordPo> process(ReceiveBaseMessage receiveBaseMessage, List<PushTemplatePo> pushTemplateList) {
        log.info("SendDesignDemandForConfirmMessageHandle 小艾发送设计需求给客户消息处理， params:{}", receiveBaseMessage);
        List<MessageRecordPo> messageRecordPoList = new ArrayList<>(pushTemplateList.size());
        final ReceiveBaseMessage baseMessage = receiveBaseMessage;
        for (PushTemplatePo pushTemplatePo : pushTemplateList) {
            MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage);
            messageRecordPoList.add(messageRecordPo);
        }

        return messageRecordPoList;
    }

    private MessageRecordPo assemblePushRecordPo(PushTemplatePo pushTemplatePo, ReceiveBaseMessage baseMessage) {
        ReceiveBaseMessage.MessageInfo messageInfo = baseMessage.getMessageInfo();
        MessageRecordPo messageRecordPo = new MessageRecordPo();
        BeanUtils.copyProperties(pushTemplatePo, messageRecordPo);

        String content = pushTemplatePo.getContent();
        String subContent = pushTemplatePo.getSubContent();
        String openUrl = pushTemplatePo.getOpenUrl();
        AppOrderBaseInfoResponseVo orderBaseInfo = aladdinOrderProxy.queryAppOrderBaseInfo(messageInfo.getOrderId());
        if (null != orderBaseInfo && StringUtils.isNotBlank(openUrl) && null != orderBaseInfo.getLayoutId()) {
            openUrl = openUrl.replace("{userId}", String.valueOf(messageInfo.getUserId()))
                    .replace("{orderId}", String.valueOf(messageInfo.getOrderId()))
                    .replace("{designDemandId}", messageInfo.getDesignDemandId())
                    .replace("{houseTypeId}", String.valueOf(orderBaseInfo.getLayoutId()));
        }

        // 设计需求中选择DNA的头图
        AppSolutionDesignDto solutionDesignDto = dollyWebProxy.queryDesignDemond(messageInfo.getOrderId());
        if (null != solutionDesignDto && StringUtils.isNotBlank(solutionDesignDto.getDnaHeadImg())) {
            messageRecordPo.setCardImgs(solutionDesignDto.getDnaHeadImg()+"!H-SMALL");
        }

        messageRecordPo.setUserId(messageInfo.getUserId())
                .setOrderId(messageInfo.getOrderId())
                .setTitle(pushTemplatePo.getTitle())
                .setSubTitle(pushTemplatePo.getSubTitle())
                .setContent(content)
                .setSubContent(subContent)
                .setOpenUrl(openUrl)
                .setPushStatus(1)
                .setPushTime(new Date())
        ;

        return messageRecordPo;
    }
}
