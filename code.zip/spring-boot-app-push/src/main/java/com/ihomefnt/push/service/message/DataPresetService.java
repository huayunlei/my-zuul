package com.ihomefnt.push.service.message;

import com.alibaba.ttl.threadpool.TtlExecutors;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ihomefnt.push.common.constans.MessageStatus;
import com.ihomefnt.push.dao.DataPresetDao;
import com.ihomefnt.push.dao.MessageRecordDao;
import com.ihomefnt.push.dao.PushTemplateDao;
import com.ihomefnt.push.dao.TempOrderDeliveryDao;
import com.ihomefnt.push.domain.dto.AppVersionDto;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.domain.po.TempOrderDeliveryPo;
import com.ihomefnt.push.dto.SendJPushMessage;
import com.ihomefnt.push.po.MessageSource;
import com.ihomefnt.push.po.MessageType;
import com.ihomefnt.push.po.jpush.JPushExtra;
import com.ihomefnt.push.po.jpush.PhoneOS;
import com.ihomefnt.push.po.jpush.TargetClients;
import com.ihomefnt.push.proxy.AppVersionProxy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-25 13:54
 */
@Slf4j
@Service
public class DataPresetService {
    private static int threadCount = 200;
    private static final ExecutorService exec = TtlExecutors.getTtlExecutorService(Executors.newFixedThreadPool(threadCount));

    @Autowired
    private AppVersionProxy appVersionProxy;
    @Autowired
    private PushTemplateDao pushTemplateDao;
    @Autowired
    private DataPresetDao dataPresetDao;
    @Autowired
    private MessageRecordDao messageRecordDao;
    @Autowired
    private TempOrderDeliveryDao tempOrderDeliveryDao;
    @Autowired
    private MqMessagePushService mqMessagePushService;

    private PushTemplatePo constructionNotifyPushTemplatePo;
    private String tags;
    @Async
    public void fixBugDataPreset() {
        long start = System.currentTimeMillis();
        // 查询模版
        List<PushTemplatePo> pushTemplateList = pushTemplateDao.queryByTriggerNodeName("constructionNotify",2);
        if (CollectionUtils.isEmpty(pushTemplateList)) {
            return;
        }
        constructionNotifyPushTemplatePo = pushTemplateList.get(0);

        // 查询要处理的数据
        int recordTotalCount = tempOrderDeliveryDao.countTempOrderDeliveryRecords();// 总记录数  查询的总记录数
        log.info("fixBugDataPreset begin 要处理的总记录数:{}", recordTotalCount);
        if (recordTotalCount < 1) {
            return;
        }

        if (StringUtils.isNotEmpty(constructionNotifyPushTemplatePo.getMinVersion())) {
            List<AppVersionDto> versionDtoList = appVersionProxy.queryRecordListByMinVersion(constructionNotifyPushTemplatePo.getMinVersion(), Lists.newArrayList("washriwvd8c6r6nz","eax4kpvv3nsuk837"));
            if (!org.springframework.util.CollectionUtils.isEmpty(versionDtoList)) {
                Set<String> versionSet = versionDtoList.parallelStream().map(versionDto -> versionDto.getVersion()).collect(Collectors.toSet());
                tags = versionSet.stream().collect(Collectors.joining(","));
            }
        }

        int recordPageSize = 300;// 每次最多查询记录数
        int recordPageNum = 1;
        while (true) {
            // limit from, recordPageSize
            List<TempOrderDeliveryPo> list = tempOrderDeliveryDao.queryTempOrderDeliveryRecordsPage(0, recordPageSize);// 分页查询record
            if (CollectionUtils.isEmpty(list)) {
                break;
            }

            int totalCount = list.size();
            int pageSize = 15;
            int totalPage = totalCount%pageSize==0 ? totalCount/pageSize : totalCount/pageSize+1;
            final CountDownLatch latch = new CountDownLatch(totalPage);
            for (int pageNum = 1;pageNum <= totalPage; pageNum++) {
                int fromIndex = (pageNum-1)*pageSize;
                int endIndex = pageNum == totalPage ? totalCount : pageNum*pageSize;
                List<TempOrderDeliveryPo> subList = list.subList(fromIndex, endIndex);
                // 多线程分页
                exec.execute(new FixBugDataPresetRunnable(latch, subList, recordPageNum, pageNum));
            }

            try {
                latch.await();
                Thread.sleep(500L);
            }catch (Exception e) {
                log.error("第 "+recordPageNum+" 次分页查询处理异常", e);
            }
            log.info("第 {} 次分页查询处理完成，subList size：{}", recordPageNum, list.size());
            recordPageNum++;
        }

        log.info("DataPresetService.fixBugDataPreset所有数据处理完成，times：{}", System.currentTimeMillis() - start);
    }

    class FixBugDataPresetRunnable implements Runnable {
        private CountDownLatch latch;
        private List<TempOrderDeliveryPo> subList;
        private int recordPageNum;
        private int pageNum;

        public FixBugDataPresetRunnable(CountDownLatch latch, List<TempOrderDeliveryPo> subList, int recordPageNum, int pageNum) {
            this.latch = latch;
            this.subList = subList;
            this.recordPageNum = recordPageNum;
            this.pageNum = pageNum;
        }

        @Override
        public void run() {
            try {
                List<Integer> ids = new ArrayList<>();
                List<MessageRecordPo> addRecordList = new ArrayList<>();
                for (TempOrderDeliveryPo item : subList) {
                    MessageRecordPo messageRecordPo = new MessageRecordPo();
                    BeanUtils.copyProperties(constructionNotifyPushTemplatePo, messageRecordPo);
                    messageRecordPo.setPushStatus(-6)
                            .setUserId(item.getUserId())
                            .setOrderId(item.getOrderId())
                            .setPushTime(new Date())
                            .setAlias(item.getMobile())
                            .setTags(tags);

                    mqMessagePushService.checkSaveMessageRecordNull(messageRecordPo);
                    // 推送消息
                    assembleAndSendJPushMessage(messageRecordPo);
                    ids.add(item.getId());
                    addRecordList.add(messageRecordPo);
                }
                // 批量保存MessageRecordPo
                messageRecordDao.batchSaveMessageRecord(addRecordList);

                // 批量更新状态
                tempOrderDeliveryDao.batchUpdateByIds(ids);
                log.info("第 {} 次分页查询，第 {} 次线程处理完成", recordPageNum, pageNum);
            } catch (Exception e) {
                log.error("第 " + recordPageNum + " 次分页查询，第 " + pageNum + " 次线程处理异常", e);
            } finally {
                latch.countDown();
            }
        }

        private void assembleAndSendJPushMessage(MessageRecordPo messageRecordPo) {
            SendJPushMessage jPushMessage = new SendJPushMessage();
            if ("MESSAGE".equals(constructionNotifyPushTemplatePo.getPushType())) {
                jPushMessage.setDiyMsg(true);
            } else {
                jPushMessage.setDiyMsg(false);
            }
            jPushMessage.setMsgTitle(messageRecordPo.getTitle());
            jPushMessage.setMsgContent(messageRecordPo.getSubContent());
            jPushMessage.setMessageType(MessageType.JPUSH);

            TargetClients targetClients = new TargetClients();
            String mobile = messageRecordPo.getAlias();
            String version = messageRecordPo.getTags();
            if (StringUtils.isBlank(version)) {// 版本号为空不推送
                return;
            }
            if (StringUtils.isBlank(mobile)) {// 手机号为空不推送
                return;
            }
            version = version.replace(".", "_");
            targetClients.setAlias(new HashSet<>(Arrays.asList(mobile.split(","))));
            // 版本号可能会重复，此处去重
            targetClients.setTag(new HashSet<>(Arrays.asList(version.split(","))));
            jPushMessage.setTargetClients(targetClients);

            jPushMessage.setPlatform(Sets.newHashSet(PhoneOS.ALL));
            jPushMessage.setReceiveTime(System.currentTimeMillis());
            jPushMessage.setMessageStatus(MessageStatus.RECEIVED.getValue());

            JPushExtra pushExtra = assembleJPushExtra(messageRecordPo, constructionNotifyPushTemplatePo.getRefreshType());
            jPushMessage.setExtra(pushExtra);

            mqMessagePushService.pushMessage(jPushMessage);
        }

        private JPushExtra assembleJPushExtra(MessageRecordPo messageRecord, int refreshType) {
            JPushExtra pushExtra = new JPushExtra();
            pushExtra.setMsgType(26);
            pushExtra.setCreateTime(System.currentTimeMillis());// 发送时间
            pushExtra.setUnReadCount(1);// 未读数加1
            pushExtra.setSaveInMsgCenter(1);// 是否是消息组 :1是0否
            pushExtra.setMessageGroupStatus(0);// 是否需要消息分组 :1是0否
            pushExtra.setOpenPage(messageRecord.getOpenUrl());
            pushExtra.setMsgImg(messageRecord.getImg());//消息图标
            return pushExtra;
        }
    }
}
