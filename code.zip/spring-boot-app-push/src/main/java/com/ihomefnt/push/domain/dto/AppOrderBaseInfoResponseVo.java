package com.ihomefnt.push.domain.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel("订单信息")
public class AppOrderBaseInfoResponseVo {

	@ApiModelProperty("订单号")
	private Integer orderNum;//订单号

	@ApiModelProperty("订单类型 0:方案下单，6:代客下单")
	private Integer source;//订单类型

	@ApiModelProperty("beta订单状态，app前端慎用")
	private Integer orderStatus;//订单阶段

	@ApiModelProperty("订单阶段-子状态(161,未签约),(162,签约中),(163,签约成功)")
	private Integer orderSubstatus;

	@ApiModelProperty("已付金额")
	private BigDecimal fundAmount;//已付金额

	@ApiModelProperty("款项类型")
	private Integer paymentType;//款项类型

	@ApiModelProperty("合同价")
	private BigDecimal contractAmount;//订单总额

	@ApiModelProperty("收款进度")
	private BigDecimal fundProcess;//收款进度  0.34

	@ApiModelProperty("方案头图")
	private String solutionUrl;//已选方案首图

	@ApiModelProperty("创建时间")
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	private Date createTime;//创建时间

	@ApiModelProperty("更新时间")
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	private Date updateTime;//创建时间

	@ApiModelProperty("已选方案风格名称")
	private String solutionStyleName;//已选方案风格名称

	@ApiModelProperty("已选方案风格id")
	private Integer solutionStyleId;//已选方案风格id

	@ApiModelProperty("置家顾问id")
	private Integer adviser;//置家顾问id

	@ApiModelProperty("置家顾问")
	private String adviserName;//置家顾问

	@ApiModelProperty("置家顾问电话")
	private String adviserPhone;//置家顾问电话

	@ApiModelProperty("距离交房还差多少天")
	private Integer deliverDiff;//距离交房还差多少天

	@ApiModelProperty("是否是老订单(0. 老订单 1. 新订单)")
	private Integer oldOrder;//是否是老订单(0. 老订单 1. 新订单)

	@ApiModelProperty("售卖类型：0：全品家（软+硬） 1：全品家（软）")
	private Integer orderSaleType;//售卖类型：0：全品家（软+硬） 1：全品家（软）

	@ApiModelProperty("楼盘id")
	private Integer buildingId;//楼盘id

	@ApiModelProperty("户型id")
	private Integer layoutId;//户型id

	@ApiModelProperty("权益等级")
	private Integer gradeId;//权益等级 0-普通 1-黄金 2-铂金 3-钻石 4-白银 5-青铜

	@ApiModelProperty("权益等级名称")
	private String gradeName;//等级名称

	@ApiModelProperty("用户是否已预确认方案，0:未预确认  1：已确认")
	private Integer preConfirmed;//用户是否已预确认方案，0:未预确认  1：已确认

	@ApiModelProperty("用户享受权益并缴满全款，0: 不满足  1: 满足")
	private Integer allMoney;//用户享受权益并缴满全款，0: 不满足  1: 满足

	@ApiModelProperty("软装商品总数")
	private Integer totalProductCount;//软装商品总数

	@ApiModelProperty("送货完成数")
	private Integer completeDelivery;//送货完成数

	@ApiModelProperty("艾升级券面值")
	private BigDecimal upGradeCouponAmount;// 艾升级券面值

	@ApiModelProperty("订单原始金额（方案总价）")
	private BigDecimal originalOrderAmount;// 订单原始金额（方案总价）

	@JsonIgnore
	@ApiModelProperty(hidden = true)
	private BigDecimal orderTotalAmount;//订单总价,beta订单总价和

	@ApiModelProperty("方案总价")
	private BigDecimal solutionAmount;

	@ApiModelProperty("定价优惠")
	private BigDecimal priceDisAmount;

	@ApiModelProperty("艾升级优惠")
	private BigDecimal upgradeDisAmount;

	@ApiModelProperty("促销优惠")
	private BigDecimal promotionDisAmount;

	@ApiModelProperty("艾升级权益可抵扣金额")
	private BigDecimal upItemDeAmount;

	@ApiModelProperty("房产id")
	private Integer houseId;

	@ApiModelProperty("-1:失效（老订单） 0：锁价中 1：最终锁价")
	private Integer lockPriceFlag;

	@ApiModelProperty("锁价倒计时")
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	private Date lockPriceExpireTime;

}
