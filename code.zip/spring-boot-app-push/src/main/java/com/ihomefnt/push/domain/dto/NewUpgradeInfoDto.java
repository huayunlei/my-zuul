package com.ihomefnt.push.domain.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-03 10:48
 */
@Data
public class NewUpgradeInfoDto {

    private Integer orderNum;

    private String firstFundTime;

    private boolean upgradable;

    private List<UpgradeItem> upgradeList;

    @Data
    public class UpgradeItem {
        private String gradeName;
        private Date lastDate;
        private BigDecimal paymentRequiredAmount;
    }

}
