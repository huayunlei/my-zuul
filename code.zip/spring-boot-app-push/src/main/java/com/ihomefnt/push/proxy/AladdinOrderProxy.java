package com.ihomefnt.push.proxy;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ihomefnt.common.api.ResponseVo;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.push.common.constant.ServiceNameConstants;
import com.ihomefnt.push.domain.dto.*;
import com.ihomefnt.zeus.finder.ServiceCaller;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-20 13:47
 */
@Slf4j
@Service
public class AladdinOrderProxy {

    @Resource
    private ServiceCaller serviceCaller;

    public UserInfoDto getCustomerInfoByOrderId(Integer orderId) {
        ResponseVo<UserInfoDto> response = serviceCaller.post(ServiceNameConstants.QUERY_CUSTOMER_INFO_BY_ORDER_ID, orderId,
                new TypeReference<ResponseVo<UserInfoDto>>() {
                });

        if (null != response && response.isSuccess()) {
            return response.getData();
        }
        return null;
    }

    /**
     * App5.0大订单基础信息查询
     */
    public AppOrderBaseInfoResponseVo queryAppOrderBaseInfo(Integer orderId) {
        ResponseVo<AppOrderBaseInfoResponseVo> responseVo = serviceCaller.post(ServiceNameConstants.QUERY_APP_ORDER_BASE_INFO, orderId,
                    new TypeReference<ResponseVo<AppOrderBaseInfoResponseVo>>() {
                    });
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return responseVo.getData();
        }
        return null;
    }

    public List<LoanMainInfoDto> queryLoanInfoList(Integer orderId) {
        JSONObject param = new JSONObject();
        param.put("orderNum", orderId);
        ResponseVo<List<LoanMainInfoDto>> responseVo = serviceCaller.post(ServiceNameConstants.LOAN_APP_QUERY_LOAN_INFOS, param,
                new TypeReference<ResponseVo<List<LoanMainInfoDto>>>() {
                });
        if (responseVo != null && responseVo.isSuccess()) {
            return responseVo.getData();
        }

        return null;
    }

    /**
     * 查询可升级权益
     */
    public NewUpgradeInfoDto queryNewUpgradeInfo(Integer orderNum) {
        ResponseVo responseVo = serviceCaller.post(ServiceNameConstants.QUERY_NEW_UPGRADE_INFO, orderNum, ResponseVo.class);
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return JsonUtils.json2obj(JsonUtils.obj2json(responseVo.getData()), NewUpgradeInfoDto.class);
        }
        return null;
    }

    /**
     * 查询订单选方案信息
     *
     * @return
     */
    public SolutionInfo querySolutionInfo(Integer orderId) {
        ResponseVo<SolutionInfo> responseVo = null;
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("orderNum", orderId);
        log.info("service: {}, params {}", ServiceNameConstants.QUERY_ORDER_SOLUTION_INFO, JSON.toJSONString(paramMap));
        try {
            responseVo = serviceCaller.post(ServiceNameConstants.QUERY_ORDER_SOLUTION_INFO, paramMap,
                    new TypeReference<ResponseVo<SolutionInfo>>() {
                    });
        } catch (Exception e) {
            log.error("service: {} error , message :", ServiceNameConstants.QUERY_ORDER_SOLUTION_INFO, e);
            return null;
        }
        log.info("service: {} , response:{}", ServiceNameConstants.QUERY_ORDER_SOLUTION_INFO,  JSON.toJSONString(responseVo));
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return responseVo.getData();
        }
        return null;
    }

    /**
     * 查询当前用户权益版本
     * @return obj
     */
    public GradeVersionDto queryCurrentVersion(Integer orderNum) {
        ResponseVo<GradeVersionDto> response;
        log.info("service: {}, params {}", ServiceNameConstants.ALADDIN_ORDER_MASTERORDER_APP_QUERYORDERVERSION, JSON.toJSONString(orderNum));
        try{
            response = serviceCaller.post(ServiceNameConstants.ALADDIN_ORDER_MASTERORDER_APP_QUERYORDERVERSION, orderNum,
                    new TypeReference<ResponseVo<GradeVersionDto>>() {
                    });
        }catch (Exception e){
            log.error("service: {} error , message :", ServiceNameConstants.ALADDIN_ORDER_MASTERORDER_APP_QUERYORDERVERSION, e);
            return null;
        }

        if (response == null || response.getData() == null) {
            return null;
        }
        return response.getData();
    }

    public List<CustomerSimpleInfoDto> queryAllFundCustomer() {
        ResponseVo<List<CustomerSimpleInfoDto>> responseVo = null;
        long start = System.currentTimeMillis();
        try {
            responseVo = serviceCaller.post("aladdin-order.masterOrder-app.queryAllFundCustomer", null, new TypeReference<ResponseVo<List<CustomerSimpleInfoDto>>>() {
            });
            log.info("ServiceName : aladdin-order.masterOrder-app.queryAllFundCustomer success   耗时 " + (System.currentTimeMillis() - start) + "ms  resp" + JSON.toJSONString(responseVo));
            XxlJobLogger.log("ServiceName : aladdin-order.masterOrder-app.queryAllFundCustomer success   耗时 " + (System.currentTimeMillis() - start) + "ms  resp" + JSON.toJSONString(responseVo));
        } catch (Exception e) {
            log.error("订单系统调用失败! ServiceName : aladdin-order.masterOrder-app.queryAllFundCustomer");
            XxlJobLogger.log("error 订单系统调用失败! ServiceName : aladdin-order.masterOrder-app.queryAllFundCustomer   耗时 " + (System.currentTimeMillis() - start) + "ms");
        }
        if (responseVo != null && responseVo.isSuccess()) {
            return responseVo.getData();
        }
        return null;
    }

}
