package com.ihomefnt.push.service.push;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.common.util.ServiceLocator;
import com.ihomefnt.message.RocketMQTemplate;
import com.ihomefnt.push.common.constans.MessageStatus;
import com.ihomefnt.push.common.constant.MessageQueueName;
import com.ihomefnt.push.configuration.AppPushCommonNacosCofig;
import com.ihomefnt.push.dao.MessageRecordDao;
import com.ihomefnt.push.dao.OriginalMessageDao;
import com.ihomefnt.push.domain.dto.*;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.OriginalMessagePo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.dto.BaseMessage;
import com.ihomefnt.push.dto.SendJPushMessage;
import com.ihomefnt.push.po.MessageSource;
import com.ihomefnt.push.po.MessageType;
import com.ihomefnt.push.po.jpush.JPushExtra;
import com.ihomefnt.push.po.jpush.PhoneOS;
import com.ihomefnt.push.po.jpush.TargetClients;
import com.ihomefnt.push.proxy.AladdinOrderProxy;
import com.ihomefnt.push.proxy.AppVersionProxy;
import com.ihomefnt.push.service.cache.PushTemplateCacheService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 通用消息数据处理
 */
@Slf4j
public abstract class CommonMessagePushHandle {

    private RocketMQTemplate rocketMQTemplate;
    private MessageRecordDao messageRecordDao;
    private AppVersionProxy appVersionProxy;
    private PushTemplateCacheService pushTemplateCacheService;
    private AppPushCommonNacosCofig appPushCommonNacosCofig;

    private volatile boolean isInited = false;

    public CommonMessagePushHandle() {
    }

    private synchronized void init() {
        if (isInited) {
            return;
        }
        this.rocketMQTemplate = (RocketMQTemplate) ServiceLocator.init().getService(RocketMQTemplate.class);
        this.messageRecordDao = (MessageRecordDao) ServiceLocator.init().getService(MessageRecordDao.class);
        this.appVersionProxy = (AppVersionProxy) ServiceLocator.init().getService(AppVersionProxy.class);
        this.pushTemplateCacheService = (PushTemplateCacheService)ServiceLocator.init().getService(PushTemplateCacheService.class);
        this.appPushCommonNacosCofig = (AppPushCommonNacosCofig)ServiceLocator.init().getService(AppPushCommonNacosCofig.class);

        this.isInited = true;
    }

    // 消息资源查询
    protected abstract List<MessageRecordPo> process(Object commonMessage, List<PushTemplatePo> pushTemplateList);

    public void handle( Object commonMessage,String triggerNodeName) {
        if (!isInited) {
            init();
        }
        List<PushTemplatePo> pushTemplateList = pushTemplateCacheService.getByTriggerNodeName(triggerNodeName,2);
        if (CollectionUtils.isEmpty(pushTemplateList)) {
            log.error("没有查到可用的消息模版，param:{}", commonMessage);
            return;
        }
        HashMap hashMap = JsonUtils.json2obj(JsonUtils.obj2json(commonMessage), HashMap.class);
        //  check is repeat and filter
        PushTemplatePo pushTemplatePo = pushTemplateList.get(0);
        if (pushTemplatePo.getIsRepeat() == 0) {// 不可重复
            int count = messageRecordDao.queryMessageCount(Integer.parseInt(hashMap.get("userId").toString()),Integer.parseInt(hashMap.get("orderId").toString()),triggerNodeName);
            if (count > 0) {// 已存在
                log.info("该类型消息已处理，param:{}", commonMessage);
                return;
            }
        }

        try {
            //  封装数据
            List<MessageRecordPo> messageRecordPoList = process(commonMessage, pushTemplateList);
            assembleTagsAndAlias(messageRecordPoList, pushTemplateList.get(0), hashMap);

            //  发送消息
            assembleAndSendJPushMessage(messageRecordPoList, pushTemplateList);

            //  batch add PushRecord
            messageRecordDao.batchSaveMessageRecord(messageRecordPoList);
        } catch (Exception e) {
            log.error("MessagePushHandle Exception! commonMessage:{}, Exception:{}", commonMessage, e);
        }
    }


    private void assembleTagsAndAlias(List<MessageRecordPo> messageRecordPoList, PushTemplatePo pushTemplatePo, HashMap hashMap) {
        // tags、alias模版中有就以模版中为准，没有就查询
        String tags = appPushCommonNacosCofig.getApp_push_version();
        if (StringUtils.isBlank(tags)) {
            List<AppVersionDto> versionDtoList = appVersionProxy.queryRecordListByMinVersion(appPushCommonNacosCofig.getApp_push_min_version(), Lists.newArrayList("washriwvd8c6r6nz","eax4kpvv3nsuk837"));
            if (!CollectionUtils.isEmpty(versionDtoList)) {
                Set<String> versionSet = versionDtoList.parallelStream().map(versionDto -> versionDto.getVersion()).collect(Collectors.toSet());
                tags = versionSet.stream().collect(Collectors.joining(","));
            }
        }

        for (MessageRecordPo messageRecordPo : messageRecordPoList) {
            messageRecordPo.setUserId(Integer.parseInt(hashMap.get("userId").toString()));
            messageRecordPo.setTags(tags);
            if(hashMap.get("orderId")!=null){
                messageRecordPo.setOrderId(Integer.parseInt(hashMap.get("orderId").toString()));
            }

            if (StringUtils.isBlank(pushTemplatePo.getAlias()) && StringUtils.isNotBlank(hashMap.get("mobile").toString())) {
                messageRecordPo.setAlias(hashMap.get("mobile").toString());
            }
            checkSaveMessageRecordNull(messageRecordPo);
        }
    }

    private void checkSaveMessageRecordNull(MessageRecordPo messageRecordPo) {
        if (null == messageRecordPo.getUserId()) {
            messageRecordPo.setUserId(0);
        }
        if (null == messageRecordPo.getOrderId()) {
            messageRecordPo.setOrderId(0);
        }
        if (null == messageRecordPo.getPlatform()) {
            messageRecordPo.setPlatform("");
        }
        if (null == messageRecordPo.getPushTarget()) {
            messageRecordPo.setPushTarget("");
        }
        if (null == messageRecordPo.getTags()) {
            messageRecordPo.setTags("");
        }
        if (null == messageRecordPo.getAlias()) {
            messageRecordPo.setAlias("");
        }
        if (null == messageRecordPo.getPushType()) {
            messageRecordPo.setPushType("");
        }
        if (null == messageRecordPo.getTitle()) {
            messageRecordPo.setTitle("");
        }
        if (null == messageRecordPo.getSubTitle()) {
            messageRecordPo.setSubTitle("");
        }
        if (null == messageRecordPo.getContent()) {
            messageRecordPo.setContent("");
        }
        if (null == messageRecordPo.getSubContent()) {
            messageRecordPo.setSubContent("");
        }
        if (null == messageRecordPo.getCardImgs()) {
            messageRecordPo.setCardImgs("");
        }
        if (null == messageRecordPo.getOpenUrl()) {
            messageRecordPo.setOpenUrl("");
        }
        if (null == messageRecordPo.getErrorMsg()) {
            messageRecordPo.setErrorMsg("");
        }
        if (null == messageRecordPo.getPushTime()) {
            messageRecordPo.setPushTime(new Date());
        }
    }

    private void assembleAndSendJPushMessage(List<MessageRecordPo> messageRecordList, List<PushTemplatePo> pushTemplateList) {
        Map<Integer, PushTemplatePo> pushTemplatePoMap = pushTemplateList.parallelStream().collect(Collectors.toMap(PushTemplatePo::getMessageNum, pushTemplatePo -> pushTemplatePo));

        for (MessageRecordPo messageRecord : messageRecordList) {
            SendJPushMessage jPushMessage = new SendJPushMessage();
            PushTemplatePo pushTemplatePo = pushTemplatePoMap.get(messageRecord.getMessageNum());
            if ("MESSAGE".equals(pushTemplatePo.getPushType())) {
                jPushMessage.setDiyMsg(true);
            } else {
                jPushMessage.setDiyMsg(false);
            }
            jPushMessage.setMsgTitle("");
            jPushMessage.setMsgContent("");
            jPushMessage.setMessageType(MessageType.JPUSH);

            TargetClients targetClients = new TargetClients();
            String mobile = messageRecordList.get(0).getAlias();
            String version = messageRecordList.get(0).getTags();
            if (StringUtils.isBlank(version)) {// 版本号为空不推送
                continue;
            }
            if (StringUtils.isBlank(mobile)) {// 手机号为空不推送
                continue;
            }
            version = version.replace(".", "_");
            targetClients.setAlias(new HashSet<>(Arrays.asList(mobile.split(","))));
            // 版本号可能会重复，此处去重
            targetClients.setTag(new HashSet<>(Arrays.asList(version.split(","))));
            jPushMessage.setTargetClients(targetClients);
            jPushMessage.setPlatform(Sets.newHashSet(PhoneOS.ALL));
            jPushMessage.setReceiveTime(System.currentTimeMillis());
            jPushMessage.setMessageStatus(MessageStatus.RECEIVED.getValue());

            JPushExtra pushExtra = assembleJPushExtra(messageRecord, pushTemplatePo.getRefreshType());
            jPushMessage.setExtra(pushExtra);

            pushMessage(jPushMessage);
        }
    }

    private JPushExtra assembleJPushExtra(MessageRecordPo messageRecord, int refreshType) {
        JPushExtra pushExtra = new JPushExtra();
        pushExtra.setMsgType(27);
        pushExtra.setCreateTime(System.currentTimeMillis());// 发送时间
        pushExtra.setUnReadCount(0);// 未读数加1
        pushExtra.setSaveInMsgCenter(1);// 是否是消息组 :1是0否
        pushExtra.setMsgTitle(messageRecord.getTitle());// 消息标题
        pushExtra.setMessageGroupStatus(0);// 是否需要消息分组 :1是0否
        pushExtra.setOpenPage(messageRecord.getOpenUrl());
        pushExtra.setMsgImg(messageRecord.getImg());//消息图标

        FeedMessageDto feedMessageDto = new FeedMessageDto();
        List<MessageCardInfoDto> feedMessage = new ArrayList<>(1);
        Date date = new Date();

        MessageCardInfoDto messageCardInfoDto = new MessageCardInfoDto();
        messageCardInfoDto.setCardType(messageRecord.getCardType())
                .setContent(messageRecord.getContent())
                .setSubContent(messageRecord.getSubContent())
                .setTitle(messageRecord.getTitle())
                .setSubTitle(messageRecord.getSubTitle())
                .setHasRead(0)
                .setIsPushTop(messageRecord.getIsPushTop())
                .setOpenUrl(messageRecord.getOpenUrl())
                .setImgList(Arrays.asList(messageRecord.getCardImgs().split(",")))
                .setPushTime(date)
                .setCreateTime(date)
                .setUpdateTime(date)
                .setMessageNum(messageRecord.getMessageNum());
        feedMessage.add(messageCardInfoDto);

        if (messageRecord.getOrderId() != null) {
            feedMessageDto.setOrderId(messageRecord.getOrderId());
        }
        feedMessageDto.setRefreshType(refreshType).setFeedMessage(feedMessage);
        pushExtra.setMsgContent(JsonUtils.obj2json(feedMessageDto));//消息内容

        return pushExtra;
    }


    // mq 推送消息
    private int pushMessage(BaseMessage baseMessage) {
        try {
            baseMessage.setSource(MessageSource.O2O);
            rocketMQTemplate.syncSend(MessageQueueName.RECEIVE_MESSAGE_PREFIX + baseMessage.getMessageType().getValue(), baseMessage);
        } catch (Exception e) {
            log.error("send message by mq exception {}", e.getMessage(), e);
            return 0;
        }
        log.info("send message by mq params:{}", JsonUtils.obj2json(baseMessage));
        return 1;
    }

}
