package com.ihomefnt.push.domain.po;

import lombok.Data;

import java.util.Date;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-25 11:41
 */
@Data
public class DataPresetPo {

    private int id;

    private Integer userId; //用户id

    private Integer orderId; //订单id

    private Integer taskId;//任务Id

    private Integer orderStatus;//订单状态

    private Integer orderSubstatus;//订单子状态

    private Date registerTime;//用户注册时间

    private Date buildingTime;//首次维护房产时间

    private Date firstFundTime;// 首次缴纳定金时间

    private Date finalFundTime;// 最终结清款项时间

    private Date finalTime;//订单完成时间,终验评价完成时间

    private Date solutionTime;// 最新提交签约方案时间

    private Date taskTime;// 首次提交设计需求时间

    private Integer loanId;// 爱家贷
    private Integer gradeId;//等级Id
    private Integer status;// 处理状态 ： 0待处理 ， 1已处理

    private Integer layoutId;// 户型id

    private Integer loanSolutionId;// 申请爱家贷专用方案id

    private Integer buildingId;// 楼盘项目id


}
