package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author wanyunxin
 * @create 2019-11-22 11:25
 */
@Data
public class SolutionDetailResponseDto {

    @ApiModelProperty("方案id")
    private Integer solutionId;// 方案id

    @ApiModelProperty("方案名称")
    private String solutionName;// 方案名称

}
