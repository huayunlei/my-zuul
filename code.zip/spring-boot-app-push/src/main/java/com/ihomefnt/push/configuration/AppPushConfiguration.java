package com.ihomefnt.push.configuration;

import com.ihomefnt.common.util.ServiceLocator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-12 14:48
 */
@Configuration
public class AppPushConfiguration {

    @Bean(name = "serviceLocator")
    public ServiceLocator serviceLocator() {
        return ServiceLocator.init();
    }
}
