package com.ihomefnt.push.proxy;

import com.ihomefnt.common.api.ResponseVo;
import com.ihomefnt.push.common.constant.ServiceNameConstants;
import com.ihomefnt.push.domain.dto.UserDto;
import com.ihomefnt.zeus.finder.ServiceCaller;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-18 10:15
 */
@Service
public class UserProxy {

    @Resource
    private ServiceCaller serviceCaller;

    public UserDto getUserById(Integer id) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("userId", id);
        ResponseVo<UserDto> response = serviceCaller.post(ServiceNameConstants.GET_USER_BY_ID, params,
                new TypeReference<ResponseVo<UserDto>>() {
                });

        if (null != response && response.isSuccess()) {
            return response.getData();
        }
        return null;
    }
}
