package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author xiamingyu
 * @date 2018/7/18
 */
@Data
@ApiModel("户型方案效果返回")
public class SolutionEffectResponse implements Serializable{

    @ApiModelProperty("空间标识图")//若不存在，取户型图
    private String houseTypeImage;

    @ApiModelProperty("方案列表")
    private List<SolutionEffectInfo> solutionEffectInfoList;

    @ApiModelProperty("是否有待分配、待确认、设计中的任务")
    private Boolean hasTask;
}
