package com.ihomefnt.push.common.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by onefish on 2016/12/9 0009.
 */
@Component
public class MessageQueueName {

    public static String RECEIVE_MESSAGE_PREFIX;
    
    @Value("${push.receive.message.prefix}")
    public void setReceiveMessagePrefix(String prefix) {
        MessageQueueName.RECEIVE_MESSAGE_PREFIX = prefix;
    }



}
