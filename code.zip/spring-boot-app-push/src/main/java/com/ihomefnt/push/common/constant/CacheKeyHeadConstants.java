package com.ihomefnt.push.common.constant;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-28 15:11
 */
public interface CacheKeyHeadConstants {

    String PUSH_TEMPLATE = "push_template:";
}
