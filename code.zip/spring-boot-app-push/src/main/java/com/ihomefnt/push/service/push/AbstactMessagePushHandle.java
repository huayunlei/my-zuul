package com.ihomefnt.push.service.push;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.common.util.ServiceLocator;
import com.ihomefnt.push.common.constans.MessageStatus;
import com.ihomefnt.push.configuration.AppPushCommonNacosCofig;
import com.ihomefnt.push.dao.MessageRecordDao;
import com.ihomefnt.push.dao.OriginalMessageDao;
import com.ihomefnt.push.domain.dto.*;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.OriginalMessagePo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.dto.SendJPushMessage;
import com.ihomefnt.push.po.MessageSource;
import com.ihomefnt.push.po.MessageType;
import com.ihomefnt.push.po.jpush.JPushExtra;
import com.ihomefnt.push.po.jpush.PhoneOS;
import com.ihomefnt.push.po.jpush.TargetClients;
import com.ihomefnt.push.proxy.AladdinOrderProxy;
import com.ihomefnt.push.proxy.AppVersionProxy;
import com.ihomefnt.push.service.cache.PushTemplateCacheService;
import com.ihomefnt.push.service.message.MqMessagePushService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:消息推送处理抽象模版
 * @Author hua
 * @Date 2019-11-11 14:16
 */
@Slf4j
public abstract class AbstactMessagePushHandle {

    private MqMessagePushService mqMessagePushService;
    private MessageRecordDao messageRecordDao;
    private OriginalMessageDao originalMessageDao;
    private AppVersionProxy appVersionProxy;
    private PushTemplateCacheService pushTemplateCacheService;
    private AppPushCommonNacosCofig appPushCommonNacosCofig;
    @Autowired
    private AladdinOrderProxy aladdinOrderProxy;

    private volatile boolean isInited = false;

    public AbstactMessagePushHandle () {
    }

    private synchronized void init() {
        if (isInited) {
            return;
        }
        this.mqMessagePushService = (MqMessagePushService) ServiceLocator.init().getService(MqMessagePushService.class);
        this.messageRecordDao = (MessageRecordDao) ServiceLocator.init().getService(MessageRecordDao.class);
        this.originalMessageDao = (OriginalMessageDao) ServiceLocator.init().getService(OriginalMessageDao.class);
        this.appVersionProxy = (AppVersionProxy) ServiceLocator.init().getService(AppVersionProxy.class);
        this.pushTemplateCacheService = (PushTemplateCacheService)ServiceLocator.init().getService(PushTemplateCacheService.class);
        this.appPushCommonNacosCofig = (AppPushCommonNacosCofig)ServiceLocator.init().getService(AppPushCommonNacosCofig.class);

        this.isInited = true;
    }

    // 消息资源查询
    protected abstract List<MessageRecordPo> process(ReceiveBaseMessage receiveBaseMessage, List<PushTemplatePo> pushTemplateList);

    public void handle(ReceiveBaseMessage receiveBaseMessage, UserDto userDto) {
        if (!isInited) {
            init();
        }
        ReceiveBaseMessage.MessageInfo messageInfo = receiveBaseMessage.getMessageInfo();
        if (messageInfo == null || !checkUserIdAndOrderId(messageInfo)) {
            log.error(" userId and orderId 不能同时为空， param:{}", receiveBaseMessage);
            return;
        }
        Integer version=messageInfo.getRightsVersion()==null?1:messageInfo.getRightsVersion()==4?2:1;
        if(receiveBaseMessage.getTriggerNodeName()!=null
                &&("upgradeOrderRight".equals(receiveBaseMessage.getTriggerNodeName())||//权益升级
                "completeFinalCheck".equals(receiveBaseMessage.getTriggerNodeName()))){//用户点评验收完成
            Integer rightVersion = getRightVersion(messageInfo.getOrderId());
            version=rightVersion==4?2:1;
        }

        List<PushTemplatePo> pushTemplateList = pushTemplateCacheService.getByTriggerNodeName(receiveBaseMessage.getTriggerNodeName(),version);
        if (CollectionUtils.isEmpty(pushTemplateList)) {
            log.error("没有查到可用的消息模版，param:{}", receiveBaseMessage);
            return;
        }

        //  check is repeat and filter
        PushTemplatePo pushTemplatePo = pushTemplateList.get(0);
        if (pushTemplatePo.getIsRepeat() == 0) {// 不可重复
            int count = messageRecordDao.queryMessageCount(userDto.getId(),messageInfo.getOrderId(),receiveBaseMessage.getTriggerNodeName());
            if (count > 0) {// 已存在
                log.info("该类型消息已处理，param:{}", receiveBaseMessage);
                return;
            }
        }

        //  save OriginalMessagePo
        int originalMessageId = saveOriginalMessagePo(receiveBaseMessage);

        try {
            //  封装数据
            List<MessageRecordPo> messageRecordPoList = process(receiveBaseMessage, pushTemplateList);
            assembleTagsAndAlias(messageRecordPoList, pushTemplateList.get(0), userDto);

            //  发送消息
            assembleAndSendJPushMessage(messageRecordPoList, pushTemplateList);

            //  batch add PushRecord
            messageRecordDao.batchSaveMessageRecord(messageRecordPoList);

            //  更新 OriginalMessagePo状态为已推送
            originalMessageDao.updateOriginalMessageStatusById(originalMessageId, 1);
        } catch (Exception e) {
            log.error("MessagePushHandle Exception! receiveBaseMessage:{}, Exception:{}", receiveBaseMessage, e);
        }
    }

    /**
     * 获取权益版本
     *
     * @param orderNum
     * @return
     */
    private Integer getRightVersion(Integer orderNum) {
        if (orderNum == null) {
            return 2;
        }
        GradeVersionDto gradeVersionDto = aladdinOrderProxy.queryCurrentVersion(orderNum);
        if (gradeVersionDto != null) {
            return gradeVersionDto.getVersion();
        }
        return 1;
    }

    private boolean checkUserIdAndOrderId(ReceiveBaseMessage.MessageInfo messageInfo) {
        if (null == messageInfo) {
            return false;
        }
        if ((messageInfo.getUserId() == null || messageInfo.getUserId() <= 0)
            && (messageInfo.getOrderId() == null || messageInfo.getOrderId() <= 0)) {
            return false;
        }

        return true;
    }

    private void assembleTagsAndAlias(List<MessageRecordPo> messageRecordPoList, PushTemplatePo pushTemplatePo, UserDto userDto) {
        // tags、alias模版中有就以模版中为准，没有就查询
        String tags = appPushCommonNacosCofig.getApp_push_version();
        if (StringUtils.isBlank(tags)) {
            List<AppVersionDto> versionDtoList = appVersionProxy.queryRecordListByMinVersion(appPushCommonNacosCofig.getApp_push_min_version(), Lists.newArrayList("washriwvd8c6r6nz","eax4kpvv3nsuk837"));
            if (!CollectionUtils.isEmpty(versionDtoList)) {
                Set<String> versionSet = versionDtoList.parallelStream().map(versionDto -> versionDto.getVersion()).collect(Collectors.toSet());
                tags = versionSet.stream().collect(Collectors.joining(","));
            }
        }

        for (MessageRecordPo messageRecordPo : messageRecordPoList) {
            messageRecordPo.setUserId(userDto.getId());
            messageRecordPo.setTags(tags);

            if (StringUtils.isBlank(pushTemplatePo.getAlias()) && StringUtils.isNotBlank(userDto.getMobile())) {
                messageRecordPo.setAlias(userDto.getMobile());
            }

            mqMessagePushService.checkSaveMessageRecordNull(messageRecordPo);
        }
    }

    private void assembleAndSendJPushMessage(List<MessageRecordPo> messageRecordList, List<PushTemplatePo> pushTemplateList) {
        Map<Integer, PushTemplatePo> pushTemplatePoMap = pushTemplateList.parallelStream().collect(Collectors.toMap(PushTemplatePo::getMessageNum, pushTemplatePo -> pushTemplatePo));

        for (MessageRecordPo messageRecord : messageRecordList) {
            SendJPushMessage jPushMessage = new SendJPushMessage();
            PushTemplatePo pushTemplatePo = pushTemplatePoMap.get(messageRecord.getMessageNum());
            if ("MESSAGE".equals(pushTemplatePo.getPushType())) {
                jPushMessage.setDiyMsg(true);
            } else {
                jPushMessage.setDiyMsg(false);
            }
            jPushMessage.setMsgTitle("");
            jPushMessage.setMsgContent("");
            jPushMessage.setMessageType(MessageType.JPUSH);

            TargetClients targetClients = new TargetClients();
            String mobile = messageRecordList.get(0).getAlias();
            String version = messageRecordList.get(0).getTags();
            if (StringUtils.isBlank(version)) {// 版本号为空不推送
                continue;
            }
            if (StringUtils.isBlank(mobile)) {// 手机号为空不推送
                continue;
            }
            version = version.replace(".", "_");
            targetClients.setAlias(new HashSet<>(Arrays.asList(mobile.split(","))));
            // 版本号可能会重复，此处去重
            targetClients.setTag(new HashSet<>(Arrays.asList(version.split(","))));
            jPushMessage.setTargetClients(targetClients);

            jPushMessage.setPlatform(Sets.newHashSet(PhoneOS.ALL));
            jPushMessage.setReceiveTime(System.currentTimeMillis());
            jPushMessage.setMessageStatus(MessageStatus.RECEIVED.getValue());

            JPushExtra pushExtra = assembleJPushExtra(messageRecord, pushTemplatePo.getRefreshType());
            jPushMessage.setExtra(pushExtra);

            mqMessagePushService.pushMessage(jPushMessage);
        }
    }

    private JPushExtra assembleJPushExtra(MessageRecordPo messageRecord, int refreshType) {
        JPushExtra pushExtra = new JPushExtra();
        pushExtra.setMsgType(27);
        pushExtra.setCreateTime(System.currentTimeMillis());// 发送时间
        pushExtra.setUnReadCount(0);// 未读数加1
        pushExtra.setSaveInMsgCenter(1);// 是否是消息组 :1是0否
        pushExtra.setMsgTitle(messageRecord.getTitle());// 消息标题
        pushExtra.setMessageGroupStatus(0);// 是否需要消息分组 :1是0否
        pushExtra.setOpenPage(messageRecord.getOpenUrl());
        pushExtra.setMsgImg(messageRecord.getImg());//消息图标

        FeedMessageDto feedMessageDto = new FeedMessageDto();
        List<MessageCardInfoDto> feedMessage = new ArrayList<>(1);
        Date date = new Date();

        MessageCardInfoDto messageCardInfoDto = new MessageCardInfoDto();
        messageCardInfoDto.setCardType(messageRecord.getCardType())
                .setContent(messageRecord.getContent())
                .setSubContent(messageRecord.getSubContent())
                .setTitle(messageRecord.getTitle())
                .setSubTitle(messageRecord.getSubTitle())
                .setHasRead(0)
                .setIsPushTop(messageRecord.getIsPushTop())
                .setOpenUrl(messageRecord.getOpenUrl())
                .setImgList(Arrays.asList(messageRecord.getCardImgs().split(",")))
                .setPushTime(date)
                .setCreateTime(date)
                .setUpdateTime(date)
                .setMessageNum(messageRecord.getMessageNum());
        feedMessage.add(messageCardInfoDto);

        if (messageRecord.getOrderId() != null) {
            feedMessageDto.setOrderId(messageRecord.getOrderId());
        }
        feedMessageDto.setRefreshType(refreshType).setFeedMessage(feedMessage);
        pushExtra.setMsgContent(JsonUtils.obj2json(feedMessageDto));//消息内容

        return pushExtra;
    }

    private int saveOriginalMessagePo(ReceiveBaseMessage receiveBaseMessage) {
        OriginalMessagePo originalMessagePo = new OriginalMessagePo();
        originalMessagePo.setTriggerNodeName(receiveBaseMessage.getTriggerNodeName())
                .setSource(receiveBaseMessage.getSource())
                .setMessageInfo(JsonUtils.obj2json(receiveBaseMessage.getMessageInfo()))
                .setStatus(0);
        int cnt = originalMessageDao.saveOriginalMessagePo(originalMessagePo);
        if (cnt > 0) {
            return originalMessagePo.getId();
        }
        return 0;
    }

}
