package com.ihomefnt.push.proxy;

import com.beust.jcommander.internal.Maps;
import com.ihomefnt.common.api.ResponseVo;
import com.ihomefnt.push.common.constant.ServiceNameConstants;
import com.ihomefnt.push.domain.dto.AppSolutionDesignDto;
import com.ihomefnt.push.domain.dto.BatchSolutionBaseInfoVo;
import com.ihomefnt.push.domain.dto.SolutionDetailResponseDto;
import com.ihomefnt.push.domain.dto.SolutionEffectResponse;
import com.ihomefnt.zeus.finder.ServiceCaller;
import lombok.extern.slf4j.Slf4j;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-21 15:56
 */
@Service
@Slf4j
public class DollyWebProxy {

    @Resource
    private ServiceCaller sercviceCaller;

    public List<AppSolutionDesignDto> queryDesignDemondHistory(Map<String, Object> params) {
        ResponseVo<List<AppSolutionDesignDto>> responseVo = null;
        try {
            responseVo = sercviceCaller.post(ServiceNameConstants.QUERY_DESIGN_DEMOND_HISTORY, params,
                    new TypeReference<ResponseVo<List<AppSolutionDesignDto>>>() {
                    });
        } catch (Exception e) {
            log.error("DollyWebProxy.queryDesignDemondHistory", e);
            return null;
        }
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return responseVo.getData();
        }
        return null;
    }

    public AppSolutionDesignDto queryDesignDemond(Integer orderId) {
        ResponseVo<AppSolutionDesignDto> responseVo = null;
        try {
            responseVo = sercviceCaller.post(ServiceNameConstants.QUERY_DESIGN_DEMOND, Maps.newHashMap("orderNum", orderId),
                    new TypeReference<ResponseVo<AppSolutionDesignDto>>() {
                    });
        } catch (Exception e) {
            log.error("DollyWebProxy.queryDesignDemond", e);
            return null;
        }
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return responseVo.getData();
        }
        return null;
    }


    public SolutionDetailResponseDto getProgramDetailById(Integer solutionId) {
        ResponseVo<SolutionDetailResponseDto> responseVo = null;
        try {
            responseVo = sercviceCaller.post("dolly-web.solution-app.querySolutionDetailWithId", solutionId,
                    new TypeReference<ResponseVo<SolutionDetailResponseDto>>() {
                    });
        } catch (Exception e) {
            log.error("DollyWebProxy.getProgramDetailById", e);
            return null;
        }
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return responseVo.getData();
        }
        return null;
    }


    /**
     * 批量查询方案信息
     *
     * @param solutionIdList
     * @return
     */
    public BatchSolutionBaseInfoVo batchQuerySolutionBaseInfo(List<Integer> solutionIdList) {
        ResponseVo<BatchSolutionBaseInfoVo> responseVo = null;
        try {
            responseVo = sercviceCaller.post(ServiceNameConstants.BATCH_QUERY_SOLUTION_BASEINFO, Maps.newHashMap("solutionIdList", solutionIdList),
                    new TypeReference<ResponseVo<BatchSolutionBaseInfoVo>>() {
                    });
        } catch (Exception e) {
            log.error("DollyWebProxy.batchQuerySolutionBaseInfo", e);
            return null;
        }
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return responseVo.getData();
        }
        return null;

    }

    public SolutionEffectResponse querySolutionList(Integer layoutId, Integer orderId) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("apartmentId", layoutId);
        params.put("orderNum", orderId);
        ResponseVo<SolutionEffectResponse> responseVo = null;
        try {
            responseVo = sercviceCaller.post(ServiceNameConstants.QUERY_SOLUTION_LIST, params,
                    new TypeReference<ResponseVo<SolutionEffectResponse>>() {
                    });
        } catch (Exception e) {
            log.error("DollyWebProxy.querySolutionList", e);
            return null;
        }
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return responseVo.getData();
        }
        return null;
    }

    public Integer queryAvailableSolutionCount(Integer layoutId, Integer orderId, Integer buildingId) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("houseTypeId", layoutId);
        params.put("orderNum", orderId);
        params.put("houseProjectId", buildingId);

        ResponseVo<Integer> responseVo = sercviceCaller.post(ServiceNameConstants.QUERY_AVAILABLE_SOLUTION_COUNT, params,
                new TypeReference<ResponseVo<Integer>>() {
                });
        if (responseVo != null && responseVo.isSuccess() && responseVo.getData() != null) {
            return responseVo.getData();
        }
        return null;
    }

}
