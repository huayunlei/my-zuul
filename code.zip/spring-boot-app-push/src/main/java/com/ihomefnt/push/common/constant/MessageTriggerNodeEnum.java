package com.ihomefnt.push.common.constant;

/**
 * @Description:消息节点名称
 * @Author hua
 * @Date 2019-11-15 11:28
 */
public enum MessageTriggerNodeEnum {
    unLoginUser("unLoginUser", 1),
    addNewUser("addNewUser", 1),
    addHouseProperty("addHouseProperty", 1),
    payEarnestMoney("payEarnestMoney", 1),

    sendOfflineDraw("sendOfflineDraw", 1),
    completeOfflineDraw("completeOfflineDraw",1),


    createLoanAijia("createLoanAijia", 3),
    cancelScheme("cancelScheme", 2),
    approvalFastCheck("approvalFastCheck", 2),
    confirmRequriement("confirmRequriement", 2)

    ;

    private String name;
    // 1 正常全流程，2 只记原信息，刷新核心区 3 只记原信息
    private int type;

    MessageTriggerNodeEnum(String name, int type) {
        this.name = name;
        this.type = type;
    }

    public static int getMessageTriggerType (String name) {
        for (MessageTriggerNodeEnum nodeEnum : MessageTriggerNodeEnum.values()) {
            if (nodeEnum.name.equals(name)) {
                return nodeEnum.type;
            }
        }
        return 1;
    }
}
