package com.ihomefnt.push.service.message;

import com.ihomefnt.common.util.ModelMapperUtil;
import com.ihomefnt.push.common.constant.CacheKeyHeadConstants;
import com.ihomefnt.push.common.constant.LifeArticleHeadImgsData;
import com.ihomefnt.push.common.constant.MessageTriggerNodeEnum;
import com.ihomefnt.push.dao.MessageRecordDao;
import com.ihomefnt.push.dao.PushTemplateDao;
import com.ihomefnt.push.domain.dto.MessageCardInfoDto;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.domain.vo.DeleteOfflineDrawMessageRequestVo;
import com.ihomefnt.push.domain.vo.MessageRecordFlowResponseVo;
import com.ihomefnt.push.domain.vo.QueryMessageRecordFlowRequestVo;
import com.ihomefnt.redis.GracefulRedisTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-20 19:26
 */
@Service
@Slf4j
public class MessageRecordService {
    @Autowired
    private MessageRecordDao  messageRecordDao;
    @Autowired
    private PushTemplateDao pushTemplateDao;
    @Resource
    private GracefulRedisTemplate gracefulRedisTemplate;

    public MessageRecordFlowResponseVo queryMessageRecordFlow(QueryMessageRecordFlowRequestVo request) {
        int from = (request.getPageNo() - 1) * request.getPageSize();
        int count = messageRecordDao.countMessageRecordFlow(request.getUserId(), request.getOrderId(), from, request.getPageSize());
        MessageRecordFlowResponseVo responseVo = new MessageRecordFlowResponseVo();
        if (count == 0) {
            responseVo.setFeedMessage(null).setTotalCount(count);
            return responseVo;
        }

        List<MessageRecordPo> recordPoList = messageRecordDao.queryMessageRecordFlow(request.getUserId(), request.getOrderId(), from, request.getPageSize());
        if (CollectionUtils.isEmpty(recordPoList)) {
            return null;
        }

        List<MessageCardInfoDto> messageRecordFlowList = ModelMapperUtil.strictMapList(recordPoList, MessageCardInfoDto.class);
        messageRecordFlowList.parallelStream().forEach(item -> {
            if (StringUtils.isNotBlank(item.getCardImgs())) {
                item.setImgList(Arrays.asList(item.getCardImgs().split(",")));
            }
        });
        responseVo.setFeedMessage(messageRecordFlowList).setTotalCount(count);
        return responseVo;
    }

    public MessageRecordFlowResponseVo queryMessageRecordsByTemplate(String triggerNodeName) {
        String key = CacheKeyHeadConstants.PUSH_TEMPLATE+triggerNodeName+1;
        List<PushTemplatePo> pushTemplatePoList = gracefulRedisTemplate.getList(key, PushTemplatePo.class);
        if (org.springframework.util.CollectionUtils.isEmpty(pushTemplatePoList)) {
            pushTemplatePoList = pushTemplateDao.queryByTriggerNodeName(triggerNodeName,1);
        }
        if (CollectionUtils.isEmpty(pushTemplatePoList)) {
            return null;
        }
        gracefulRedisTemplate.setEx(key, pushTemplatePoList, 3600);

        MessageRecordFlowResponseVo responseVo = new MessageRecordFlowResponseVo();
        List<MessageCardInfoDto> messageRecordFlowList = ModelMapperUtil.strictMapList(pushTemplatePoList, MessageCardInfoDto.class);
        messageRecordFlowList.parallelStream().forEach(item -> {
            if (StringUtils.isNotBlank(item.getCardImgs())) {
                item.setImgList(Arrays.asList(item.getCardImgs().split(",")));
            }
            // 首席交付官
            if (3 == item.getMessageNum() && StringUtils.isBlank(item.getCardImgs())) {
                item.setCardImgs(LifeArticleHeadImgsData.getCompressImgs(item.getCardType(), 5));
                item.setImgList(Arrays.asList(item.getCardImgs().split(",")));
            }
        });
        responseVo.setFeedMessage(messageRecordFlowList).setTotalCount(messageRecordFlowList.size());
        return responseVo;
    }

    public void deleteOfflineDrawMessage(DeleteOfflineDrawMessageRequestVo request) {
        List<MessageRecordPo> sendOfflineDrawList = messageRecordDao.queryMessageRecordByNode(request.getUserId(), request.getOrderId(), MessageTriggerNodeEnum.sendOfflineDraw.name());
        List<MessageRecordPo> completeOfflineDrawList = messageRecordDao.queryMessageRecordByNode(request.getUserId(), request.getOrderId(), MessageTriggerNodeEnum.completeOfflineDraw.name());

        List<Integer> isList = new ArrayList<>();
        if (null != sendOfflineDrawList) {
            for (MessageRecordPo item : sendOfflineDrawList) {
                String openUrl = item.getOpenUrl();
                if (StringUtils.isNotEmpty(openUrl)) {
                    String draftProfileNum = openUrl.substring(openUrl.lastIndexOf("draftProfileNum=")+16);
                    if (request.getDraftProfileNum().toString().equals(draftProfileNum)) {
                        isList.add(item.getId());
                    }
                }
            }
        }
        if (null != completeOfflineDrawList) {
            for (MessageRecordPo item : completeOfflineDrawList) {
                String openUrl = item.getOpenUrl();
                if (StringUtils.isNotEmpty(openUrl)) {
                    String draftProfileNum = openUrl.substring(openUrl.lastIndexOf("draftProfileNum=")+16);
                    if (request.getDraftProfileNum().toString().equals(draftProfileNum)) {
                        isList.add(item.getId());
                    }
                }
            }
        }

        if (CollectionUtils.isNotEmpty(isList)) {
            messageRecordDao.deleteMessageRecordByIds(isList);
        }
    }

}
