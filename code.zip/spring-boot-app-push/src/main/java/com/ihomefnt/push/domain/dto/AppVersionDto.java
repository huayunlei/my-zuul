package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-18 09:17
 */
@Data
@ApiModel("AppVersionDto")
public class AppVersionDto {

    @ApiModelProperty("主键")
    private Long vId;

    @ApiModelProperty("应用唯一码")
    private String appId;

    @ApiModelProperty("版本号")
    private String version;

    @ApiModelProperty("版本描述（版本号百进制转换为int）")
    private Integer versionComment;

    @ApiModelProperty("渠道编号")
    private String partnerValue = "0";

    @ApiModelProperty("下载地址")
    private String download;

    @ApiModelProperty("更新描述")
    private String updateContent;

    @ApiModelProperty("app类型")
    private Integer type;

    @ApiModelProperty("添加人")
    private Integer opUid;

    @ApiModelProperty("强更标记")
    private Integer updateFlag;

    @ApiModelProperty("删除标记位")
    private Integer delFlag;

    @ApiModelProperty("基础运行环境")
    private Integer baseAppVersion;

    @ApiModelProperty("上架标记 0 未上架 1已上架")
    private Integer putAwayState;

}
