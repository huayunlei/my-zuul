package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Map;

/**
 * 个人经纪人MQ消息数据
 */
@Data
@ApiModel("推送请求参数")
public class PersonalAgentMessage implements Serializable {


    private static final long serialVersionUID = -3688871385435624698L;

    @ApiModelProperty("用户id")
    @NotNull(message="消息来源不能为空")
    private Integer userId;

    @ApiModelProperty("手机号")
    @NotNull(message="消息节点名称不能为空")
    private String mobile;

    @ApiModelProperty("订单号")
    @NotNull(message="消息节点名称不能为空")
    private Long orderId;


}
