package com.ihomefnt.push.dao;

import com.ihomefnt.push.domain.po.TempOrderDeliveryPo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2020/2/11 7:30 下午
 */
@Repository
public interface TempOrderDeliveryDao {

    int countTempOrderDeliveryRecords();

    List<TempOrderDeliveryPo> queryTempOrderDeliveryRecordsPage(@Param("from") int from, @Param("pageSize") int pageSize);

    int updateById(int id);

    void batchUpdateByIds(List<Integer> list);


}
