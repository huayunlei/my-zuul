package com.ihomefnt.push.service.message;

import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.message.RocketMQTemplate;
import com.ihomefnt.push.common.constant.MessageQueueName;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.dto.BaseMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @Description:
 * @Author hua
 * @Date 2020/3/13 3:03 下午
 */
@Service
@Slf4j
public class MqMessagePushService {
    @Resource
    private RocketMQTemplate rocketMQTemplate;

    // mq 推送消息
    public int pushMessage(BaseMessage baseMessage) {
        try {
            rocketMQTemplate.syncSend(MessageQueueName.RECEIVE_MESSAGE_PREFIX + baseMessage.getMessageType().getValue(), baseMessage);
        } catch (Exception e) {
            log.error("send message by mq exception {}", e.getMessage(), e);
            return 0;
        }
        log.info("send message by mq params:{}", JsonUtils.obj2json(baseMessage));
        return 1;
    }

    public void checkSaveMessageRecordNull(MessageRecordPo messageRecordPo) {
        if (null == messageRecordPo.getUserId()) {
            messageRecordPo.setUserId(0);
        }
        if (null == messageRecordPo.getOrderId()) {
            messageRecordPo.setOrderId(0);
        }
        if (null == messageRecordPo.getPlatform()) {
            messageRecordPo.setPlatform("");
        }
        if (null == messageRecordPo.getPushTarget()) {
            messageRecordPo.setPushTarget("");
        }
        if (null == messageRecordPo.getTags()) {
            messageRecordPo.setTags("");
        }
        if (null == messageRecordPo.getAlias()) {
            messageRecordPo.setAlias("");
        }
        if (null == messageRecordPo.getPushType()) {
            messageRecordPo.setPushType("");
        }
        if (null == messageRecordPo.getTitle()) {
            messageRecordPo.setTitle("");
        }
        if (null == messageRecordPo.getSubTitle()) {
            messageRecordPo.setSubTitle("");
        }
        if (null == messageRecordPo.getContent()) {
            messageRecordPo.setContent("");
        }
        if (null == messageRecordPo.getSubContent()) {
            messageRecordPo.setSubContent("");
        }
        if (null == messageRecordPo.getCardImgs()) {
            messageRecordPo.setCardImgs("");
        }
        if (null == messageRecordPo.getOpenUrl()) {
            messageRecordPo.setOpenUrl("");
        }
        if (null == messageRecordPo.getErrorMsg()) {
            messageRecordPo.setErrorMsg("");
        }
        if (null == messageRecordPo.getPushTime()) {
            messageRecordPo.setPushTime(new Date());
        }
    }
}
