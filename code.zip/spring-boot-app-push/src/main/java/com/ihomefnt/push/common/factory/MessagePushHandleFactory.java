package com.ihomefnt.push.common.factory;

import com.ihomefnt.common.util.ServiceLocator;
import com.ihomefnt.push.service.push.AbstactMessagePushHandle;
import org.apache.commons.lang3.StringUtils;

/**
 * @Description:消息推送处理 Factory
 * @Author hua
 * @Date 2019-11-11 14:33
 */
public class MessagePushHandleFactory {

    public static AbstactMessagePushHandle newMessagePushHandle(String triggerNodeName) {

        if (StringUtils.isNotBlank(triggerNodeName)) {
            return (AbstactMessagePushHandle) ServiceLocator.init().getService(triggerNodeName+"MessageHandle");
        }

        return null;

    }
}
