package com.ihomefnt.push.configuration;

import com.alibaba.nacos.api.config.annotation.NacosValue;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-07 17:23
 */
@Component
public class AppPushCommonNacosCofig {
    /*
    * 推送最小版本号
    * */
    @NacosValue(value = "${app.push.min.version}", autoRefreshed = true)
    private String app_push_min_version;

    /*
     * 推送版本号，多个版本号之间用逗号隔开
     * */
    @NacosValue(value = "${app.push.version}", autoRefreshed = true)
    private String app_push_version;

    public String getApp_push_min_version() {
        return app_push_min_version;
    }

    public String getApp_push_version() {
        return app_push_version;
    }

    public Set<String> getAppPushVersionSet() {
        if (StringUtils.isNotBlank(this.app_push_version)) {
            return Arrays.stream(this.app_push_version.split(",")).collect(Collectors.toSet());
        }
        return null;
    }
}
