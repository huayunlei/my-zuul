package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Map;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-11 11:43
 */
@Data
@ApiModel("推送请求参数")
public class ReceiveBaseMessage implements Serializable {

    @ApiModelProperty("消息来源，user-web、dolly-web")
    @NotNull(message="消息来源不能为空")
    private String source;

    @ApiModelProperty("消息节点名称（addNewUser，addHouseProperty，payEarnestMoney）")
    @NotNull(message="消息节点名称不能为空")
    private String triggerNodeName;

    @ApiModelProperty("messageInfo")
    @NotNull(message="messageInfo不能为空")
    private MessageInfo messageInfo;

    @Data
    public class MessageInfo {
        @ApiModelProperty("订单id")
        private Integer orderId;

        @ApiModelProperty("dolly设计任务ID")
        private Integer taskId;

        @ApiModelProperty("dolly方案ID")
        private Integer solutionId;

        @ApiModelProperty("用户id")
        private Integer userId;

        @ApiModelProperty("wcm设计任务草稿id")
        private String designDemandId;

        @ApiModelProperty("wcm设计任务提交记录id")
        private Integer commitRecordId;

        @ApiModelProperty("wcm方案意见草稿ID")
        private String programOpinionId;

        @ApiModelProperty("草稿编号")
        private Long draftProfileNum;

        @ApiModelProperty("硬装子阶段名称")
        private String hardSubStatusName;

        @ApiModelProperty("单推手机号")
        private String mobile;

        @ApiModelProperty("权益等级")
        private Integer rightsVersion;


        @ApiModelProperty("推送信息的替换参数")
        private Map<String, Object> replaceParams;


    }


}
