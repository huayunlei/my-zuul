package com.ihomefnt.push;

import com.alibaba.nacos.spring.context.annotation.config.NacosPropertySource;
import com.ihomefnt.starter.semporna.EnableSemporna;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableSemporna(rocketMQ = true, redis = true)
@NacosPropertySource(dataId = "app-push", autoRefreshed = true)
@MapperScan("com.ihomefnt.push.dao")
@EnableAsync
public class SpringBootAppPushApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootAppPushApplication.class, args);
    }

}

