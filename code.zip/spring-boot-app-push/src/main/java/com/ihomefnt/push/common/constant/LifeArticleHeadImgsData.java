package com.ihomefnt.push.common.constant;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:wcm生活板块文章头图
 * @Author hua
 * @Date 2019-11-24 11:08
 */
public class LifeArticleHeadImgsData {

    /**
     * 4 业主故事
     */
    private static List<String> ownerStoryImgs = new ArrayList<>(10);

    /**
     * 5首席交付官
     */
    private static List<String> chiefDeliveryOfficerImgs =  Arrays.asList(
            "https://static.ihomefnt.com/1/appImage/%E8%B6%B3%E7%90%83%E5%B0%8F%E5%B0%86.jpg",
            "https://static.ihomefnt.com/1/appImage/%E7%94%9F%E6%97%A5%E6%83%8A%E5%96%9C.jpg",
            "https://static.ihomefnt.com/1/appImage/%E5%AE%9A%E5%88%B6%E5%B9%B8%E7%A6%8F.jpg",
            "https://static.ihomefnt.com/1/appImage/%E5%9C%A3%E8%AF%9E%E7%89%B9%E8%BE%91.jpg",
            "https://static.ihomefnt.com/1/appImage/lADPD2eDJ7asSZnNAhvNAw4_782_539.jpg_720x720g.jpg",
            "https://static.ihomefnt.com/1/appImage/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20191021155726.jpg",
            "https://static.ihomefnt.com/1/appImage/BD727427-B974-4eef-826C-1FAB3790BD96.png",
            "https://static.ihomefnt.com/1/appImage/mmexport1569462029269.jpg",
            "https://common.ihomefnt.com/85f815a14757b292d08c34acd17c06ea.jpg",
            "https://common.ihomefnt.com/16466e81c09abf751f5beae882fd8f6e.png",
            "https://common.ihomefnt.com/be370ca1cc0f83c58dcb5ee9faa33d8f.jpg",
            "https://common.ihomefnt.com/c72b4412b90baf33578183673d904d50.png",
            "https://common.ihomefnt.com/a0b67b8b9a49931718856bdddcfd3bc1.png",
            "https://common.ihomefnt.com/b2d942ebca1da9918abb36233ad03a7a.jpg");
    /**
     * 3 居住指南
     */
    private static List<String> LivingGuideImgs = new ArrayList<>(20);
    /**
     * 2 家装经验
     */
    private static List<String> fitmentExperienceImgs = new ArrayList<>(20);

    static {
        ownerStoryImgs.add("https://common.ihomefnt.com/010d98263411d2c32c36db5c662ad203.jpg");
        ownerStoryImgs.add("https://common.ihomefnt.com/c922e711107b5c777223629e42dd5fe1.png");
        ownerStoryImgs.add("https://common.ihomefnt.com/bdd74ac805c7e511df1a5b8e9105110f.png");
        ownerStoryImgs.add("https://common.ihomefnt.com/66fcd6fab5583e97748436b363d26082.png");
        ownerStoryImgs.add("https://common.ihomefnt.com/aa85612ebeb29b0134b4e372cb4c0d38.png");
        ownerStoryImgs.add("https://common.ihomefnt.com/7b2c0ed808d76af0ff93c497cf20b7c3.png");
        ownerStoryImgs.add("https://common.ihomefnt.com/946a9f04f4e786804f745671d9096338.jpg");
        ownerStoryImgs.add("https://common.ihomefnt.com/078d773448044626a421cba03bd469e3.png");
        ownerStoryImgs.add("https://common.ihomefnt.com/9f2bd6415de15434d4697fd149c5da01.jpg");
        ownerStoryImgs.add("https://common.ihomefnt.com/9a980ce47db97603d904e7cdb1dbb0f6.png");

        LivingGuideImgs.add("https://common.ihomefnt.com/7d6200f5ccb2aa626d30ad848e2858e9.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/bd150aa6510ca36a9f19eacec905e8f2.png");
        LivingGuideImgs.add("https://common.ihomefnt.com/2be5de497264ba878dc9efc75f78e8f5.png");
        LivingGuideImgs.add("https://common.ihomefnt.com/10d2213318dbcb427461e092ebe3bea1.png");
        LivingGuideImgs.add("https://common.ihomefnt.com/f7531221692d83eda9130d02567999d4.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/54433a6fd8df672ceb5265186cd41896.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/2e9e211bbd19241aa234abc4215aac1c.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/0164fcd3d173bc6fd524e6c843d816c7.png");
        LivingGuideImgs.add("https://common.ihomefnt.com/1cb7e70830050592e083560f94eb999e.png");
        LivingGuideImgs.add("https://common.ihomefnt.com/6b630695a58608c826eb76e1f1745b9d.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/5564b457e54ccb6c65b77170824d41c5.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/dd1ad18fa2026dbc2185bd8d598e926c.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/084266790a8b60d04428f0173dc3a1b5.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/21ab92e96aa05283a31cec6ec5ec7f69.png");
        LivingGuideImgs.add("https://common.ihomefnt.com/82c26b5480e5b203b5c26deadf5ccd7a.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/f31200067a88bf42a8875b390d7945f8.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/67e1fcc1922d47b4022201634b792349.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/bf2e5d21e8dc660400e6079f24ac1c0c.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/4616cb0c3ec5bef38aaa3056cfbfbee3.jpg");
        LivingGuideImgs.add("https://common.ihomefnt.com/1781be65fbf3b4b035f57ec310c1083f.png");

        fitmentExperienceImgs.add("https://common.ihomefnt.com/0711fc5afbd20acc0967320966ce7a24.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/2c7befca9becd21037e8ed2e3b3f37c8.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/7161bfc388fa2b54e29b9f69e82fcbae.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/cee0a191772bbc55558f0426b28023e5.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/ba695e211c4c803a1ebe88836295559e.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/06bf85b30915ab603cd0c00c7819c48c.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/7be2bbde57020155781c54d373f638fa.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/5996acdf6f6ecae2441eb149f69b83b6.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/5a235288a830798ce7b5060ee9bd0635.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/5a6b8d4cb72ce440d00c9ddf3072d4db.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/5bcf708cc9d0adb1fec8a58dd2f5f8f2.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/11ab3c412677999509010f6f85e09dd5.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/ee20f146ca8fbe3f7f543ab11793b1fd.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/b8651d953873a08254428dd19b5d807d.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/8d865aa5fc9a4653989a18f99033b61d.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/1884bbb744006bc32492cc321a0a2bff.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/cb4c20c6165eb91b32de5f8210878a36.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/67c33cb0dea90754ff2613ef4f622170.png");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/479aa2adf3311b8b4f4f664ad1441766.jpg");
        fitmentExperienceImgs.add("https://common.ihomefnt.com/7c5f82df6139ca3ebd32c979f9390b1c.jpg");
    }

    /**
     * cardType：卡片样式：1单张大图；2三张小图；3单张小图
     * categoryId：2家装经验 3居住指南 4业主故事 5首席交付官
     */
    public static String getCompressImgs(int cardType, int categoryId) {
        int size = cardType == 2 ? 3 : 1;

        Set<Integer> totals = new HashSet<Integer>();
        while (totals.size() < size) {//获取size个
            int number = 0;
            switch (categoryId) {
                case 2:
                    number = (int) (Math.random() * fitmentExperienceImgs.size());
                    break;
                case 3:
                    number = (int) (Math.random() * LivingGuideImgs.size());
                    break;
                case 5:
                    number = (int) (Math.random() * chiefDeliveryOfficerImgs.size());
                    break;
                default:
                    number = (int) (Math.random() * ownerStoryImgs.size());
                    break;
            }
            totals.add(number);
        }

        List<String> list = new ArrayList<>(size);
        Iterator<Integer> iterator = totals.iterator();
        while (iterator.hasNext()) {
            int number = iterator.next();
            switch (categoryId){
                case 2:
                    if (cardType == 1) {
                        list.add(fitmentExperienceImgs.get(number)+"!H-MIDDLE");
                    } else {
                        list.add(fitmentExperienceImgs.get(number)+"!H-SMALL");
                    }
                    break;
                case 3:
                    if (cardType == 1) {
                        list.add(LivingGuideImgs.get(number)+"!H-MIDDLE");
                    } else {
                        list.add(LivingGuideImgs.get(number)+"!H-SMALL");
                    }
                    break;
                case 5:
                    if (cardType == 1) {
                        list.add(chiefDeliveryOfficerImgs.get(number)+"!H-MIDDLE");
                    } else {
                        list.add(chiefDeliveryOfficerImgs.get(number)+"!H-SMALL");
                    }
                    break;
                default:
                    if (cardType == 1) {
                        list.add(ownerStoryImgs.get(number)+"!H-MIDDLE");
                    } else {
                        list.add(ownerStoryImgs.get(number)+"!H-SMALL");
                    }
                    break;
            }
        }
        return list.stream().collect(Collectors.joining(","));
    }

    public static void main(String args[]) {
        System.out.println(LifeArticleHeadImgsData.getCompressImgs(2, 1));
    }

}
