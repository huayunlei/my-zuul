package com.ihomefnt.push.domain.dto;

import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-04 11:25
 */
@Data
public class OrderDraftCountGroupDto {
    private Integer orderNum;

    private Integer count;
}
