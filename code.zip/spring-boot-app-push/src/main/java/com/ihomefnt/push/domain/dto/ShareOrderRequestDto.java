package com.ihomefnt.push.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-29 16:38
 */
@Data
@AllArgsConstructor
public class ShareOrderRequestDto {

    private int page = 1;
    private int limit = 10;
    private int checkFlag = 1;

}
