package com.ihomefnt.push.service.cache;

import com.ihomefnt.push.common.constant.CacheKeyHeadConstants;
import com.ihomefnt.push.common.constant.MessageTriggerNodeEnum;
import com.ihomefnt.push.dao.PushTemplateDao;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.redis.GracefulRedisTemplate;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-25 16:06
 */
@Service
public class PushTemplateCacheService {

    @Resource
    private GracefulRedisTemplate gracefulRedisTemplate;
    @Autowired
    private PushTemplateDao pushTemplateDao;

    @PostConstruct
    public void cachePushTemplateList() {
        List<PushTemplatePo> list = pushTemplateDao.queryAllList(0);
        Map<String, List<PushTemplatePo>> mapList = list.stream().collect(Collectors.groupingBy(PushTemplatePo::getTriggerNodeName));

        Set<String> keySet = mapList.keySet();
        Iterator<String> keyIt = keySet.iterator();
        while (keyIt.hasNext()) {
            String key = keyIt.next();
            gracefulRedisTemplate.setEx(CacheKeyHeadConstants.PUSH_TEMPLATE+key, mapList.get(key), 3600);
        }
    }

    public List<PushTemplatePo> getByTriggerNodeName(String triggerNodeName,Integer version) {
        List<PushTemplatePo> pushTemplateList = gracefulRedisTemplate.getList(CacheKeyHeadConstants.PUSH_TEMPLATE+triggerNodeName+version, PushTemplatePo.class);
        if (CollectionUtils.isNotEmpty(pushTemplateList) && MessageTriggerNodeEnum.addNewUser.name().equals(triggerNodeName)) {
            List<PushTemplatePo> unLoginTemplateList = gracefulRedisTemplate.getList(CacheKeyHeadConstants.PUSH_TEMPLATE+MessageTriggerNodeEnum.unLoginUser.name()+version, PushTemplatePo.class);
            if (CollectionUtils.isEmpty(unLoginTemplateList)) {
                unLoginTemplateList = pushTemplateDao.queryByTriggerNodeName(MessageTriggerNodeEnum.unLoginUser.name(),version);
                gracefulRedisTemplate.setEx(CacheKeyHeadConstants.PUSH_TEMPLATE+MessageTriggerNodeEnum.unLoginUser.name()+version, unLoginTemplateList, 3600);
            }
            pushTemplateList.addAll(unLoginTemplateList);
        }

        if (CollectionUtils.isEmpty(pushTemplateList)) {
            pushTemplateList = pushTemplateDao.queryByTriggerNodeName(triggerNodeName,version);
            if (CollectionUtils.isNotEmpty(pushTemplateList)) {
                if (MessageTriggerNodeEnum.addNewUser.name().equals(triggerNodeName)) {
                    Map<String, List<PushTemplatePo>> mapList = pushTemplateList.stream().collect(Collectors.groupingBy(PushTemplatePo::getTriggerNodeName));
                    Set<String> keySet = mapList.keySet();
                    Iterator<String> keyIt = keySet.iterator();
                    while (keyIt.hasNext()) {
                        String key = keyIt.next();
                        gracefulRedisTemplate.setEx(CacheKeyHeadConstants.PUSH_TEMPLATE+key+version, mapList.get(key), 3600);
                    }
                } else {
                    gracefulRedisTemplate.setEx(CacheKeyHeadConstants.PUSH_TEMPLATE+triggerNodeName+version, pushTemplateList, 3600);
                }
            }
        }
        return pushTemplateList;
    }

}
