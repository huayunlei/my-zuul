package com.ihomefnt.push.service.push;

import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.push.common.constant.LifeArticleHeadImgsData;
import com.ihomefnt.push.domain.dto.PersonalAgentMessage;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * 个人经纪人根据模版消息组装推送内容
 */
@Slf4j
@Service
public class PersonalAgentMessageHandle extends CommonMessagePushHandle{

    public PersonalAgentMessageHandle() {
        super();
    }

    @Override
    protected List<MessageRecordPo> process(Object commonMessage, List<PushTemplatePo> pushTemplateList) {
        PersonalAgentMessage personalAgentMessage = JsonUtils.json2obj(JsonUtils.obj2json(commonMessage), PersonalAgentMessage.class);
        log.info("PersonalAgentMessageHandle 个人经纪人推送消息处理， params:{}", personalAgentMessage);
        if (CollectionUtils.isEmpty(pushTemplateList)) {
            return null;
        }

        List<MessageRecordPo> messageRecordPoList = new ArrayList<>(pushTemplateList.size());
        final PersonalAgentMessage baseMessage = personalAgentMessage;
        for (PushTemplatePo pushTemplatePo : pushTemplateList) {
            MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage);
            messageRecordPoList.add(messageRecordPo);
        }

        return messageRecordPoList;
    }


    private MessageRecordPo assemblePushRecordPo(PushTemplatePo pushTemplatePo, PersonalAgentMessage baseMessage) {
        MessageRecordPo messageRecordPo = new MessageRecordPo();
        BeanUtils.copyProperties(pushTemplatePo, messageRecordPo);

        messageRecordPo.setCardImgs(pushTemplatePo.getCardImgs());
        messageRecordPo.setUserId(baseMessage.getUserId())
                .setTitle(pushTemplatePo.getTitle())
                .setSubTitle(pushTemplatePo.getSubTitle())
                .setContent(pushTemplatePo.getContent())
                .setSubContent( pushTemplatePo.getSubContent())
                .setOpenUrl(pushTemplatePo.getOpenUrl())
                .setPushStatus(1)
                .setPushTime(new Date())
        ;

        return messageRecordPo;
    }

}

