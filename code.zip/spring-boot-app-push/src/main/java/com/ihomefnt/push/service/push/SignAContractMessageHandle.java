package com.ihomefnt.push.service.push;

import com.ihomefnt.push.domain.dto.AppOrderBaseInfoResponseVo;
import com.ihomefnt.push.domain.dto.LoanMainInfoDto;
import com.ihomefnt.push.domain.dto.NewUpgradeInfoDto;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.proxy.AladdinOrderProxy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Description:提交方案签约推送消息处理
 * @Author hua
 * @Date 2019-11-19 11:22
 */
@Slf4j
@Service
public class SignAContractMessageHandle extends AbstactMessagePushHandle {
    @Autowired
    private AladdinOrderProxy aladdinOrderProxy;

    public SignAContractMessageHandle() {
        super();
    }

    @Override
    protected List<MessageRecordPo> process(ReceiveBaseMessage receiveBaseMessage, List<PushTemplatePo> pushTemplateList) {
        log.info("SignAContractMessageHandle 提交方案签约推送消息处理， params:{}", receiveBaseMessage);
        List<MessageRecordPo> messageRecordPoList = new ArrayList<>(pushTemplateList.size());
        final ReceiveBaseMessage baseMessage = receiveBaseMessage;
        Integer orderId = baseMessage.getMessageInfo().getOrderId();
        // 用户最新提交签约方案的时间（25、26、27）(其中25：未申请过爱家贷 26：权益为钻石级别以下  27：参与了保价优惠)
        AppOrderBaseInfoResponseVo orderBaseInfo = aladdinOrderProxy.queryAppOrderBaseInfo(orderId);
        List<LoanMainInfoDto> queryLoanInfoList = aladdinOrderProxy.queryLoanInfoList(orderId);

        if (orderBaseInfo != null) {
            for (PushTemplatePo pushTemplatePo : pushTemplateList) {
                if (25 == pushTemplatePo.getMessageNum() && CollectionUtils.isEmpty(queryLoanInfoList)) {
                    MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage);
                    messageRecordPoList.add(messageRecordPo);
                }
                if (26 == pushTemplatePo.getMessageNum() && orderBaseInfo.getGradeId() != 3) {
                    //权益等级4不判断是否有可升级项
                    if(baseMessage.getMessageInfo().getRightsVersion()!=null && baseMessage.getMessageInfo().getRightsVersion()==4){
                        MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage);
                        messageRecordPoList.add(messageRecordPo);
                    }else{
                        NewUpgradeInfoDto newUpgradeInfoDto = aladdinOrderProxy.queryNewUpgradeInfo(orderId);
                        if (null != newUpgradeInfoDto && newUpgradeInfoDto.isUpgradable() && CollectionUtils.isNotEmpty(newUpgradeInfoDto.getUpgradeList())) {
                            MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage);
                            NewUpgradeInfoDto.UpgradeItem upgradeItem = newUpgradeInfoDto.getUpgradeList().get(0);
                            String content = messageRecordPo.getContent();
                            content = content.replace("{gradeName}", upgradeItem.getGradeName())
                                    .replace("{requiredAmount}", upgradeItem.getPaymentRequiredAmount().stripTrailingZeros().toPlainString());
                            messageRecordPo.setContent(content);
                            messageRecordPoList.add(messageRecordPo);
                        }
                    }

                }
                if (27 == pushTemplatePo.getMessageNum() && orderBaseInfo.getLockPriceFlag() == 0) {
                    MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage);
                    messageRecordPoList.add(messageRecordPo);
                }
            }
        }

        return messageRecordPoList;

    }

    private MessageRecordPo assemblePushRecordPo(PushTemplatePo pushTemplatePo, ReceiveBaseMessage baseMessage) {
        ReceiveBaseMessage.MessageInfo messageInfo = baseMessage.getMessageInfo();
        MessageRecordPo messageRecordPo = new MessageRecordPo();
        BeanUtils.copyProperties(pushTemplatePo, messageRecordPo);

        String content = pushTemplatePo.getContent();
        String subContent = pushTemplatePo.getSubContent();
        String openUrl = pushTemplatePo.getOpenUrl();
        if (StringUtils.isNotBlank(openUrl)) {
            openUrl = openUrl.replace("{orderId}", String.valueOf(messageInfo.getOrderId()));
        }

        messageRecordPo.setUserId(messageInfo.getUserId())
                .setOrderId(messageInfo.getOrderId())
                .setTitle(pushTemplatePo.getTitle())
                .setSubTitle(pushTemplatePo.getSubTitle())
                .setContent(content)
                .setSubContent(subContent)
                .setOpenUrl(openUrl)
                .setPushStatus(1)
                .setPushTime(new Date())
        ;

        return messageRecordPo;
    }

}
