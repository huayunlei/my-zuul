package com.ihomefnt.push.domain.po;

import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2020/2/11 7:31 下午
 */
@Data
public class TempOrderDeliveryPo {

    private int id;

    private String mobile;//手机号

    private Integer userId; //用户id

    private Integer orderId; //订单id

    private Integer orderStatus;//订单状态

    private Integer status;// 处理状态 ： 0待处理 ， 1已处理

}
