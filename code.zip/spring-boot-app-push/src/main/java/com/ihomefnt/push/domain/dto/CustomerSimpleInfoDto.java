package com.ihomefnt.push.domain.dto;

import lombok.Data;

/**
 * 个人经纪人返回信息
 */
@Data
public class CustomerSimpleInfoDto {

    private String customerName;
    private String mobile;
    private Long userId;
    private Integer orderId;

}
