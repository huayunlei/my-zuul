package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-19 10:46
 */
@Data
@Accessors(chain = true)
@ApiModel("TestPushMessageDto")
public class TestPushMessageDto {
    @ApiModelProperty("推送手机号")
    private String mobile;

    @ApiModelProperty("推送版本号，都版本逗号隔开 5.4.5 ")
    private String version;

    @ApiModelProperty("feedMessageDto")
    private FeedMessageDto feedMessageDto;

}
