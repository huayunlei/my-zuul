package com.ihomefnt.push.dao;

import com.ihomefnt.push.domain.po.PushTemplatePo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-11 19:15
 */
@Repository
public interface PushTemplateDao {

    List<PushTemplatePo> queryByTriggerNodeName(@Param("triggerNodeName") String triggerNodeName,@Param("version") Integer version);

    List<PushTemplatePo> queryAllList(@Param("flag") int flag);

}
