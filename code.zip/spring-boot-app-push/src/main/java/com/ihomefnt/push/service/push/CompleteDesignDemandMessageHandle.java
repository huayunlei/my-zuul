package com.ihomefnt.push.service.push;

import com.ihomefnt.push.domain.dto.BatchSolutionBaseInfoVo;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.dto.SolutionBaseInfoVo;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.proxy.DollyWebProxy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Description:设计需求完成消息处理
 * @Author hua
 * @Date 2019-11-18 18:25
 */
@Slf4j
@Service
public class CompleteDesignDemandMessageHandle extends AbstactMessagePushHandle {
    @Autowired
    private DollyWebProxy dollyWebProxy;

    @Override
    protected List<MessageRecordPo> process(ReceiveBaseMessage receiveBaseMessage, List<PushTemplatePo> pushTemplateList) {
        log.info("CompleteDesignDemandMessageHandle 设计需求完成消息处理， params:{}", receiveBaseMessage);
        List<MessageRecordPo> messageRecordPoList = new ArrayList<>(pushTemplateList.size());
        final ReceiveBaseMessage.MessageInfo messageInfo = receiveBaseMessage.getMessageInfo();
        SolutionBaseInfoVo solutionBaseInfoVo = null;
        if (null != messageInfo.getSolutionId() && messageInfo.getSolutionId() > 0) {
            List<Integer> solutionIdList = new ArrayList<Integer>(1);
            solutionIdList.add(messageInfo.getSolutionId());
            BatchSolutionBaseInfoVo batchSolutionBaseInfoVo = dollyWebProxy.batchQuerySolutionBaseInfo(solutionIdList);
            if (null != batchSolutionBaseInfoVo && CollectionUtils.isNotEmpty(batchSolutionBaseInfoVo.getSolutionBaseInfoList())) {
                solutionBaseInfoVo = batchSolutionBaseInfoVo.getSolutionBaseInfoList().get(0);
            }
        }
        for (PushTemplatePo pushTemplatePo : pushTemplateList) {
            MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, messageInfo, solutionBaseInfoVo);
            messageRecordPoList.add(messageRecordPo);
        }

        return messageRecordPoList;
    }

    private MessageRecordPo assemblePushRecordPo(PushTemplatePo pushTemplatePo, ReceiveBaseMessage.MessageInfo messageInfo, SolutionBaseInfoVo solutionBaseInfoVo) {
        MessageRecordPo messageRecordPo = new MessageRecordPo();
        BeanUtils.copyProperties(pushTemplatePo, messageRecordPo);

        String content = pushTemplatePo.getContent();
        String subContent = pushTemplatePo.getSubContent();
        String openUrl = pushTemplatePo.getOpenUrl();
        if (StringUtils.isNotBlank(content) && null != solutionBaseInfoVo) {
            content = content.replace("{solutionName}", solutionBaseInfoVo.getSolutionName());
            messageRecordPo.setCardImgs(solutionBaseInfoVo.getHeadImgURL()+"!H-SMALL");
        }

        if (StringUtils.isNotBlank(openUrl)) {
            openUrl = openUrl.replace("{programId}", String.valueOf(messageInfo.getSolutionId()))
                    .replace("{orderId}", String.valueOf(messageInfo.getOrderId()))
                    .replace("{dataType}", "solution");
        }

        messageRecordPo.setUserId(messageInfo.getUserId())
                .setOrderId(messageInfo.getOrderId())
                .setTitle(pushTemplatePo.getTitle())
                .setSubTitle(pushTemplatePo.getSubTitle())
                .setContent(content)
                .setSubContent(subContent)
                .setOpenUrl(openUrl)
                .setPushStatus(1)
                .setPushTime(new Date())
        ;

        return messageRecordPo;
    }
}

