package com.ihomefnt.push.common.constant;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description:dna头图
 * @Author hua
 * @Date 2019-11-23 14:33
 */
public class DnaHeadImgsData {

    private static List<String> imgs = new ArrayList<>(20);
    static {
        imgs.add("https://img15.ihomefnt.com/cc8cad3c81768fa912c407d389ecdc27efa1744421f8ea7797329b8e7e651b77.jpg");
        imgs.add("https://img15.ihomefnt.com/18d0372bef0fb0325b3714a42b2d2e6334f8454f176b5d58830f893e0e608881.jpg");
        imgs.add("https://img15.ihomefnt.com/58904ed00a0f375ef07d91ddb28990da201a04483ff587a6df34ca1fb7ad6861.jpg");
        imgs.add("https://img15.ihomefnt.com/f90453ad2f0f6c2f4b90a95f8495a8021cf538cc619c1ac1c47a8ea634662062.jpg");
        imgs.add("https://img15.ihomefnt.com/bff05251f2c1f82082bc95d176566c85d9ab9bad66e1a1d6064e404707230eed.jpg");
        imgs.add("https://img15.ihomefnt.com/dfa9cd1216f2e901d77fde221cb395854b3b7012289597a3ce1586990e59af49.jpg");
        imgs.add("https://img15.ihomefnt.com/8079db7d65ad6eba4879518624fe709da10580305ffb32c1c5f8df68eb75e739.jpg");
        imgs.add("https://img15.ihomefnt.com/77c301662b1c06fcd832afa9886284bcc1f9260dc750791b3352f7416022b817.jpg");
        imgs.add("https://img15.ihomefnt.com/4381fad97ce2b0bfa544e6fff215b5c16c3b8beded04d4e5066e9191c8af01b4.jpg");
        imgs.add("https://img15.ihomefnt.com/a9f7c176700206e6597e54e83f47d6ab29407338d2e44286fab346b2710856b1.jpg");
        imgs.add("https://img15.ihomefnt.com/68c4110e0cfa9285ce20addd031f33bc8db3e75d90400483a3f3dd19d2debae9.jpg");
        imgs.add("https://img15.ihomefnt.com/a119e1615475ac5535c2b8e28d5862458dfb08e24edb69305684333ab82a12d9.jpg");
        imgs.add("https://img15.ihomefnt.com/8028baa66c4b86d71053c4ac83cf4aabdb37cc3a6621f9b77b4b1e1775b04d0a.jpg");
        imgs.add("https://img15.ihomefnt.com/d8022bacd06603cf4d79e6865df3c83c197299f66bea59648e7d553105440ecd.jpg");
        imgs.add("https://img15.ihomefnt.com/53fecb3fdc4692933d47f099343dcd83b83d8f6877930e5e8963d1d625ee2e4e.jpg");
        imgs.add("https://img15.ihomefnt.com/99b88c70c677bb1cfd6b624204522cd8969b683351a330eb87d91eb5429cb00c.jpg");
        imgs.add("https://img15.ihomefnt.com/47ab580eed5c7fb48069dfa5803db81e4baa53587cd90c5b3c8207394e55cdfa.jpg");
        imgs.add("https://img15.ihomefnt.com/6562f3e9a0d30299cd89d195cf8e0bf412dcef11efb7ab4f3134ec80f96a840f.jpg");
        imgs.add("https://img15.ihomefnt.com/80d004ce6b641f451726e35ef86123a60ece041fca5c434f92fd5fc21298bb2d.jpg");
        imgs.add("https://img15.ihomefnt.com/aab208d616e28b9030ed762980ffc31b6271fa07bdbea894b3f81e7a37c9c07d.jpg");
    }

    /**
     * cardType：卡片样式：1单张大图；2三张小图；3单张小图
     */
    public static String getCompressImgs(int cardType) {
        int size = cardType == 2 ? 3 : 1;
        List<String> list = new ArrayList<>(size);
        for (int i = 0;i < size;i++) {
            int number = (int)(Math.random()*imgs.size());
            if (cardType == 1) {
                list.add(imgs.get(number)+"!H-MIDDLE");
            } else {
                list.add(imgs.get(number)+"!H-SMALL");
            }
        }
        return list.stream().collect(Collectors.joining(","));
    }

    public static void main(String args[]) {
        System.out.println(DnaHeadImgsData.getCompressImgs(1));
    }

}
