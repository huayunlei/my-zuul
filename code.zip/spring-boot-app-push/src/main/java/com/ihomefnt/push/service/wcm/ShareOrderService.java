package com.ihomefnt.push.service.wcm;

import com.ihomefnt.push.domain.dto.PageResponse;
import com.ihomefnt.push.domain.dto.ShareOrderRequestDto;
import com.ihomefnt.push.domain.dto.ShareOrderResponseDto;
import com.ihomefnt.push.domain.dto.TransferDto;
import com.ihomefnt.push.proxy.WcmProxy;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author hua
 * @Date 2019-12-26 10:15
 */
@Service
public class ShareOrderService {

    @Autowired
    private WcmProxy wcmProxy;

    public List<ShareOrderResponseDto> getShareOrderListPage(ShareOrderRequestDto shareOrderRequestDto) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("type", 0);
        params.put("pageNo", shareOrderRequestDto.getPage());
        params.put("pageSize", shareOrderRequestDto.getLimit());
        params.put("checkFlag", shareOrderRequestDto.getCheckFlag());

        // 只查询主表
        PageResponse<TransferDto> page = wcmProxy.getTransferDtoList(params);
        if (null != page && CollectionUtils.isNotEmpty(page.getList())) {
            List<String> shareIdList = page.getList().stream().map(TransferDto::getFk).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(shareIdList)) {
                return wcmProxy.getShareOrderListByIds(shareIdList);
            }
        }

        return null;
    }
}
