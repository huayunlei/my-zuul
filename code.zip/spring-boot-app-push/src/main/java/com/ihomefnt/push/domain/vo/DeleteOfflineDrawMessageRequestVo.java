package com.ihomefnt.push.domain.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description:
 * @Author hua
 * @Date 2020/3/19 4:30 下午
 */
@Data
@ApiModel("DeleteOfflineDrawMessageRequestVo")
public class DeleteOfflineDrawMessageRequestVo {

    @ApiModelProperty("草稿编号")
    private Long draftProfileNum;

    @ApiModelProperty("用户id")
    private Integer userId;

    @ApiModelProperty("订单id")
    private Long orderId;
}
