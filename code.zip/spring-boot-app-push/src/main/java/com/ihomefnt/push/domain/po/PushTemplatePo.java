package com.ihomefnt.push.domain.po;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-11 19:08
 */
@Data
@Accessors(chain = true)
public class PushTemplatePo implements Serializable {

    private static final long serialVersionUID = 121030894935967057L;

    private int id;

    private String triggerNodeName; //消息触发节点名称

    private int messageNum; //消息序号

    private int sortNo; //顺序编号

    private String minVersion; //需要推送的最小版本号

    private String platform; //设备类型，android, ios, winphone，all

    private String pushTarget; //推送目标 ALIAS TAG ALL

    private String tags; //tag标签

    private String alias; //别号

    private String pushType; //推送类型: 通知 NOTICE 消息MESSAGE

    private String title;//通知栏标题

    private String subTitle;//副标题

    private String content;//推送内容

    private String subContent;//副内容

    private int cardType;// 卡片样式：1单张大图；2三图；3单张小图

    private String cardImgs; //卡片图urls，逗号隔开

    private String openUrl; //RN跳转地址

    private int refreshType; //1：只刷新核心区，2：只刷新信息区，3：都刷新

    private int hasRead; //是否已度： 0未读，1已读

    private int isPushTop; //是否置顶 0不置顶，1置顶

    private int isRepeat; //消息是否可重复 0不能重复，1可重复

    private String img; //消息盒子图片

    private int delFlag; //删除标识 ： 0可用 ， 1删除

    private Date createTime;

    private Date updateTime;

}
