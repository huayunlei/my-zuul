package com.ihomefnt.push.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author wanyunxin
 * @create 2019-11-22 10:25
 */
@Data
public class DecorationProcessDto {

    @ApiModelProperty("订单号")
    private Integer orderNum;

    @ApiModelProperty("用户id")
    private Integer userId;

    @ApiModelProperty("mq消息关键字")
    private String triggerNodeName;

    @ApiModelProperty("装修日历通配内容")//方案名称或xxx具体装修阶段
    private String eventContent;
}
