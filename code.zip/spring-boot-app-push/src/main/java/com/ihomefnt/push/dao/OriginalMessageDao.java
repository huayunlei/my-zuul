package com.ihomefnt.push.dao;

import com.ihomefnt.push.domain.po.OriginalMessagePo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-15 14:53
 */
@Repository
public interface OriginalMessageDao {

    int saveOriginalMessagePo(OriginalMessagePo originalMessagePo);

    int deleteOriginalMessagePoById(int id);

    int updateOriginalMessageStatusById(@Param("id") int id, @Param("status") int status);
}
