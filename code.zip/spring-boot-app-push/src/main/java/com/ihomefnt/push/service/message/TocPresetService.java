package com.ihomefnt.push.service.message;

import com.alibaba.ttl.threadpool.TtlExecutors;
import com.google.common.collect.Lists;
import com.ihomefnt.push.dao.PushTemplateDao;
import com.ihomefnt.push.domain.dto.AppVersionDto;
import com.ihomefnt.push.domain.dto.CustomerSimpleInfoDto;
import com.ihomefnt.push.domain.dto.TocMessageInfoRequest;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.proxy.AladdinOrderProxy;
import com.ihomefnt.push.proxy.AppVersionProxy;
import com.ihomefnt.push.service.thread.TocPresetRunnable;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * 老带新信息流预置
 */
@Slf4j
@Service
public class TocPresetService {
    private static int threadCount = 200;
    private static final ExecutorService exec = TtlExecutors.getTtlExecutorService(Executors.newFixedThreadPool(threadCount));

    @Autowired
    private PushTemplateDao pushTemplateDao;

    @Autowired
    private AppVersionProxy appVersionProxy;

    @Autowired
    private AladdinOrderProxy aladdinOrderProxy;

    private PushTemplatePo constructionNotifyPushTemplatePo;
    private String tags;


    @Async
    public void process(TocMessageInfoRequest request) throws InterruptedException {
        long start = System.currentTimeMillis();
        // 查询模版
        List<PushTemplatePo> pushTemplateList = new ArrayList<>();
        if(request.getTriggerNodeName().equals("personalAgentMessage")
                &&request.getMsgType().equals(27)){//toc信息流通知
            pushTemplateList = pushTemplateDao.queryByTriggerNodeName("personalAgentMessage",2);

        }else if(request.getTriggerNodeName().equals("tocOldUserMessagePush")
                &&request.getMsgType().equals(24)){//toc通知栏信息
            PushTemplatePo pushTemplatePo = new PushTemplatePo();
            pushTemplatePo.setOpenUrl("rn://decoration/InviteRewardPage");
            pushTemplatePo.setMinVersion("5.5.5");
            pushTemplatePo.setTitle("友福同享");
            pushTemplatePo.setContent("把艾佳推荐给身边好友，最高可得10000元现金红包，好友也可得万元置家大礼包！多邀多得，上不封顶");
            pushTemplatePo.setPushType("NOTICE");
            pushTemplateList.add(pushTemplatePo);
        }else{
            return;
        }

        if (CollectionUtils.isEmpty(pushTemplateList)) {
            return;
        }
        constructionNotifyPushTemplatePo = pushTemplateList.get(0);

        List<CustomerSimpleInfoDto> customerSimpleInfoDtos = aladdinOrderProxy.queryAllFundCustomer();
        if (CollectionUtils.isEmpty(customerSimpleInfoDtos)) {
            XxlJobLogger.log("未做任何操作,无推送用户!");
            return;
        }

        if (StringUtils.isNotEmpty(constructionNotifyPushTemplatePo.getMinVersion())) {
            List<AppVersionDto> versionDtoList = appVersionProxy.queryRecordListByMinVersion(constructionNotifyPushTemplatePo.getMinVersion(), Lists.newArrayList("washriwvd8c6r6nz","eax4kpvv3nsuk837"));
            if (!org.springframework.util.CollectionUtils.isEmpty(versionDtoList)) {
                Set<String> versionSet = versionDtoList.parallelStream().map(versionDto -> versionDto.getVersion()).collect(Collectors.toSet());
                tags = versionSet.stream().collect(Collectors.joining(","));
            }
        }
        log.info("push message total:{}", customerSimpleInfoDtos.size());
        List<List<CustomerSimpleInfoDto>> partition = Lists.partition(customerSimpleInfoDtos, 300);
        for (List<CustomerSimpleInfoDto> requests : partition) {
            exec.execute(new TocPresetRunnable(requests,tags,constructionNotifyPushTemplatePo,request));
            Thread.sleep(500L);
        }

        log.info("TocPresetService.process finished，times：{}", System.currentTimeMillis() - start);
    }

}
