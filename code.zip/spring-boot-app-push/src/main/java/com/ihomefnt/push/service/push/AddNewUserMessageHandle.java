package com.ihomefnt.push.service.push;

import com.ihomefnt.push.common.constant.DnaHeadImgsData;
import com.ihomefnt.push.common.constant.LifeArticleHeadImgsData;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.dto.ShareOrderRequestDto;
import com.ihomefnt.push.domain.dto.ShareOrderResponseDto;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.service.wcm.ShareOrderService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description:用户注册推送消息处理
 * @Author hua
 * @Date 2019-11-11 14:23
 */
@Slf4j
@Service
public class AddNewUserMessageHandle extends AbstactMessagePushHandle {

    @Autowired
    private ShareOrderService shareOrderService;

    public AddNewUserMessageHandle() {
        super();
    }

    @Override
    protected List<MessageRecordPo> process(ReceiveBaseMessage receiveBaseMessage, List<PushTemplatePo> pushTemplateList) {
        log.info("AddNewUserMessageHandle 用户注册推送消息处理， params:{}", receiveBaseMessage);
        List<MessageRecordPo> messageRecordPoList = new ArrayList<>(pushTemplateList.size());
        final ReceiveBaseMessage baseMessage = receiveBaseMessage;
        Date now = new Date();
        for (PushTemplatePo pushTemplatePo : pushTemplateList) {
            MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage, now);
            messageRecordPoList.add(messageRecordPo);
        }

        return messageRecordPoList;

    }

    private MessageRecordPo assemblePushRecordPo(PushTemplatePo pushTemplatePo, ReceiveBaseMessage baseMessage, Date now) {
        ReceiveBaseMessage.MessageInfo messageInfo = baseMessage.getMessageInfo();
        MessageRecordPo messageRecordPo = new MessageRecordPo();
        BeanUtils.copyProperties(pushTemplatePo, messageRecordPo);

        String content = pushTemplatePo.getContent();
        String subContent = pushTemplatePo.getSubContent();
        String openUrl = pushTemplatePo.getOpenUrl();
        // 首席交付官
        if (3 == pushTemplatePo.getMessageNum() && StringUtils.isBlank(pushTemplatePo.getCardImgs())) {
            messageRecordPo.setCardImgs(LifeArticleHeadImgsData.getCompressImgs(pushTemplatePo.getCardType(), 5));
        }
        // 设计案例
        if (6 == pushTemplatePo.getMessageNum() && StringUtils.isBlank(pushTemplatePo.getCardImgs())) {
            messageRecordPo.setCardImgs(DnaHeadImgsData.getCompressImgs(pushTemplatePo.getCardType()));
        }
        // 我秀我家评论中的3张图
        if (7 == pushTemplatePo.getMessageNum() && StringUtils.isBlank(pushTemplatePo.getCardImgs())) {
            List<ShareOrderResponseDto> shareOrderList = shareOrderService.getShareOrderListPage(new ShareOrderRequestDto(1,10, 1));

            List<String> cardImgList = new ArrayList<>(3);
            for (ShareOrderResponseDto item : shareOrderList) {
                if (cardImgList.size() == 3) {
                    break;
                }

                List<String> imgContent = item.getImgContent();
                for (String cardImg : imgContent) {
                    if (cardImgList.size() == 3) {
                        break;
                    }
                    cardImgList.add(cardImg + "!H-SMALL");
                }
            }
            if (CollectionUtils.isNotEmpty(cardImgList)) {
                String cardImgs = cardImgList.stream().collect(Collectors.joining(","));
                messageRecordPo.setCardImgs(cardImgs);
            }
        }

        messageRecordPo.setUserId(messageInfo.getUserId())
                .setOrderId(messageInfo.getOrderId())
                .setTitle(pushTemplatePo.getTitle())
                .setSubTitle(pushTemplatePo.getSubTitle())
                .setContent(content)
                .setSubContent(subContent)
                .setOpenUrl(openUrl)
                .setPushStatus(1)
                .setPushTime(now)
                ;

        return messageRecordPo;
    }

}
