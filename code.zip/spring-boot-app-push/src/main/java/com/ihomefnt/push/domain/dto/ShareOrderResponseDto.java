package com.ihomefnt.push.domain.dto;

import lombok.Data;

import java.util.List;

/**
 * Created by onefish on 2016/11/3 0003. 用户的晒单分享
 */
@Data
public class ShareOrderResponseDto {
	/**
	 * 晒单mongoId
	 */
	private String shareOrderId;
	/**
	 * 用户id
	 */
	private long userId;

	/**
	 * 用户昵称
	 */
	private String userNickName;

	/**
	 * 用户头像
	 */
	private String userImgUrl;

	/**
	 * 用户手机号码
	 */
	private String phoneNum;

	/**
	 * 展示在前端的名称，若有用户昵称则为用户昵称，否则为用户手机号码 only for front end ,no meaning for
	 * backend
	 */
	private String showName;

	/**
	 * 晒单文字内容
	 */
	private String textContent;

	/**
	 * 晒单图片内容
	 */
	private List<String> imgContent;

	/**
	 * 晒单生成时间
	 */
	private long createTime;

	/**
	 * 晒单生成时间文字 eg. 5分钟前
	 */
	private String createTimeText;

	/**
	 * 晒单点赞数
	 */
	private int praiseNum;

	/**
	 * 用户是否点赞 0：未点赞 1：已点赞 默认未点赞
	 */
	private String praised = "0";



}
