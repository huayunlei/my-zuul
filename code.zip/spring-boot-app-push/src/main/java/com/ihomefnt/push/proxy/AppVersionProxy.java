package com.ihomefnt.push.proxy;

import com.beust.jcommander.internal.Maps;
import com.ihomefnt.common.http.HttpBaseResponse;
import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.push.common.constant.ServiceNameConstants;
import com.ihomefnt.push.domain.dto.AppVersionDto;
import com.ihomefnt.zeus.finder.ServiceCaller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-15 18:12
 */
@Slf4j
@Service
public class AppVersionProxy {

    @Resource
    private ServiceCaller serviceCaller;

    public List<AppVersionDto> queryRecordListByMinVersion (String minVersion, List<String> appIdList) {
        HttpBaseResponse responseVo = null;
        try {
            responseVo = serviceCaller.post(ServiceNameConstants.QUERY_RECORD_LIST_BY_MIN_VERSION, Maps.newHashMap("minVersion", minVersion, "appIdList", appIdList),
                    HttpBaseResponse.class);
        } catch (Exception e) {
            log.error(ServiceNameConstants.QUERY_RECORD_LIST_BY_MIN_VERSION + " param:{}, ERROR:{}", minVersion, e.getMessage());
        }

        if (responseVo == null || responseVo.getObj() == null) {
            return null;
        }
        return JsonUtils.json2list(JsonUtils.obj2json(responseVo.getObj()), AppVersionDto.class);
    }

}
