package com.ihomefnt.push.common.mq.listener;

import com.ihomefnt.common.util.JsonUtils;
import com.ihomefnt.common.util.ServiceLocator;
import com.ihomefnt.common.util.validation.ValidationResult;
import com.ihomefnt.common.util.validation.ValidationUtils;
import com.ihomefnt.message.annotation.RocketListener;
import com.ihomefnt.push.common.constant.MessageTriggerNodeEnum;
import com.ihomefnt.push.common.factory.MessagePushHandleFactory;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.dto.UserDto;
import com.ihomefnt.push.service.push.AbstactMessagePushHandle;
import com.ihomefnt.push.service.push.CommonMessagePushHandle;
import com.ihomefnt.push.service.push.DecorationProcessHandle;
import com.ihomefnt.push.service.push.OnlyRefreshOrOriginalMessageHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Description:推送消息listener
 * @Author hua
 * @Date 2019-11-11 11:36
 */
@Slf4j
@Service
public class MqMessagePushListener {

    @Autowired
    private OnlyRefreshOrOriginalMessageHandle onlyRefreshOrOriginalMessageHandle;


    @Autowired
    private DecorationProcessHandle decorationProcessHandle;

    @RocketListener(topic = "${app.push.message.flow}", consumerGroup = "app-push")
    public void handlerMessage(String message) {
        log.info("MqMessagePushListener start params:{}", message);
        ReceiveBaseMessage receiveBaseMessage = JsonUtils.json2obj(message, ReceiveBaseMessage.class);

        ValidationResult result = ValidationUtils.validateEntity(receiveBaseMessage);
        if (result.isHasErrors()) {
            log.info("MqMessagePushListener params check error params:{}， error:{}", message, result.getErrorMsgJson());
            return;
        }
        ReceiveBaseMessage.MessageInfo messageInfo = receiveBaseMessage.getMessageInfo();
        if(receiveBaseMessage.getTriggerNodeName().equals("completeEditDesignDemand")){//方案修改意见完成暂时不处理
            log.info("MqMessagePushListener 方案意见消息暂不处理:{}", message);
            return;
        }
        if(receiveBaseMessage.getTriggerNodeName().equals(MessageTriggerNodeEnum.cancelScheme.name())
                && receiveBaseMessage.getMessageInfo().getSolutionId()!=null
                && receiveBaseMessage.getMessageInfo().getSolutionId().equals(3232)){//艾家贷取消方案不进装修历程
            log.info("MqMessagePushListener 艾家贷取消方案不进装修历程:{}", message);
            return;
        }

        UserDto userInfo = onlyRefreshOrOriginalMessageHandle.getUserInfo(messageInfo.getUserId(), messageInfo.getOrderId());
        if (userInfo == null) {
            log.error("userDto is null ，param:{}", receiveBaseMessage);
            return;
        }
        messageInfo.setUserId(userInfo.getId());
        //装修进程
        decorationProcessHandle.addDecorationProcess(receiveBaseMessage,userInfo);
        // 1 正常全流程，2 只记原信息，刷新核心区 3 只记原信息
        int messageTriggerType = MessageTriggerNodeEnum.getMessageTriggerType(receiveBaseMessage.getTriggerNodeName());
        if (2 == messageTriggerType || 3 == messageTriggerType) {
            onlyRefreshOrOriginalMessageHandle.processMessage(receiveBaseMessage, messageTriggerType,userInfo);
            return;
        }

        AbstactMessagePushHandle messagePushHandle = MessagePushHandleFactory.newMessagePushHandle(receiveBaseMessage.getTriggerNodeName());
        if (null == messagePushHandle) {
            return;
        }

        messagePushHandle.handle(receiveBaseMessage,userInfo);

    }

    @RocketListener(topic = "${app.become.personal.agent}", consumerGroup = "app-push")
    public void handlerPersonalAgentMessage(String message) {
        log.info("MqMessagePushListener personal agent start params:{}", message);
        Object personalAgentMessage = JsonUtils.json2obj(message, Object.class);

        ValidationResult result = ValidationUtils.validateEntity(personalAgentMessage);
        if (result.isHasErrors()) {
            log.info("MqMessagePushListener personal agent  params check error params:{}， error:{}", message, result.getErrorMsgJson());
            return;
        }

        CommonMessagePushHandle messagePushHandle = (CommonMessagePushHandle) ServiceLocator.init().getService("personalAgentMessageHandle");
        if (null == messagePushHandle) {
            return;
        }
        messagePushHandle.handle(personalAgentMessage,"personalAgentMessage");
    }

}