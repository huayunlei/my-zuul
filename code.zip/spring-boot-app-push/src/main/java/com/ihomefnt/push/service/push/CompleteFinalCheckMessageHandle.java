package com.ihomefnt.push.service.push;

import com.ihomefnt.push.common.constant.AijiaShopProductImgs;
import com.ihomefnt.push.domain.dto.AppOrderBaseInfoResponseVo;
import com.ihomefnt.push.domain.dto.ReceiveBaseMessage;
import com.ihomefnt.push.domain.dto.ShareOrderRequestDto;
import com.ihomefnt.push.domain.dto.ShareOrderResponseDto;
import com.ihomefnt.push.domain.po.MessageRecordPo;
import com.ihomefnt.push.domain.po.PushTemplatePo;
import com.ihomefnt.push.proxy.AladdinOrderProxy;
import com.ihomefnt.push.service.wcm.ShareOrderService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description:用户评价验收完成推送消息处理
 * @Author hua
 * @Date 2019-11-19 17:41
 */
@Slf4j
@Service
public class CompleteFinalCheckMessageHandle extends AbstactMessagePushHandle {
    @Autowired
    private ShareOrderService shareOrderService;
    @Autowired
    private AladdinOrderProxy aladdinOrderProxy;

    public CompleteFinalCheckMessageHandle() {
        super();
    }

    @Override
    protected List<MessageRecordPo> process(ReceiveBaseMessage receiveBaseMessage, List<PushTemplatePo> pushTemplateList) {
        log.info("CompleteFinalCheckMessageHandle 用户评价验收完成推送消息处理， params:{}", receiveBaseMessage);
        List<MessageRecordPo> messageRecordPoList = new ArrayList<>(pushTemplateList.size());
        final ReceiveBaseMessage baseMessage = receiveBaseMessage;
        for (PushTemplatePo pushTemplatePo : pushTemplateList) {
            MessageRecordPo messageRecordPo = assemblePushRecordPo(pushTemplatePo, baseMessage);
            messageRecordPoList.add(messageRecordPo);
        }

        return messageRecordPoList;

    }

    private MessageRecordPo assemblePushRecordPo(PushTemplatePo pushTemplatePo, ReceiveBaseMessage baseMessage) {
        ReceiveBaseMessage.MessageInfo messageInfo = baseMessage.getMessageInfo();
        MessageRecordPo messageRecordPo = new MessageRecordPo();
        BeanUtils.copyProperties(pushTemplatePo, messageRecordPo);

        String content = pushTemplatePo.getContent();
        String subContent = pushTemplatePo.getSubContent();
        String openUrl = pushTemplatePo.getOpenUrl();
        if (36 == pushTemplatePo.getMessageNum()) {
            if (StringUtils.isNotBlank(openUrl)) {
                openUrl = openUrl.replace("{orderId}", String.valueOf(messageInfo.getOrderId()));
            }
            AppOrderBaseInfoResponseVo orderBaseInfo = aladdinOrderProxy.queryAppOrderBaseInfo(messageInfo.getOrderId());
            if (null != orderBaseInfo) {
                subContent = subContent.replace("{gradeName}", orderBaseInfo.getGradeName());
            }
        }
        if (37 == pushTemplatePo.getMessageNum() && StringUtils.isBlank(pushTemplatePo.getCardImgs())) {
            messageRecordPo.setCardImgs(AijiaShopProductImgs.getCompressImgs());
        }

        // 我秀我家评论中的3张图
        if (38 == pushTemplatePo.getMessageNum() && StringUtils.isBlank(pushTemplatePo.getCardImgs())) {
            List<ShareOrderResponseDto> shareOrderList = shareOrderService.getShareOrderListPage(new ShareOrderRequestDto(1,10, 1));
            List<String> cardImgList = new ArrayList<>(3);
            for (ShareOrderResponseDto item : shareOrderList) {
                if (cardImgList.size() == 3) {
                    break;
                }

                List<String> imgContent = item.getImgContent();
                for (String cardImg : imgContent) {
                    if (cardImgList.size() == 3) {
                        break;
                    }
                    cardImgList.add(cardImg + "!H-SMALL");
                }
            }
            if (CollectionUtils.isNotEmpty(cardImgList)) {
                String cardImgs = cardImgList.stream().collect(Collectors.joining(","));
                messageRecordPo.setCardImgs(cardImgs);
            }
        }

        messageRecordPo.setUserId(messageInfo.getUserId())
                .setOrderId(messageInfo.getOrderId())
                .setTitle(pushTemplatePo.getTitle())
                .setSubTitle(pushTemplatePo.getSubTitle())
                .setContent(content)
                .setSubContent(subContent)
                .setOpenUrl(openUrl)
                .setPushStatus(1)
                .setPushTime(new Date())
        ;

        return messageRecordPo;
    }

}

