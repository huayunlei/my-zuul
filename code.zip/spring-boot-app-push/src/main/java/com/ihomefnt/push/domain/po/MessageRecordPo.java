package com.ihomefnt.push.domain.po;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @Description:
 * @Author hua
 * @Date 2019-11-12 10:08
 */
@Data
@Accessors(chain = true)
public class MessageRecordPo {

    private int id;

    private Integer userId; //用户id

    private Integer orderId; //订单id

    private String triggerNodeName; //消息触发节点名称

    private int messageNum; //消息序号

    private int sortNo; //顺序编号

    private String title;//通知栏标题

    private String subTitle;//副标题

    private String content;//推送内容

    private String subContent;//副内容

    private String platform; //设备类型，android, ios, winphone，all

    private String pushTarget; //推送目标 ALIAS TAG ALL

    private String tags; //tag标签

    private String alias; //别号

    private String pushType; //推送类型: 通知 NOTICE 消息MESSAGE

    private String img; //消息盒子图片

    private int cardType;// 卡片样式：1单张大图；2三图；3单张小图

    private String cardImgs; //卡片图urls，逗号隔开

    private String openUrl; //RN跳转地址

    private int hasRead; //是否已度： 0未读，1已读

    private int isPushTop; //是否置顶 0不置顶，1置顶

    private int pushStatus; //推送状态 ： 0待推送，1已推送 ， -1推送失败

    private String errorMsg = ""; //推送失败原因

    private int delFlag; //删除标识 ： 0可用 ， 1删除

    private Date pushTime;//推送时间

    private Date createTime;

    private Date updateTime;


}
